# Aset dan komponen pihak ketiga

Paket ini menyalin aset yang sudah digunakan pada aplikasi agar tampilannya tidak hilang setelah diekstrak. Ketersediaan source code **bukan** pemberian hak distribusi anime, poster, merek dagang, atau musik pihak ketiga.

## Plus Jakarta Sans

Font lokal di `public/fonts/` berasal dari Plus Jakarta Sans. Copyright 2020 The Plus Jakarta Sans Project Authors (https://github.com/tokotype/PlusJakartaSans). Lisensi SIL Open Font License 1.1 lengkap disertakan di `public/fonts/OFL.txt`.

## Poster dan metadata anime

Poster berasal dari MyAnimeList dan metadata daring menggunakan Jikan. Judul, karakter, poster, dan merek masing-masing tetap milik pemegang haknya. Tidak ada lisensi komersial tambahan yang diberikan oleh ZIP ini. Untuk deployment publik atau komersial, pastikan izin penggunaan/redistribusi sesuai ketentuan pemegang hak dan sumber atau ganti dengan aset berizin.

- https://myanimelist.net/
- https://jikan.moe/
- https://docs.api.jikan.moe/

## Video dan subtitle

Trailer disematkan dari kanal YouTube; pemutar hanya memuat trailer setelah pengguna memilih memutar. Episode penuh tidak dibundel. Pemutar dan webhook harus dihubungkan ke video/subtitle berlisensi sesuai wilayah penayangan. Hosting kode tidak memberikan hak untuk menayangkan konten milik pihak lain.

## Ilustrasi aplikasi

Ilustrasi hero dan avatar di proyek ini dihasilkan untuk prototipe, termasuk versi optimal WebP dan ikon. Avatar bukan berkas asli lampiran pengguna. Pengelola boleh menggantinya dengan gambar yang memiliki izin penggunaan yang sesuai. Tidak ada pernyataan bahwa karakter atau elemen yang menyerupai karya pihak ketiga telah mendapat persetujuan pemegang hak.

## Pustaka perangkat lunak

Next.js, React, Drizzle ORM, pg, Tailwind CSS, Lucide, hls.js, dan alat pengujian mengikuti lisensi distribusinya masing-masing. Versi terkunci terdapat dalam `package-lock.json`. `node_modules` tidak dibundel; lisensi dependency ikut terpasang saat `npm ci`. Tinjau lisensi paket pada distribusi resmi bila menggunakan atau mendistribusikan turunannya.
