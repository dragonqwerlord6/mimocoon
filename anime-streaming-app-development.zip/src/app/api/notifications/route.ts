import { and, desc, eq, lte } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { currentUser, errorResponse, sameOrigin, validUuid } from "@/lib/auth";

export async function GET() {
  try {
    const user = await currentUser();
    if (!user) return Response.json({ notifications: [] });
    const rows = await db.select().from(notifications).where(and(eq(notifications.userId, user.id), lte(notifications.visibleAt, new Date()))).orderBy(desc(notifications.visibleAt)).limit(50);
    return Response.json({ notifications: rows.map(n => ({ ...n, createdAt: n.visibleAt })) });
  } catch { return errorResponse("Notifikasi belum dapat dimuat.", 503); }
}
export async function POST(request: Request) {
  if (!sameOrigin(request)) return errorResponse("Permintaan tidak diizinkan.", 403);
  try {
    const user = await currentUser();
    if (!user) return errorResponse("Masuk terlebih dahulu.", 401);
    const body = await request.json();
    if (body.id && !validUuid(body.id)) return errorResponse("Notifikasi tidak valid.");
    await db.update(notifications).set({ read: true }).where(and(eq(notifications.userId, user.id), lte(notifications.visibleAt, new Date()), body.id ? eq(notifications.id, body.id) : undefined));
    return Response.json({ success: true });
  } catch { return errorResponse("Notifikasi belum dapat diperbarui.", 503); }
}
