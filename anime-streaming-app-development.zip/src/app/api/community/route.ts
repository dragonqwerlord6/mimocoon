import { and, eq, desc, count, avg, inArray } from "drizzle-orm";
import { db } from "@/db";
import { comments, commentLikes, users, likes, ratings, notifications } from "@/db/schema";
import { currentUser, publicUser, sameOrigin, errorResponse, validAnimeId, validUuid, rateLimit } from "@/lib/auth";
import { catalog } from "@/lib/catalog";

export async function GET(request: Request) {
  try {
    const animeId = Number(new URL(request.url).searchParams.get("animeId") || 0);
    if (animeId !== 0 && !validAnimeId(animeId)) return errorResponse("Anime tidak valid.");
    const user = await currentUser();
    const [rows, totals, scores, myLike, myScore] = await Promise.all([
      db.select({ comment: comments, user: users }).from(comments).innerJoin(users, eq(users.id, comments.userId)).where(eq(comments.animeId, animeId)).orderBy(desc(comments.createdAt)).limit(150),
      db.select({ value: count() }).from(likes).where(eq(likes.animeId, animeId)),
      db.select({ value: avg(ratings.score), count: count() }).from(ratings).where(eq(ratings.animeId, animeId)),
      user ? db.select().from(likes).where(and(eq(likes.animeId, animeId), eq(likes.userId, user.id))) : [],
      user ? db.select().from(ratings).where(and(eq(ratings.animeId, animeId), eq(ratings.userId, user.id))) : [],
    ]);
    const allLikes = rows.length ? await db.select().from(commentLikes).where(inArray(commentLikes.commentId, rows.map(r => r.comment.id))) : [];
    const ids = new Set(rows.map(r => r.comment.id));
    return Response.json({
      comments: rows.map(({ comment, user: author }) => ({ ...comment, parentId: comment.parentId && ids.has(comment.parentId) ? comment.parentId : null, name: author.name, verified: publicUser(author).verified, likes: allLikes.filter(l => l.commentId === comment.id).length, liked: allLikes.some(l => l.commentId === comment.id && l.userId === user?.id) })),
      stats: { likes: totals[0]?.value || 0, rating: Number(scores[0]?.value || 0), votes: scores[0]?.count || 0 },
      liked: myLike.length > 0, score: myScore[0]?.score || 0,
    });
  } catch { return errorResponse("Komentar belum dapat dimuat. Silakan coba lagi.", 503); }
}
export async function POST(request: Request) {
  if (!sameOrigin(request)) return errorResponse("Permintaan tidak diizinkan.", 403);
  try {
    const user = await currentUser();
    if (!user) return errorResponse("Masuk untuk ikut berinteraksi.", 401);
    if (!rateLimit(`community:${user.id}`, 100)) return errorResponse("Terlalu banyak interaksi. Istirahat sebentar, ya.", 429);
    const body = await request.json(); const { action, animeId } = body;
    if (animeId !== 0 && !validAnimeId(animeId)) return errorResponse("Anime tidak valid.");
    if (action === "comment") {
      const text = typeof body.text === "string" ? body.text.trim() : "";
      if (!text || text.length > 2000) return errorResponse("Komentar harus terdiri dari 1–2.000 karakter.");
      let parent: typeof comments.$inferSelect | undefined;
      if (body.parentId) {
        if (!validUuid(body.parentId)) return errorResponse("Balasan tidak valid.");
        [parent] = await db.select().from(comments).where(and(eq(comments.id, body.parentId), eq(comments.animeId, animeId))).limit(1);
        if (!parent) return errorResponse("Komentar yang dibalas tidak ditemukan.", 404);
      }
      const comment = await db.transaction(async (tx) => {
        const [created] = await tx.insert(comments).values({ userId: user.id, animeId, body: text, parentId: parent ? (parent.parentId || parent.id) : null }).returning();
        if (parent && parent.userId !== user.id) await tx.insert(notifications).values({ userId: parent.userId, title: `${user.name} membalas komentarmu`, body: text.slice(0, 240), animeId, anime: catalog.find(a => a.id === animeId) || null, commentId: created.id });
        return created;
      });
      return Response.json({ comment }, { status: 201 });
    }
    if (action === "commentLike") {
      if (!validUuid(body.commentId)) return errorResponse("Komentar tidak valid.");
      const [comment] = await db.select().from(comments).where(and(eq(comments.id, body.commentId), eq(comments.animeId, animeId))).limit(1);
      if (!comment) return errorResponse("Komentar tidak ditemukan.", 404);
      const condition = and(eq(commentLikes.userId, user.id), eq(commentLikes.commentId, body.commentId));
      const removed = await db.delete(commentLikes).where(condition).returning();
      if (!removed.length) await db.insert(commentLikes).values({ userId: user.id, commentId: body.commentId }).onConflictDoNothing();
      return Response.json({ liked: !removed.length });
    }
    if (action === "like") {
      const removed = await db.delete(likes).where(and(eq(likes.userId, user.id), eq(likes.animeId, animeId))).returning();
      if (!removed.length) await db.insert(likes).values({ userId: user.id, animeId }).onConflictDoNothing();
      return Response.json({ liked: !removed.length });
    }
    if (action === "rate") {
      if (!Number.isInteger(body.score) || body.score < 1 || body.score > 10) return errorResponse("Pilih rating antara 1–10.");
      await db.insert(ratings).values({ userId: user.id, animeId, score: body.score }).onConflictDoUpdate({ target: [ratings.userId, ratings.animeId], set: { score: body.score } });
      return Response.json({ score: body.score });
    }
    return errorResponse("Aksi tidak dikenal.");
  } catch { return errorResponse("Interaksi belum tersimpan. Silakan coba lagi.", 503); }
}
