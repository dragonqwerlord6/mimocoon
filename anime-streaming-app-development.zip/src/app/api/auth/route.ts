import { cookies } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { users, sessions, emailTokens } from "@/db/schema";
import { currentUser, publicUser, hashPassword, checkPassword, createSession, digest, sameOrigin, rateLimit, sendVerification, errorResponse } from "@/lib/auth";

export async function GET() {
  try { const user = await currentUser(); return Response.json({ user: user ? publicUser(user) : null }, { headers: { "Cache-Control": "private, no-store, max-age=0", Vary: "Cookie" } }); }
  catch { return errorResponse("Layanan akun sementara tidak tersedia. Coba lagi sebentar.", 503); }
}
export async function POST(request: Request) {
  if (!sameOrigin(request)) return errorResponse("Permintaan tidak diizinkan.", 403);
  try {
    const body = await request.json();
    const { action } = body;
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0] || "local";
    if (action === "logout") {
      const jar = await cookies(); const token = jar.get("animeil_session")?.value;
      if (token) await db.delete(sessions).where(eq(sessions.tokenHash, digest(token)));
      jar.delete("animeil_session"); return Response.json({ user: null });
    }
    if (action === "verify") {
      if (typeof body.token !== "string" || !/^[a-f0-9]{64}$/.test(body.token)) return errorResponse("Tautan verifikasi tidak valid.");
      const verified = await db.transaction(async (tx) => {
        const [token] = await tx.delete(emailTokens).where(and(eq(emailTokens.tokenHash, digest(body.token)), gt(emailTokens.expiresAt, new Date()))).returning();
        if (!token) return false;
        await tx.update(users).set({ emailVerified: true }).where(eq(users.id, token.userId));
        return true;
      });
      if (!verified) return errorResponse("Tautan sudah digunakan atau kedaluwarsa. Kirim ulang dari menu akun.");
      const user = await currentUser();
      return Response.json({ user: user ? publicUser(user) : null, message: "Email berhasil diverifikasi. Akunmu sekarang lebih aman." });
    }
    if (action === "resend") {
      const user = await currentUser();
      if (!user) return errorResponse("Masuk terlebih dahulu.", 401);
      if (user.emailVerified) return Response.json({ message: "Email sudah terverifikasi." });
      if (!rateLimit(`verify:${user.id}`, 3)) return errorResponse("Tunggu 15 menit sebelum meminta email baru.", 429);
      const sent = await sendVerification(user, request);
      return sent ? Response.json({ message: "Tautan verifikasi terkirim. Periksa kotak masuk dan folder spam." }) : errorResponse("Layanan email belum aktif. Pengelola perlu mengatur koneksi email terlebih dahulu.", 503);
    }
    if (!["login", "register"].includes(action)) return errorResponse("Aksi tidak dikenal.");
    if (!rateLimit(`auth:${ip}`, 25)) return errorResponse("Terlalu banyak percobaan. Coba lagi dalam 15 menit.", 429);
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const password = typeof body.password === "string" ? body.password : "";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return errorResponse("Masukkan alamat email yang valid.");
    if (password.length < 8 || password.length > 128) return errorResponse("Kata sandi harus terdiri dari 8–128 karakter.");
    if (action === "login") {
      const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
      if (!user || !checkPassword(password, user.passwordHash)) return errorResponse("Email atau kata sandi tidak cocok. Gunakan sandi akun animeil.al yang dibuat saat mendaftar. Belum punya akun? Pilih Daftar. Jika lupa, pilih Lupa kata sandi.", 401);
      await createSession(user.id, request);
      return Response.json({ user: publicUser(user), message: `Selamat datang kembali, ${user.name}!` });
    }
    const name = typeof body.name === "string" ? body.name.trim() : "";
    if (name.length < 2 || name.length > 40) return errorResponse("Nama pengguna harus terdiri dari 2–40 karakter.");
    const [user] = await db.insert(users).values({ name, email, passwordHash: hashPassword(password) }).onConflictDoNothing({ target: users.email }).returning();
    if (!user) return errorResponse("Email sudah terdaftar. Silakan masuk ke akunmu.", 409);
    await createSession(user.id, request);
    const sent = await sendVerification(user, request);
    return Response.json({ user: publicUser(user), message: sent ? "Akun berhasil dibuat! Tautan verifikasi dikirim ke emailmu." : "Akun berhasil dibuat. Selamat menemukan cerita barumu!" }, { status: 201 });
  } catch (error) {
    if (error instanceof SyntaxError) return errorResponse("Format permintaan tidak valid.");
    console.error("Auth request failed", error instanceof Error ? error.message : "Unknown error");
    return errorResponse("Layanan akun sedang sibuk. Silakan coba lagi.", 503);
  }
}
