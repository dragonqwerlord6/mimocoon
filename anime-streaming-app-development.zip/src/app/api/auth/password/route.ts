import { cookies } from "next/headers";
import { after } from "next/server";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { emailTokens, passwordResetTokens, sessions, users } from "@/db/schema";
import { digest, errorResponse, hashPassword, rateLimit, sameOrigin } from "@/lib/auth";
import { passwordRecoveryAvailable, recoveryRequestedMessage, recoveryUnavailableMessage, sendPasswordRecovery } from "@/lib/password-recovery";

export const dynamic = "force-dynamic";

export async function GET() {
  const available = passwordRecoveryAvailable();
  return Response.json({
    available,
    state: available ? "configured" : "unconfigured",
    label: available ? "Konfigurasi tersedia" : "Belum terhubung",
    deliveryVerified: false,
    checkedAt: new Date().toISOString(),
    message: available
      ? "Konfigurasi email sudah tersedia di server. Kamu dapat meminta tautan pemulihan; penerimaan email di kotak masuk belum diuji."
      : recoveryUnavailableMessage,
  }, { headers: { "Cache-Control": "private, no-store, max-age=0" } });
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return errorResponse("Permintaan tidak diizinkan.", 403);
  try {
    const body = await request.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) return errorResponse("Format permintaan tidak valid.");
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
    if (body.action === "request") {
      if (!rateLimit(`recovery-request:${ip}`, 20)) return errorResponse("Terlalu banyak permintaan. Tunggu 15 menit sebelum mencoba lagi.", 429);
      const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return errorResponse("Masukkan alamat email yang valid.");
      if (!passwordRecoveryAvailable()) return errorResponse(recoveryUnavailableMessage, 503);
      if (!rateLimit(`recovery-email:${digest(email)}`, 3)) return errorResponse("Permintaan untuk alamat ini sudah diterima. Periksa email atau tunggu 15 menit sebelum mencoba lagi.", 429);
      // Identical responses and background delivery avoid revealing whether an account exists.
      after(async () => {
        try {
          const [user] = await db.select({ id: users.id, email: users.email }).from(users).where(eq(users.email, email)).limit(1);
          if (user && !await sendPasswordRecovery(user)) console.warn("Password recovery email could not be delivered.");
        } catch { console.error("Password recovery delivery failed."); }
      });
      return Response.json({ message: recoveryRequestedMessage }, { status: 202, headers: { "Cache-Control": "no-store" } });
    }
    if (body.action === "reset") {
      if (!rateLimit(`recovery-reset:${ip}`, 20)) return errorResponse("Terlalu banyak percobaan. Tunggu 15 menit sebelum mencoba lagi.", 429);
      if (typeof body.token !== "string" || !/^[a-f0-9]{64}$/.test(body.token)) return errorResponse("Tautan pemulihan tidak valid. Pilih Minta tautan baru.");
      const password = typeof body.password === "string" ? body.password : "";
      if (password.length < 8 || password.length > 128) return errorResponse("Sandi baru harus terdiri dari 8–128 karakter.");
      if (typeof body.confirmPassword !== "string" || body.confirmPassword !== password) return errorResponse("Kedua kata sandi belum sama. Ketik ulang sandi baru dengan benar.");
      const passwordHash = hashPassword(password);
      const changed = await db.transaction(async tx => {
        const [token] = await tx.delete(passwordResetTokens).where(and(eq(passwordResetTokens.tokenHash, digest(body.token)), gt(passwordResetTokens.expiresAt, new Date()))).returning();
        if (!token) return false;
        // Possession of the emailed link also proves control of this email address.
        await tx.update(users).set({ passwordHash, emailVerified: true }).where(eq(users.id, token.userId));
        await tx.delete(sessions).where(eq(sessions.userId, token.userId));
        await tx.delete(emailTokens).where(eq(emailTokens.userId, token.userId));
        return true;
      });
      if (!changed) return errorResponse("Tautan sudah digunakan atau kedaluwarsa. Pilih Minta tautan baru.");
      (await cookies()).delete("animeil_session");
      return Response.json({ message: "Kata sandi berhasil diperbarui. Semua sesi lama sudah diakhiri. Silakan masuk dengan sandi baru.", user: null }, { headers: { "Cache-Control": "no-store" } });
    }
    return errorResponse("Aksi tidak dikenal.");
  } catch (error) {
    if (error instanceof SyntaxError) return errorResponse("Format permintaan tidak valid.");
    console.error("Password recovery request could not be processed.");
    return errorResponse("Pemulihan belum dapat diproses. Silakan coba lagi sebentar.", 503);
  }
}
