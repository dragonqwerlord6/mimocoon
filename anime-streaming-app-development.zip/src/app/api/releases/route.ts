import { after } from "next/server";
import { and, asc, count, desc, eq, gt, lte } from "drizzle-orm";
import { db } from "@/db";
import { episodes } from "@/db/schema";
import { errorResponse, validAnimeId } from "@/lib/auth";
import { bearerMatches } from "@/lib/releases/provider";
import { fallbackAnime, parseEpisode, ReleaseInputError } from "@/lib/releases/validation";
import { persistEpisodes } from "@/lib/releases/persist";
import { releaseSyncStatus, syncEpisodes } from "@/lib/releases/sync";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams;
    const raw = params.get("animeId"); const animeId = Number(raw);
    if (raw !== null && !validAnimeId(animeId)) return errorResponse("Anime tidak valid.");
    const now = new Date(); const filter = raw !== null ? eq(episodes.animeId, animeId) : undefined;
    const [released, upcoming, releasedCount, scheduledCount, sync] = await Promise.all([
      db.select().from(episodes).where(and(filter, lte(episodes.releaseAt, now))).orderBy(raw !== null ? asc(episodes.number) : desc(episodes.releaseAt)).limit(raw !== null ? 2000 : 24),
      // Explicit projection: a future media URL must never reach the browser.
      db.select({ id: episodes.id, animeId: episodes.animeId, number: episodes.number, title: episodes.title, releaseAt: episodes.releaseAt, anime: episodes.anime }).from(episodes).where(and(filter, gt(episodes.releaseAt, now))).orderBy(asc(episodes.releaseAt)).limit(raw !== null ? 100 : 24),
      db.select({ value: count() }).from(episodes).where(and(filter, lte(episodes.releaseAt, now))),
      db.select({ value: count() }).from(episodes).where(and(filter, gt(episodes.releaseAt, now))),
      releaseSyncStatus(),
    ]);
    // Safe, throttled catch-up while the app is open. Cron/webhooks handle
    // ingestion when nobody is watching. Availability itself depends on time,
    // not on the browser or cron firing at the exact second.
    if (sync.configured && sync.state !== "running" && (!sync.nextCheckAt || Date.parse(sync.nextCheckAt) <= Date.now())) {
      after(async () => { try { await syncEpisodes(); } catch { console.error("Background episode sync could not run."); } });
    }
    return Response.json({
      episodes: released.map(row => ({ id: row.id, animeId: row.animeId, number: row.number, title: row.title, videoUrl: row.videoUrl, subtitleUrl: row.subtitleUrl, releaseAt: row.releaseAt, anime: row.anime || fallbackAnime(row.animeId), status: "released" })),
      upcoming: upcoming.map(row => ({ ...row, anime: row.anime || fallbackAnime(row.animeId), status: "scheduled" })),
      stats: { released: releasedCount[0]?.value || 0, scheduled: scheduledCount[0]?.value || 0 },
      serverTime: now.toISOString(), sync,
    }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch { return errorResponse("Informasi episode belum dapat dimuat.", 503); }
}

export async function POST(request: Request) {
  if (!process.env.RELEASE_WEBHOOK_SECRET?.trim()) return errorResponse("Koneksi penerbit berlisensi belum dikonfigurasi.", 503);
  if (!bearerMatches(request, process.env.RELEASE_WEBHOOK_SECRET)) return errorResponse("Akses penerbit ditolak.", 401);
  try {
    const body = await request.json();
    const parsed = parseEpisode(body, { allowImmediate: true });
    const { result, episodes: stored } = await persistEpisodes([parsed], { source: "webhook" });
    const ready = parsed.releaseAt <= new Date();
    return Response.json({ episode: stored[0], status: ready ? "released" : "scheduled", result, message: ready ? "Episode sudah waktunya tayang dan langsung tersedia." : "Episode disimpan dan akan terbuka otomatis saat waktu rilisnya tiba." }, { status: result.imported ? 201 : 200, headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    if (error instanceof ReleaseInputError) return errorResponse(error.message);
    if (error instanceof SyntaxError) return errorResponse("JSON episode tidak valid.");
    return errorResponse("Episode belum tersimpan. Silakan coba lagi.", 503);
  }
}
