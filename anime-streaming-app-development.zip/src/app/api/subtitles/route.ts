import { and, eq, lte } from "drizzle-orm";
import { db } from "@/db";
import { episodes } from "@/db/schema";
import { errorResponse, validUuid } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const id = new URL(request.url).searchParams.get("id");
    if (!validUuid(id)) return errorResponse("Episode tidak valid.");
    const [episode] = await db.select().from(episodes).where(and(eq(episodes.id, id), lte(episodes.releaseAt, new Date()))).limit(1);
    if (!episode) return errorResponse("Subtitle belum tersedia.", 404);
    const response = await fetch(episode.subtitleUrl, { signal: AbortSignal.timeout(10000), redirect: "error", next: { revalidate: 300 } });
    if (!response.ok) throw new Error("Unavailable subtitle");
    const subtitle = await response.text();
    if (subtitle.length > 2000000 || !subtitle.trimStart().startsWith("WEBVTT")) return errorResponse("Format subtitle harus WebVTT.", 502);
    return new Response(subtitle, { headers: { "Content-Type": "text/vtt; charset=utf-8", "Cache-Control": "public, max-age=300", "X-Content-Type-Options": "nosniff" } });
  } catch { return errorResponse("Subtitle belum dapat dimuat.", 502); }
}
