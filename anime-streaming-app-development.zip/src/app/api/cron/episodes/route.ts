import { bearerMatches } from "@/lib/releases/provider";
import { syncEpisodes } from "@/lib/releases/sync";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

async function handle(request: Request) {
  if (!process.env.CRON_SECRET?.trim()) return Response.json({ error: "Penjadwal belum dikonfigurasi." }, { status: 503 });
  if (!bearerMatches(request, process.env.CRON_SECRET)) return Response.json({ error: "Akses sinkronisasi ditolak." }, { status: 401 });
  try {
    const result = await syncEpisodes({ force: new URL(request.url).searchParams.get("force") === "1" });
    return Response.json(result, { status: result.state === "error" ? 502 : result.state === "unconfigured" ? 503 : 200, headers: { "Cache-Control": "private, no-store" } });
  } catch {
    return Response.json({ error: "Sinkronisasi belum dapat dijalankan. Periksa koneksi database." }, { status: 503 });
  }
}
export const GET = handle;
export const POST = handle;
