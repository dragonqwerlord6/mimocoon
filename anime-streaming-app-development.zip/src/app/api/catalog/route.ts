import { catalog, genreTranslations, days, type Anime } from "@/lib/catalog";
import { errorResponse, validAnimeId } from "@/lib/auth";

type JikanAnime = {
  mal_id: number; title: string; title_english: string | null; images: { jpg: { large_image_url: string } };
  score: number | null; episodes: number | null; year: number | null; airing: boolean; type: string;
  genres: { name: string }[]; trailer: { youtube_id: string | null }; broadcast: { time: string | null; day: string | null }; rating: string | null;
};
function normalize(a: JikanAnime): Anime {
  const seed = catalog.find(item => item.id === a.mal_id);
  const title = a.title_english || a.title.replace(/[\u3040-\u30ff\u3400-\u9fff]/g, "").trim() || `Anime #${a.mal_id}`;
  return {
    id: a.mal_id, title, image: seed?.image || a.images.jpg.large_image_url,
    score: a.score || 0, episodes: a.episodes || 0, year: a.year || new Date().getFullYear(),
    genres: a.genres.map(g => genreTranslations[g.name]).filter(Boolean).slice(0, 3),
    description: seed?.description || `Temukan kisah ${title}. Informasi episode dan jadwal mengikuti pengumuman resmi. Simpan ke daftar tontonanmu untuk mengikuti pembaruannya.`,
    status: a.airing ? "Tayang" : "Tamat", trailer: a.trailer?.youtube_id || "", color: seed?.color || "#8297b0",
    time: a.broadcast?.time || undefined, day: a.broadcast?.day || undefined,
  };
}
export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const kind = params.get("kind") || "popular";
  const q = (params.get("q") || "").trim().slice(0, 100);
  const day = params.get("day") || "monday";
  const id = Number(params.get("id"));
  if (kind === "schedule" && !days.some(d => d.value === day)) return errorResponse("Hari tidak valid.");
  if (kind === "detail" && !validAnimeId(id)) return errorResponse("Anime tidak valid.");
  const endpoint = kind === "detail" ? `anime/${id}/full` : kind === "schedule" ? `schedules?filter=${day}&sfw=true&limit=25` : kind === "search" && q ? `anime?q=${encodeURIComponent(q)}&sfw=true&limit=24&genres_exclude=12,49` : kind === "season" ? "seasons/now?sfw=true&limit=24" : "top/anime?filter=bypopularity&sfw=true&limit=24";
  try {
    const response = await fetch(`https://api.jikan.moe/v4/${endpoint}`, { next: { revalidate: 900 }, signal: AbortSignal.timeout(6500) });
    if (!response.ok) throw new Error("Catalog unavailable");
    const json = await response.json();
    if (kind === "detail") return Response.json({ anime: normalize(json.data), live: true });
    const seen = new Set<number>();
    const data = (json.data as JikanAnime[]).filter(a => {
      if (seen.has(a.mal_id) || a.rating?.startsWith("Rx") || a.rating?.startsWith("R+")) return false;
      seen.add(a.mal_id); return true;
    }).map(normalize);
    return Response.json({ anime: data, live: true, timezone: "JST", updatedAt: new Date().toISOString() });
  } catch {
    if (kind === "detail") return Response.json({ anime: catalog.find(a => a.id === id) || null, live: false });
    const fallback = kind === "schedule" ? [] : q ? catalog.filter(a => `${a.title} ${a.genres.join(" ")}`.toLowerCase().includes(q.toLowerCase())) : catalog;
    return Response.json({ anime: fallback, live: false, message: kind === "schedule" ? "Sumber jadwal belum dapat dihubungi. Coba lagi sebentar." : "Menampilkan koleksi pilihan. Katalog langsung sedang tidak tersedia." });
  }
}
