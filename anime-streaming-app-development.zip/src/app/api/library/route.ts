import { and, desc, eq, gt, isNotNull, sql } from "drizzle-orm";
import { db } from "@/db";
import { watchlist, history, episodes, notifications } from "@/db/schema";
import { currentUser, errorResponse, sameOrigin, validAnimeId, rateLimit } from "@/lib/auth";
import { catalog, type Anime } from "@/lib/catalog";

export async function GET() {
  try {
    const user = await currentUser();
    if (!user) return Response.json({ saved: [], history: [] });
    const [saved, watched] = await Promise.all([
      db.select().from(watchlist).where(eq(watchlist.userId, user.id)).orderBy(desc(watchlist.createdAt)),
      db.select().from(history).where(eq(history.userId, user.id)).orderBy(desc(history.updatedAt)).limit(60),
    ]);
    return Response.json({ saved: saved.map(r => r.anime), history: watched });
  } catch { return errorResponse("Koleksi belum dapat dimuat.", 503); }
}
function parseAnime(value: unknown): Anime | null {
  if (!value || typeof value !== "object") return null;
  const a = value as Partial<Anime>;
  if (!validAnimeId(a.id) || typeof a.title !== "string" || typeof a.image !== "string") return null;
  const cached = catalog.find(item => item.id === a.id);
  if (cached) return cached;
  if ((!a.image.startsWith("https://") && !/^\/images\/[a-zA-Z0-9._-]+$/.test(a.image)) || a.image.length > 1000) return null;
  return { id: a.id, title: a.title.slice(0, 200), image: a.image, score: Math.min(10, Math.max(0, Number(a.score) || 0)), episodes: Math.min(10000, Math.max(0, Number(a.episodes) || 0)), year: Number(a.year) || 2026, genres: Array.isArray(a.genres) ? a.genres.filter(g => typeof g === "string").map(g => g.slice(0, 40)).slice(0, 4) : [], description: typeof a.description === "string" ? a.description.slice(0, 2000) : "", status: a.status === "Tayang" ? "Tayang" : "Tamat", trailer: typeof a.trailer === "string" && /^[a-zA-Z0-9_-]{11}$/.test(a.trailer) ? a.trailer : "", color: "#7888ad" };
}
export async function POST(request: Request) {
  if (!sameOrigin(request)) return errorResponse("Permintaan tidak diizinkan.", 403);
  try {
    const user = await currentUser();
    if (!user) return errorResponse("Masuk untuk menyimpan anime.", 401);
    if (!rateLimit(`library:${user.id}`, 300)) return errorResponse("Coba lagi sebentar.", 429);
    const body = await request.json(); const anime = parseAnime(body.anime);
    if (!anime) return errorResponse("Data anime tidak valid.");
    if (body.action === "save") {
      const saved = await db.transaction(async tx => {
        await tx.execute(sql`select pg_advisory_xact_lock(73201, 191)`);
        const removed = await tx.delete(watchlist).where(and(eq(watchlist.userId, user.id), eq(watchlist.animeId, anime.id))).returning();
        if (removed.length) {
          await tx.delete(notifications).where(and(eq(notifications.userId, user.id), eq(notifications.animeId, anime.id), isNotNull(notifications.episodeId), gt(notifications.visibleAt, new Date())));
          return false;
        }
        await tx.insert(watchlist).values({ userId: user.id, animeId: anime.id, anime }).onConflictDoNothing();
        const upcoming = await tx.select().from(episodes).where(and(eq(episodes.animeId, anime.id), gt(episodes.releaseAt, new Date()))).limit(2000);
        for (let i = 0; i < upcoming.length; i += 500) await tx.insert(notifications).values(upcoming.slice(i, i + 500).map(ep => ({ userId: user.id, animeId: anime.id, anime, episodeId: ep.id, title: `Episode ${ep.number} sudah rilis!`, body: `${anime.title} — ${ep.title}`, visibleAt: ep.releaseAt }))).onConflictDoNothing({ target: [notifications.userId, notifications.episodeId] });
        return true;
      });
      return Response.json({ saved });
    }
    if (body.action === "progress") {
      const progress = Math.max(0, Math.min(86400, Math.floor(Number(body.progress) || 0)));
      const duration = Math.max(0, Math.min(86400, Math.floor(Number(body.duration) || 0)));
      const episode = Math.max(0, Math.min(10000, Math.floor(Number(body.episode) || 0)));
      await db.insert(history).values({ userId: user.id, animeId: anime.id, anime, progress, duration, episode }).onConflictDoUpdate({ target: [history.userId, history.animeId], set: { progress, duration, episode, updatedAt: new Date() } });
      return Response.json({ success: true });
    }
    return errorResponse("Aksi tidak dikenal.");
  } catch { return errorResponse("Koleksi belum tersimpan. Silakan coba lagi.", 503); }
}
