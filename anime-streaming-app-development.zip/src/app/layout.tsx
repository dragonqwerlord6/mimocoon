import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "animeil.al — Temukan cerita. Rasakan dunianya.",
  description: "Temukan anime favorit, jadwal rilis, dan komunitasmu. Antarmuka bahasa Indonesia, audio asli, serta subtitle Indonesia untuk episode berlisensi.",
  applicationName: "animeil.al",
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "animeil.al" },
  icons: { icon: "/icon.png", apple: "/icon.png" },
  openGraph: { title: "animeil.al — Cerita tanpa batas", description: "Satu tempat untuk anime favorit dan teman satu cerita.", locale: "id_ID", type: "website" },
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#0b0e15" };
export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="id"><body><a href="#main-content" className="skip-link">Langsung ke konten</a>{children}</body></html>;
}
