import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    id: "/",
    name: "animeil.al — Cerita tanpa batas",
    short_name: "animeil.al",
    description: "Anime favorit, jadwal rilis, dan teman satu cerita. Berbahasa Indonesia, dengan audio asli dan subtitle untuk episode berlisensi.",
    lang: "id",
    start_url: "/",
    scope: "/",
    display: "standalone",
    background_color: "#0b0e15",
    theme_color: "#0f121b",
    categories: ["entertainment", "social"],
    icons: [
      { src: "/images/app-icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/images/app-icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/images/app-icon-maskable.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
