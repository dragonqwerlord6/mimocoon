import AnimeApp from "@/components/anime-app";

export default function HomePage() {
  return <AnimeApp />;
}
