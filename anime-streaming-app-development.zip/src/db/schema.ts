import { pgTable, uuid, varchar, text, boolean, timestamp, integer, primaryKey, uniqueIndex, index, jsonb, type AnyPgColumn } from "drizzle-orm/pg-core";
import type { Anime } from "@/lib/catalog";

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 40 }).notNull(),
  email: varchar("email", { length: 254 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  emailVerified: boolean("email_verified").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
export const sessions = pgTable("sessions", {
  tokenHash: text("token_hash").primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});
export const emailTokens = pgTable("email_tokens", {
  tokenHash: text("token_hash").primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});
export const passwordResetTokens = pgTable("password_reset_tokens", {
  tokenHash: text("token_hash").primaryKey(),
  userId: uuid("user_id").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});
export const watchlist = pgTable("watchlist", {
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  animeId: integer("anime_id").notNull(),
  anime: jsonb("anime").$type<Anime>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.userId, t.animeId] })]);
export const history = pgTable("watch_history", {
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  animeId: integer("anime_id").notNull(),
  anime: jsonb("anime").$type<Anime>().notNull(),
  episode: integer("episode").notNull().default(0),
  progress: integer("progress").notNull().default(0),
  duration: integer("duration").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.userId, t.animeId] })]);
export const ratings = pgTable("ratings", {
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  animeId: integer("anime_id").notNull(),
  score: integer("score").notNull(),
}, (t) => [primaryKey({ columns: [t.userId, t.animeId] })]);
export const likes = pgTable("anime_likes", {
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  animeId: integer("anime_id").notNull(),
}, (t) => [primaryKey({ columns: [t.userId, t.animeId] })]);
export const comments = pgTable("comments", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  animeId: integer("anime_id").notNull(),
  parentId: uuid("parent_id").references((): AnyPgColumn => comments.id, { onDelete: "cascade" }),
  body: varchar("body", { length: 2000 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
export const commentLikes = pgTable("comment_likes", {
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  commentId: uuid("comment_id").notNull().references(() => comments.id, { onDelete: "cascade" }),
}, (t) => [primaryKey({ columns: [t.userId, t.commentId] })]);
export const notifications = pgTable("notifications", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 150 }).notNull(),
  body: text("body").notNull(),
  animeId: integer("anime_id").notNull(),
  anime: jsonb("anime").$type<Anime>(),
  commentId: uuid("comment_id"),
  episodeId: uuid("episode_id").references(() => episodes.id, { onDelete: "cascade" }),
  read: boolean("read").notNull().default(false),
  visibleAt: timestamp("visible_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("notification_episode_user").on(t.userId, t.episodeId)]);
export const episodes = pgTable("episodes", {
  id: uuid("id").defaultRandom().primaryKey(),
  animeId: integer("anime_id").notNull(),
  number: integer("number").notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  videoUrl: text("video_url").notNull(),
  subtitleUrl: text("subtitle_url").notNull(),
  releaseAt: timestamp("release_at", { withTimezone: true }).notNull(),
  anime: jsonb("anime").$type<Anime>(),
  source: varchar("source", { length: 30 }).notNull().default("webhook"),
  syncedAt: timestamp("synced_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("episode_anime_number").on(t.animeId, t.number), index("episode_release_at_idx").on(t.releaseAt)]);

export const episodeSyncState = pgTable("episode_sync_state", {
  key: varchar("key", { length: 40 }).primaryKey(),
  sourceKey: text("source_key"),
  state: varchar("state", { length: 20 }).notNull().default("waiting"),
  runningToken: uuid("running_token"),
  leaseUntil: timestamp("lease_until", { withTimezone: true }),
  cursor: text("cursor"),
  lastAttemptAt: timestamp("last_attempt_at", { withTimezone: true }),
  lastSuccessAt: timestamp("last_success_at", { withTimezone: true }),
  nextAttemptAt: timestamp("next_attempt_at", { withTimezone: true }),
  lastError: varchar("last_error", { length: 500 }),
  imported: integer("imported").notNull().default(0),
  updated: integer("updated").notNull().default(0),
  unchanged: integer("unchanged").notNull().default(0),
  rejected: integer("rejected").notNull().default(0),
});
