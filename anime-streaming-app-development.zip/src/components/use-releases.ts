"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api, errorMessage } from "@/lib/client";
import type { ReleaseResponse } from "@/lib/releases/types";

export function useReleases(animeId?: number) {
  const [data, setData] = useState<ReleaseResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [now, setNow] = useState(Date.now());
  const mounted = useRef(false);
  const activeRequest = useRef<AbortController | null>(null);
  const serverOffset = useRef(0);
  const url = animeId ? `/api/releases?animeId=${animeId}` : "/api/releases";
  const refresh = useCallback(async () => {
    if (!mounted.current || activeRequest.current || document.visibilityState === "hidden") return;
    const controller = new AbortController(); activeRequest.current = controller;
    setRefreshing(true);
    try {
      const result = await api<ReleaseResponse>(url, { cache: "no-store", signal: AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]) });
      if (!mounted.current || controller.signal.aborted) return;
      const serverTime = Date.parse(result.serverTime);
      serverOffset.current = Number.isFinite(serverTime) ? serverTime - Date.now() : 0;
      setNow(Date.now() + serverOffset.current);
      setData({ ...result, episodes: result.episodes || [], upcoming: result.upcoming || [] });
      setError("");
    } catch (e) { if (mounted.current && !controller.signal.aborted) setError(errorMessage(e)); }
    finally {
      if (activeRequest.current === controller) activeRequest.current = null;
      if (mounted.current && !controller.signal.aborted) { setLoading(false); setRefreshing(false); }
    }
  }, [url]);
  useEffect(() => {
    mounted.current = true; void refresh();
    const timer = setInterval(() => { void refresh(); }, 20000);
    const onReturn = () => { void refresh(); };
    window.addEventListener("focus", onReturn); document.addEventListener("visibilitychange", onReturn);
    return () => { mounted.current = false; activeRequest.current?.abort(); activeRequest.current = null; clearInterval(timer); window.removeEventListener("focus", onReturn); document.removeEventListener("visibilitychange", onReturn); };
  }, [refresh]);
  const nextRelease = data?.upcoming[0]?.releaseAt;
  useEffect(() => {
    if (!nextRelease) return;
    const tick = setInterval(() => setNow(Date.now() + serverOffset.current), 1000);
    const remaining = Date.parse(nextRelease) - Date.now() - serverOffset.current;
    const releaseTimer = setTimeout(() => { void refresh(); }, Math.min(2147483647, Math.max(1500, remaining + 150)));
    return () => { clearInterval(tick); clearTimeout(releaseTimer); };
  }, [nextRelease, data?.serverTime, refresh]);
  return { data, loading, refreshing, error, refresh, now };
}

export function releaseTime(value: string) {
  return `${new Date(value).toLocaleString("id-ID", { timeZone: "Asia/Jakarta", day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" })} WIB`;
}
export function releaseCountdown(value: string, now: number) {
  const remaining = Math.ceil((Date.parse(value) - now) / 1000);
  if (remaining <= 0) return "Memeriksa ketersediaan…";
  const days = Math.floor(remaining / 86400);
  const hours = Math.floor(remaining % 86400 / 3600);
  const minutes = Math.floor(remaining % 3600 / 60);
  const seconds = remaining % 60;
  if (days) return `${days} hari ${hours} jam lagi`;
  if (hours) return `${hours} jam ${minutes} menit lagi`;
  return `${minutes} menit ${String(seconds).padStart(2, "0")} detik lagi`;
}
