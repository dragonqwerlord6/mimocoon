"use client";

import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";
import { Heart, Star, Send, MessageCircle, Reply, ThumbsUp, X, LoaderCircle, RefreshCw } from "lucide-react";
import { Avatar, VerifiedBadge } from "./shared";
import { api, post, relativeTime, errorMessage } from "@/lib/client";
import type { PublicUser, CommentData } from "@/lib/catalog";

type DiscussionData = { comments: CommentData[]; stats: { likes: number; rating: number; votes: number }; liked: boolean; score: number };
export default function Discussion({ animeId, user, needLogin, toast, highlightId }: { animeId: number; user: PublicUser | null; needLogin: () => void; toast: (text: string, error?: boolean) => void; highlightId?: string }) {
  const [data, setData] = useState<DiscussionData>({ comments: [], stats: { likes: 0, rating: 0, votes: 0 }, liked: false, score: 0 });
  const [loading, setLoading] = useState(true); const [error, setError] = useState("");
  const [text, setText] = useState(""); const [reply, setReply] = useState<CommentData | null>(null);
  const [busy, setBusy] = useState(""); const [hover, setHover] = useState(0); const [sort, setSort] = useState("new");
  const input = useRef<HTMLTextAreaElement>(null);
  const load = useCallback(async () => { try { const result = await api<DiscussionData>(`/api/community?animeId=${animeId}`); setData(result); setError(""); } catch (e) { setError(errorMessage(e)); } finally { setLoading(false); } }, [animeId]);
  useEffect(() => { load(); const timer = setInterval(load, 20000); return () => clearInterval(timer); }, [load, user?.id]);
  useEffect(() => { if (!loading && highlightId) setTimeout(() => document.getElementById(`comment-${highlightId}`)?.scrollIntoView({ behavior: "smooth", block: "center" }), 120); }, [loading, highlightId]);
  async function interact(action: string, extra: Record<string, unknown> = {}) {
    if (!user) { needLogin(); return; }
    if (busy) return;
    setBusy(action);
    try { await post("/api/community", { action, animeId, ...extra }); await load(); if (action === "rate") toast("Ratingmu berhasil disimpan. Terima kasih!"); }
    catch (e) { toast(errorMessage(e), true); } finally { setBusy(""); }
  }
  async function submit(event: FormEvent) {
    event.preventDefault(); if (!user) { needLogin(); return; } if (!text.trim() || busy) return;
    setBusy("comment");
    try { await post("/api/community", { action: "comment", animeId, text, parentId: reply?.id }); setText(""); setReply(null); await load(); toast(reply ? "Balasan terkirim. Penulis akan mendapat notifikasi." : "Komentarmu berhasil dikirim."); }
    catch (e) { toast(errorMessage(e), true); } finally { setBusy(""); }
  }
  function renderComment(comment: CommentData, nested = false) {
    return <article key={comment.id} id={`comment-${comment.id}`} className={`comment ${nested ? "comment-reply" : ""} ${highlightId === comment.id ? "highlight-comment" : ""}`}>
      <Avatar name={comment.name} verified={comment.verified} />
      <div className="comment-content"><div className="comment-heading"><strong>{comment.name}</strong><VerifiedBadge verified={comment.verified} />{user?.id === comment.userId && <span className="you-tag">Kamu</span>}<time dateTime={comment.createdAt}>{relativeTime(comment.createdAt)}</time></div><p>{comment.body}</p><div className="comment-actions"><button className={comment.liked ? "is-liked" : ""} disabled={!!busy} onClick={() => interact("commentLike", { commentId: comment.id })} aria-label={comment.liked ? "Batal menyukai komentar" : "Sukai komentar"}><ThumbsUp size={13} />{comment.likes || "Suka"}</button><button onClick={() => { if (!user) { needLogin(); return; } setReply(comment); input.current?.focus(); input.current?.scrollIntoView({ behavior: "smooth", block: "center" }); }}><Reply size={14} />Balas</button></div></div>
    </article>;
  }
  const roots = data.comments.filter(c => !c.parentId).sort((a, b) => sort === "new" ? +new Date(b.createdAt) - +new Date(a.createdAt) : +new Date(a.createdAt) - +new Date(b.createdAt));
  return <div className="discussion">
    {animeId !== 0 && <div className="engagement"><button className={`button like-button ${data.liked ? "is-liked" : ""}`} disabled={!!busy} onClick={() => interact("like")}><Heart size={18} fill={data.liked ? "currentColor" : "none"} />{data.liked ? "Disukai" : "Suka"}{data.stats.likes > 0 && <span>{data.stats.likes}</span>}</button><div className="rating-widget"><span>Bagaimana ceritanya?</span><div className="rating-stars" onMouseLeave={() => setHover(0)}>{[2, 4, 6, 8, 10].map(value => <button key={value} disabled={!!busy} onMouseEnter={() => setHover(value)} onFocus={() => setHover(value)} onBlur={() => setHover(0)} onClick={() => interact("rate", { score: value })} aria-label={`Beri rating ${value} dari 10`} aria-pressed={data.score === value}><Star size={21} fill={(hover || data.score) >= value ? "currentColor" : "none"} className={(hover || data.score) >= value ? "star-filled" : ""} /></button>)}</div><small>{data.stats.votes ? `${data.stats.rating.toFixed(1)}/10 · ${data.stats.votes} penilaian` : "Jadi yang pertama menilai"}</small></div></div>}
    <div className="discussion-heading"><h3><MessageCircle size={19} />{animeId ? "Obrolan penggemar" : "Obrolan komunitas"}<span className="count-chip">{data.comments.length}</span></h3><select aria-label="Urutkan komentar" value={sort} onChange={e => setSort(e.target.value)}><option value="new">Terbaru</option><option value="old">Terlama</option></select></div>
    <form className="comment-form" onSubmit={submit}><Avatar name={user?.name} verified={user?.verified} /><div className="comment-input-area">{reply && <div className="reply-label"><Reply size={13} />Membalas {reply.name}<button type="button" onClick={() => setReply(null)} aria-label="Batalkan balasan"><X size={14} /></button></div>}<textarea ref={input} aria-label={reply ? "Tulis balasan" : "Tulis komentar"} placeholder={user ? "Bagikan pendapatmu… tanpa spoiler, ya!" : "Punya cerita? Masuk dan ikut ngobrol di sini…"} value={text} onChange={e => setText(e.target.value)} maxLength={2000} rows={3} /><div className="comment-form-bottom"><span>{text.length ? `${text.length}/2.000` : "Saling menghargai, hindari spoiler."}</span><button className="button button-primary button-small" disabled={!!busy || (!!user && !text.trim())}>{busy === "comment" ? <LoaderCircle size={14} className="spin" /> : <Send size={14} />}{user ? (reply ? "Kirim balasan" : "Kirim komentar") : "Masuk untuk ngobrol"}</button></div></div></form>
    {error && <div className="inline-error" role="alert"><span>{error}</span><button onClick={load}><RefreshCw size={14} />Coba lagi</button></div>}
    {loading ? <div className="comments-loading"><LoaderCircle className="spin" size={22} /><span>Memuat obrolan…</span></div> : !data.comments.length && !error ? <div className="comments-empty"><MessageCircle size={28} strokeWidth={1.4} /><h4>Obrolan seru dimulai darimu.</h4><p>Jadi yang pertama berbagi kesan dan teori. Kami siap mendengar!</p></div> : <div className="comments-list">{roots.map(c => <div key={c.id} className="comment-thread">{renderComment(c)}{data.comments.filter(r => r.parentId === c.id).sort((a, b) => +new Date(a.createdAt) - +new Date(b.createdAt)).map(r => renderComment(r, true))}</div>)}</div>}
    {data.comments.length >= 150 && <p className="muted small-text">Menampilkan 150 komentar terbaru.</p>}
  </div>;
}
