"use client";

import { useEffect, useRef, useState } from "react";
import Hls from "hls.js";
import { Play, Bookmark, Check, Star, Headphones, Captions, ExternalLink, Film, LoaderCircle, RefreshCw, ShieldCheck, CalendarClock } from "lucide-react";
import { Modal } from "./shared";
import Discussion from "./discussion";
import { api } from "@/lib/client";
import type { Anime, Episode, HistoryData, PublicUser } from "@/lib/catalog";
import { useReleases } from "./use-releases";
import { UpcomingEpisodes } from "./release-board";

type Props = { anime: Anime; user: PublicUser | null; saved: boolean; onClose: () => void; onSave: (anime: Anime) => void; needLogin: () => void; toast: (text: string, error?: boolean) => void; onProgress: (anime: Anime, episode: number, progress: number, duration: number) => void; history?: HistoryData; highlightId?: string };
function EpisodeVideo({ episode, start, poster, onProgress }: { episode: Episode; start: number; poster: string; onProgress: (progress: number, duration: number) => void }) {
  const ref = useRef<HTMLVideoElement>(null); const callback = useRef(onProgress); callback.current = onProgress;
  const lastSave = useRef(0); const [error, setError] = useState(false); const [retry, setRetry] = useState(0);
  useEffect(() => {
    const video = ref.current; if (!video) return;
    setError(false); let hls: Hls | null = null;
    if (/\.m3u8(?:\?|$)/i.test(episode.videoUrl) && Hls.isSupported()) {
      hls = new Hls(); hls.loadSource(episode.videoUrl); hls.attachMedia(video);
      hls.on(Hls.Events.ERROR, (_, data) => { if (data.fatal) setError(true); });
    } else video.src = episode.videoUrl;
    const onReady = () => { if (start > 0 && Number.isFinite(video.duration)) video.currentTime = Math.min(start, Math.max(0, video.duration - 2)); };
    video.addEventListener("loadedmetadata", onReady);
    return () => { video.removeEventListener("loadedmetadata", onReady); if (video.currentTime > 0) callback.current(video.currentTime, video.duration || 0); hls?.destroy(); video.pause(); };
  }, [episode.id, episode.videoUrl, retry]);
  const save = () => { const v = ref.current; if (v && Number.isFinite(v.duration)) callback.current(v.currentTime, v.duration); };
  return <div className="episode-video"><video ref={ref} controls playsInline poster={poster} onError={() => setError(true)} onPause={save} onEnded={save} onTimeUpdate={() => { if (Date.now() - lastSave.current > 15000) { lastSave.current = Date.now(); save(); } }}><track key={episode.id} kind="subtitles" src={`/api/subtitles?id=${episode.id}`} srcLang="id" label="Bahasa Indonesia" default />Browsermu belum mendukung pemutar video.</video>{error && <div className="video-error"><Film size={30} /><h3>Video belum dapat diputar</h3><p>Sumber video mungkin sedang sibuk. Coba lagi sebentar.</p><button className="button button-primary" onClick={() => setRetry(retry + 1)}><RefreshCw size={16} />Coba lagi</button></div>}</div>;
}
export default function WatchModal({ anime, user, saved, onClose, onSave, needLogin, toast, onProgress, history, highlightId }: Props) {
  const { data, loading, error: loadError, refreshing, refresh: loadEpisodes, now } = useReleases(anime.id);
  const episodes = data?.episodes || [];
  const upcoming = data?.upcoming || [];
  const [mode, setMode] = useState<"preview" | "trailer" | "episode">("preview");
  const [episode, setEpisode] = useState<Episode | null>(null);
  const [tab, setTab] = useState(highlightId ? "comments" : "episodes");
  const [trailer, setTrailer] = useState(anime.trailer);
  const cover = anime.id === 52991 ? "/images/hero.webp" : anime.image;
  useEffect(() => {
    let active = true;
    api<{ anime: Anime | null }>(`/api/catalog?kind=detail&id=${anime.id}`).then(result => { if (active && result.anime?.trailer) setTrailer(result.anime.trailer); }).catch(() => {});
    return () => { active = false; };
  }, [anime.id]);
  useEffect(() => {
    if (mode !== "episode" || !episode || !data) return;
    const latest = data.episodes.find(item => item.id === episode.id);
    if (!latest) { setEpisode(null); setMode("preview"); toast("Jadwal episode diperbarui oleh penerbit. Video belum tersedia saat ini."); }
    else if (latest.videoUrl !== episode.videoUrl || latest.subtitleUrl !== episode.subtitleUrl) setEpisode(latest);
  }, [data, episode, mode, toast]);
  function playTrailer() { if (!trailer) { toast("Trailer resmi belum tersedia untuk judul ini."); return; } setMode("trailer"); onProgress(anime, 0, 0, 0); }
  function playEpisode(item: Episode) { setEpisode(item); setMode("episode"); onProgress(anime, item.number, history?.episode === item.number ? history.progress : 0, history?.episode === item.number ? history.duration : 0); }
  const nextEpisode = episodes.find(item => item.number === history?.episode) || episodes[0];
  return <Modal title={anime.title} onClose={onClose} className="watch-modal">
    <div className="watch-screen">
      {mode === "trailer" ? <iframe src={`https://www.youtube-nocookie.com/embed/${trailer}?autoplay=1&rel=0&hl=id&cc_lang_pref=id&cc_load_policy=1`} title={`Trailer resmi ${anime.title}`} allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" /> : mode === "episode" && episode ? <EpisodeVideo episode={episode} start={history?.episode === episode.number ? history.progress : 0} poster={cover} onProgress={(progress, duration) => onProgress(anime, episode.number, progress, duration)} /> : <>
        <img className={`watch-cover ${anime.id === 52991 ? "" : "portrait-cover"}`} src={cover} alt="" /><div className="watch-screen-shade" />
        <div className="watch-preview"><span className="eyebrow"><Film size={14} />{nextEpisode ? "EPISODE SIAP DITONTON" : "KENALI CERITANYA"}</span><h2>{anime.title}</h2>
          {nextEpisode ? <button className="button button-primary" onClick={() => playEpisode(nextEpisode)}><Play size={17} fill="currentColor" />Tonton episode {nextEpisode.number}</button> : <button className="button button-primary" onClick={playTrailer} disabled={!trailer}><Play size={17} fill="currentColor" />{trailer ? "Putar trailer resmi" : "Trailer belum tersedia"}</button>}
        </div><span className="preview-label">{nextEpisode ? "SUDAH RILIS · SUBTITLE INDONESIA" : "CUPLIKAN RESMI"}</span>
      </>}
    </div>
    <div className="watch-body">
      <div className="watch-title-row"><div><div className="watch-kicker">{mode === "episode" && episode ? `EPISODE ${episode.number} · ${episode.title}` : "TEMUKAN CERITA FAVORITMU"}</div><h2>{anime.title}</h2></div><button className={`button button-secondary ${saved ? "saved-button" : ""}`} onClick={() => onSave(anime)}>{saved ? <Check size={17} /> : <Bookmark size={17} />}{saved ? "Tersimpan" : "Daftar saya"}</button></div>
      <div className="watch-meta"><span className="score"><Star size={15} fill="currentColor" />{anime.score ? anime.score.toFixed(1) : "—"}<small>MyAnimeList</small></span><span>{anime.year}</span><span>{anime.episodes ? `${anime.episodes} episode` : "Sedang tayang"}</span><span>{anime.status}</span><span className="language-label"><Headphones size={14} />Audio asli</span></div>
      <p className="watch-description">{anime.description}</p><div className="genre-tags">{anime.genres.map(genre => <span key={genre}>{genre}</span>)}</div>
      {mode === "trailer" && <p className="trailer-note">Subtitle trailer mengikuti ketersediaan kanal resmi. <a href={`https://www.youtube.com/watch?v=${trailer}`} target="_blank" rel="noreferrer">Buka di YouTube <ExternalLink size={11} /></a></p>}
      <div className="detail-tabs"><button className={tab === "episodes" ? "active" : ""} onClick={() => setTab("episodes")}>Daftar episode<span>{episodes.length}</span></button><button className={tab === "comments" ? "active" : ""} onClick={() => setTab("comments")}>Komentar & rating</button><span className="subtitle-indicator"><span className="indonesia-flag" />Subtitle Indonesia</span></div>
      {tab === "episodes" ? <section className="episode-section">
        {loading ? <div className="comments-loading"><LoaderCircle className="spin" size={22} />Memeriksa episode…</div> : <>
          {loadError && <div className="inline-error" role="alert"><span>{loadError}</span><button onClick={() => { void loadEpisodes(); }} disabled={refreshing}><RefreshCw size={14} />Coba lagi</button></div>}
          {episodes.length > 0 && <><div className="upcoming-heading"><Play size={15} /><h3>Sudah rilis · {data?.stats.released || episodes.length} episode</h3></div><div className="episodes-grid">{episodes.map(ep => <button key={ep.id} className={`episode-item ${episode?.id === ep.id && mode === "episode" ? "active" : ""}`} onClick={() => playEpisode(ep)}><span className="episode-number">{String(ep.number).padStart(2, "0")}</span><div><strong>{ep.title}</strong><small><Captions size={12} />Subtitle Indonesia</small></div><Play size={17} /></button>)}</div></>}
          <UpcomingEpisodes episodes={upcoming} now={now} />
          {!episodes.length && !upcoming.length && !loadError && <div className="no-episodes"><span className="no-episodes-icon"><CalendarClock size={26} /></span><div><h3>Episode penuh belum tersedia.</h3><p>Simpan anime ini untuk mendapat notifikasi saat episode berlisensi tersedia. Sambil menunggu, nikmati trailer resminya.</p><a className="official-link" href={`https://www.crunchyroll.com/search?q=${encodeURIComponent(anime.title)}`} target="_blank" rel="noreferrer">Cari di layanan resmi <ExternalLink size={13} /></a></div></div>}
          {data?.sync && <div className="license-note"><RefreshCw size={14} /><span>{data.sync.label}. Daftar diperbarui otomatis saat aplikasi terbuka; episode yang sudah waktunya rilis tidak ditunda lagi.</span></div>}
        </>}
        <div className="license-note"><ShieldCheck size={15} />Kami mendukung kreator. Episode penuh hanya tersedia dari penyedia berlisensi, sesuai wilayah penayangan.</div>
        <button className="discussion-jump" onClick={() => setTab("comments")}>Sudah punya pendapat? Beri rating dan ikut ngobrol <span>→</span></button>
      </section> : <Discussion key={anime.id} animeId={anime.id} user={user} needLogin={needLogin} toast={toast} highlightId={highlightId} />}
    </div>
  </Modal>;
}
