"use client";

import { useEffect, useState, type FormEvent, type KeyboardEvent } from "react";
import { ArrowLeft, ArrowRight, CircleCheck, Eye, EyeOff, Info, KeyRound, LoaderCircle, LockKeyhole, Mail, ShieldCheck, UserRound } from "lucide-react";
import { Modal } from "./shared";
import { api, post, errorMessage } from "@/lib/client";
import type { PublicUser } from "@/lib/catalog";
import "./auth-modal.css";

type AuthMode = "login" | "register" | "forgot" | "reset" | "sent";
type Props = {
  onClose: () => void;
  onSuccess: (user: PublicUser, message: string) => void;
  onHelp: () => void;
  resetToken?: string;
  onResetComplete?: () => void;
};
const titles: Record<AuthMode, string> = {
  login: "Masuk ke animeil.al",
  register: "Buat akun animeil.al",
  forgot: "Lupa kata sandi",
  reset: "Atur ulang kata sandi",
  sent: "Permintaan pemulihan akun",
};
const headings: Record<AuthMode, string> = {
  login: "Senang kamu kembali.",
  register: "Mulai cerita barumu.",
  forgot: "Lupa sandi? Tenang dulu.",
  reset: "Buat sandi yang baru.",
  sent: "Periksa emailmu.",
};
const descriptions: Record<AuthMode, string> = {
  login: "Gunakan email dan sandi akun animeil.al milikmu.",
  register: "Buat akun gratis dan tentukan sandimu sendiri.",
  forgot: "Pulihkan akun lewat email yang digunakan saat mendaftar.",
  reset: "Pilih sandi baru yang belum kamu pakai di layanan lain.",
  sent: "Pemulihan hanya bisa dilakukan melalui email pemilik akun.",
};

export default function AuthModal({ onClose, onSuccess, onHelp, resetToken, onResetComplete }: Props) {
  const [mode, setMode] = useState<AuthMode>(resetToken !== undefined ? "reset" : "login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [visible, setVisible] = useState(false);
  const [capsLock, setCapsLock] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [recoveryAvailable, setRecoveryAvailable] = useState<boolean | null>(null);
  const [recoveryMessage, setRecoveryMessage] = useState("");
  const [recoveryLabel, setRecoveryLabel] = useState("");
  const [recoveryCheckedAt, setRecoveryCheckedAt] = useState<string | null>(null);
  const [recoveryChecking, setRecoveryChecking] = useState(false);
  const [recoveryCheckFailed, setRecoveryCheckFailed] = useState(false);
  const [recoveryRetry, setRecoveryRetry] = useState(0);
  const isAccountForm = mode === "login" || mode === "register";

  useEffect(() => {
    if (mode !== "forgot") return;
    let active = true;
    let checking = false;
    const controller = new AbortController();
    setRecoveryAvailable(null);
    setRecoveryMessage("");
    setRecoveryCheckedAt(null);
    setRecoveryCheckFailed(false);

    async function checkRecovery() {
      if (checking || document.visibilityState === "hidden") return;
      checking = true;
      setRecoveryChecking(true);
      try {
        const result = await api<{ available: boolean; message: string; label: string; checkedAt: string }>("/api/auth/password", {
          cache: "no-store",
          signal: AbortSignal.any([controller.signal, AbortSignal.timeout(10000)]),
        });
        if (!active) return;
        const date = new Date(result.checkedAt);
        setRecoveryAvailable(result.available);
        setRecoveryMessage(result.message);
        setRecoveryLabel(result.label);
        setRecoveryCheckedAt(Number.isNaN(date.getTime()) ? null : date.toISOString());
        setRecoveryCheckFailed(false);
      } catch (e) {
        if (!active) return;
        // A network failure is unknown status, not proof that email is disabled.
        setRecoveryAvailable(null);
        setRecoveryLabel("Status belum dapat diperiksa");
        setRecoveryMessage(errorMessage(e));
        setRecoveryCheckedAt(null);
        setRecoveryCheckFailed(true);
      } finally {
        checking = false;
        if (active) setRecoveryChecking(false);
      }
    }

    void checkRecovery();
    const interval = setInterval(() => { void checkRecovery(); }, 30000);
    const onReturn = () => { void checkRecovery(); };
    window.addEventListener("focus", onReturn);
    document.addEventListener("visibilitychange", onReturn);
    return () => {
      active = false;
      controller.abort();
      clearInterval(interval);
      window.removeEventListener("focus", onReturn);
      document.removeEventListener("visibilitychange", onReturn);
    };
  }, [mode, recoveryRetry]);

  function switchMode(next: AuthMode) {
    if (busy) return;
    setMode(next); setError(""); setNotice(""); setPassword(""); setConfirmPassword(""); setVisible(false); setCapsLock(false);
  }
  function detectCapsLock(event: KeyboardEvent<HTMLInputElement>) {
    setCapsLock(event.getModifierState("CapsLock"));
  }
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (busy || (mode === "forgot" && (recoveryAvailable !== true || recoveryChecking))) return;
    setError(""); setNotice("");
    if (mode === "reset" && confirmPassword !== password) {
      setError("Kedua kata sandi belum sama. Ketik ulang sandi baru dengan benar."); return;
    }
    setBusy(true);
    try {
      if (mode === "forgot") {
        const result = await post<{ message: string }>("/api/auth/password", { action: "request", email });
        setNotice(result.message); setMode("sent"); return;
      }
      if (mode === "reset") {
        const result = await post<{ message: string }>("/api/auth/password", { action: "reset", token: resetToken, password, confirmPassword });
        setPassword(""); setConfirmPassword(""); setVisible(false); setMode("login"); setNotice(result.message); onResetComplete?.(); return;
      }
      const result = await post<{ user: PublicUser; message: string }>("/api/auth", { action: mode, email, password, name });
      onSuccess(result.user, result.message); onClose();
    } catch (e) { setError(errorMessage(e)); } finally { setBusy(false); }
  }

  return <Modal title={titles[mode]} onClose={onClose} className="auth-modal">
    <div className="auth-art">
      <img src="/images/avatar.webp" alt="Ilustrasi karakter anime berambut biru" />
      <div className="auth-art-shade" />
      <span className="auth-brand">animeil<span>.al</span></span>
      <div><span className="eyebrow">SATU AKUN, BANYAK CERITA</span><h2>Cerita lebih seru<br />kalau bareng.</h2><p>Simpan favoritmu. Bagikan pendapatmu.<br />Temukan teman satu cerita.</p></div>
    </div>
    <div className="auth-form-wrap">
      {isAccountForm ? <div className="auth-tabs">
        <button className={mode === "login" ? "active" : ""} disabled={busy} onClick={() => switchMode("login")}>Masuk</button>
        <button className={mode === "register" ? "active" : ""} disabled={busy} onClick={() => switchMode("register")}>Daftar</button>
      </div> : <button className="auth-back" disabled={busy} onClick={() => switchMode("login")}><ArrowLeft size={15} />Kembali ke masuk</button>}
      <h2>{headings[mode]}</h2>
      <p className="muted">{descriptions[mode]}</p>
      {mode === "login" && <div className="auth-login-hint"><Info size={15} /><p>Tidak ada sandi bawaan. Belum pernah mendaftar? <button disabled={busy} onClick={() => switchMode("register")}>Buat akun dulu.</button></p></div>}
      {notice && <div className="auth-success" role="status"><CircleCheck size={17} /><p>{notice}</p></div>}
      {mode === "sent" ? <div className="recovery-sent">
        <p>Jangan bagikan tautan pemulihan kepada siapa pun. Sandi lama tetap berlaku sampai kamu menyimpan sandi baru.</p>
        <button className="button button-primary auth-submit" onClick={() => switchMode("login")}>Kembali ke masuk<ArrowRight size={16} /></button>
        <button className="auth-inline-link" onClick={() => switchMode("forgot")}>Periksa alamat email / minta ulang</button>
      </div> : <form onSubmit={submit}>
        {mode === "register" && <label className="field-label">Nama pengguna<span className="input-wrap"><UserRound size={17} /><input aria-label="Nama pengguna" value={name} onChange={e => setName(e.target.value)} placeholder="Nama panggilanmu" autoComplete="nickname" minLength={2} maxLength={40} required disabled={busy} /></span></label>}
        {mode !== "reset" && <label className="field-label">Alamat email<span className="input-wrap"><Mail size={17} /><input aria-label="Alamat email" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="nama@email.com" autoComplete="email" autoCapitalize="none" spellCheck={false} maxLength={254} required disabled={busy} /></span></label>}
        {mode !== "forgot" && <>
          <label className="field-label">{mode === "reset" ? "Kata sandi baru" : "Kata sandi"}<span className="input-wrap"><LockKeyhole size={17} /><input aria-label={mode === "reset" ? "Kata sandi baru" : "Kata sandi"} type={visible ? "text" : "password"} value={password} onChange={e => setPassword(e.target.value)} placeholder={mode === "login" ? "Sandi akun animeil.al" : "Minimal 8 karakter"} minLength={8} maxLength={128} autoComplete={mode === "login" ? "current-password" : "new-password"} onKeyUp={detectCapsLock} onKeyDown={detectCapsLock} onBlur={() => setCapsLock(false)} required disabled={busy} /><button type="button" className="input-eye" onClick={() => setVisible(!visible)} aria-label={visible ? "Sembunyikan kata sandi" : "Tampilkan kata sandi"}>{visible ? <EyeOff size={17} /> : <Eye size={17} />}</button></span></label>
          {mode === "reset" && <label className="field-label">Ulangi kata sandi baru<span className="input-wrap"><LockKeyhole size={17} /><input aria-label="Ulangi kata sandi baru" type={visible ? "text" : "password"} value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder="Ketik sandi baru sekali lagi" minLength={8} maxLength={128} autoComplete="new-password" onKeyUp={detectCapsLock} onKeyDown={detectCapsLock} onBlur={() => setCapsLock(false)} required disabled={busy} /></span></label>}
          {capsLock && <p className="auth-caps-warning" role="status">Caps Lock aktif. Sandi membedakan huruf besar dan kecil.</p>}
        </>}
        {mode === "login" && <div className="auth-password-options"><span>Bukan sandi emailmu.</span><button type="button" disabled={busy} onClick={() => switchMode("forgot")}>Lupa kata sandi?</button></div>}
        {mode === "forgot" && <div className={`recovery-availability ${recoveryCheckFailed ? "unknown" : recoveryAvailable === false ? "unavailable" : recoveryAvailable === true ? "configured" : ""}`} role="status" aria-live="polite" aria-atomic="true">
          {recoveryAvailable === null && !recoveryCheckFailed ? <><LoaderCircle size={16} className="spin" /><p>Memeriksa layanan pemulihan…</p></> : <>
            {recoveryAvailable ? <CircleCheck size={16} /> : <Info size={16} />}
            <div>
              <strong>{recoveryLabel}</strong>
              <p>{recoveryMessage}</p>
              {recoveryAvailable && <small>Tautan berlaku 30 menit dan hanya dapat digunakan sekali.</small>}
              <div className="recovery-status-meta">
                {recoveryCheckedAt && <time dateTime={recoveryCheckedAt}>Diperiksa pukul {new Date(recoveryCheckedAt).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</time>}
                <button type="button" disabled={busy || recoveryChecking} onClick={() => setRecoveryRetry(value => value + 1)}>{recoveryChecking && <LoaderCircle size={12} className="spin" />}{recoveryChecking ? "Memeriksa…" : "Periksa lagi"}</button>
              </div>
              <p className="recovery-refresh-note">Status diperiksa otomatis setiap 30 detik dan saat kamu kembali ke tab ini.</p>
            </div>
          </>}
        </div>}
        {error && <p role="alert" className="form-error">{error}</p>}
        <button className="button button-primary auth-submit" disabled={busy || (mode === "forgot" && (recoveryAvailable !== true || recoveryChecking))}>
          {busy ? <><LoaderCircle className="spin" size={18} /><span>Memproses…</span></> : <>{mode === "login" ? "Masuk ke akun" : mode === "register" ? "Buat akun gratis" : mode === "forgot" ? "Kirim tautan pemulihan" : "Simpan sandi baru"}{mode === "forgot" ? <Mail size={16} /> : mode === "reset" ? <KeyRound size={16} /> : <ArrowRight size={17} />}</>}
        </button>
        {mode === "reset" && <button type="button" className="auth-inline-link" disabled={busy} onClick={() => switchMode("forgot")}>Minta tautan baru</button>}
        {mode === "forgot" && <p className="auth-register-prompt">Belum pernah mendaftar? <button type="button" disabled={busy} onClick={() => switchMode("register")}>Buat akun baru</button></p>}
      </form>}
      <p className="auth-privacy"><ShieldCheck size={14} /> {mode === "reset" ? "Sesi lama akan diakhiri setelah sandi diganti." : "Kami tidak pernah meminta sandimu lewat chat."}</p>
      {isAccountForm && <p className="auth-terms">Dengan melanjutkan, kamu setuju untuk menjaga ruang ini tetap nyaman. <button onClick={onHelp}>Baca pedoman komunitas.</button></p>}
    </div>
  </Modal>;
}
