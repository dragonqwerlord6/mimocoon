"use client";

import { useState } from "react";
import { ArrowRight, CalendarClock, Check, Clock3, Info, LoaderCircle, LockKeyhole, Play, Radio, RefreshCw } from "lucide-react";
import type { Anime } from "@/lib/catalog";
import type { UpcomingEpisode } from "@/lib/releases/types";
import { useReleases, releaseTime, releaseCountdown } from "./use-releases";
import "./release-board.css";

export function UpcomingEpisodes({ episodes, now }: { episodes: UpcomingEpisode[]; now: number }) {
  if (!episodes.length) return null;
  return <section className="upcoming-episodes" aria-label="Episode terjadwal">
    <div className="upcoming-heading"><CalendarClock size={17} /><h3>Segera tayang</h3><span>Waktu Indonesia Barat</span></div>
    <div className="upcoming-episode-list">{episodes.map(episode => <article className="upcoming-episode" key={episode.id}>
      <span className="episode-number">{String(episode.number).padStart(2, "0")}</span>
      <div><strong>{episode.title}</strong><time dateTime={episode.releaseAt}>{releaseTime(episode.releaseAt)}</time><small>{releaseCountdown(episode.releaseAt, now)}</small></div>
      <span className="episode-lock" title="Video terbuka otomatis saat waktu rilis" aria-label="Menunggu waktu rilis"><LockKeyhole size={17} /></span>
    </article>)}</div>
    <p>Video dibuka oleh server saat waktunya tiba. Mengubah jam perangkat tidak akan membuka episode lebih awal.</p>
  </section>;
}

export default function ReleaseBoard({ onOpen, compact = false, onSchedule }: { onOpen: (anime: Anime) => void; compact?: boolean; onSchedule?: () => void }) {
  const { data, loading, refreshing, error, refresh, now } = useReleases();
  const [tab, setTab] = useState<"released" | "scheduled">("released");
  const stats = data?.stats || { released: 0, scheduled: 0 };
  const sync = data?.sync;
  if (compact) return <section className="release-compact" aria-label="Status rilis otomatis">
    <span className="release-radio"><Radio size={20} /></span><div className="release-compact-copy"><h2>Rilis otomatis, tepat waktunya.</h2><p>{error ? "Status rilis belum dapat diperiksa." : loading ? "Memeriksa sumber episode…" : stats.released ? `${stats.released} episode tersedia · ${stats.scheduled} menunggu jadwal` : "Yang sudah tayang langsung tersedia. Yang akan datang menunggu jadwal."}</p></div>
    <span className={`release-state ${sync?.state === "ready" ? "ready" : ""}`}><span />{error ? "Belum terhubung" : sync?.label || "Memeriksa…"}</span>
    <button className="text-link" onClick={onSchedule}>Lihat rilis<ArrowRight size={14} /></button>
  </section>;
  const list = tab === "released" ? data?.episodes || [] : data?.upcoming || [];
  return <section className="release-board" aria-label="Episode aplikasi dan rilis otomatis">
    <div className="release-board-heading"><div><span className="eyebrow orange"><Radio size={14} />EPISODE DI ANIMEIL.AL</span><h2>Sudah waktunya? Langsung tayang.</h2><p>Episode yang sudah rilis tidak ditunda lagi. Sisanya mengikuti jadwal resmi penerbit.</p></div><button className="release-refresh" onClick={() => { void refresh(); }} disabled={refreshing} aria-label="Perbarui daftar episode"><RefreshCw size={16} className={refreshing ? "spin" : ""} /><span>Perbarui</span></button></div>
    <div className={`release-source-status ${sync?.state === "ready" ? "ready" : ""}`}><span className="release-radio"><Radio size={19} /></span><div><strong>{sync?.label || "Memeriksa koneksi sumber…"}</strong><p>{sync?.message || "Mengambil informasi rilis dari server."}</p>{sync?.lastSuccessAt && <small>Sinkronisasi terakhir: {releaseTime(sync.lastSuccessAt)}</small>}</div>{sync?.state === "ready" && <Check size={18} />}</div>
    <div className="release-board-tabs" role="tablist" aria-label="Status episode"><button role="tab" aria-selected={tab === "released"} onClick={() => setTab("released")}><Play size={14} />Sudah rilis<span>{stats.released}</span></button><button role="tab" aria-selected={tab === "scheduled"} onClick={() => setTab("scheduled")}><CalendarClock size={15} />Terjadwal<span>{stats.scheduled}</span></button><span className="release-timezone"><Clock3 size={13} />Jadwal dalam WIB</span></div>
    {error && <div className="inline-error" role="alert"><span>{error}</span><button onClick={() => { void refresh(); }}>Coba lagi</button></div>}
    {loading ? <div className="release-empty"><LoaderCircle size={27} className="spin" /><p>Memeriksa episode dan jadwal…</p></div> : !list.length ? <div className="release-empty">{tab === "released" ? <Play size={28} /> : <CalendarClock size={28} />}<h3>{tab === "released" ? "Belum ada episode penuh yang tersedia." : "Belum ada episode dalam antrean."}</h3><p>{tab === "released" ? "Setelah feed video berlisensi terhubung, episode yang sudah melewati waktu tayang langsung masuk ke sini." : "Episode mendatang akan muncul beserta jadwalnya. Videonya tetap terkunci sampai waktu rilis."}</p></div> : <div className="release-cards">{list.map(episode => <article key={episode.id} className={`release-card ${tab === "scheduled" ? "scheduled" : ""}`}>
      <button className="release-card-cover" onClick={() => onOpen(episode.anime)} aria-label={`Lihat ${episode.anime.title}`}><img src={episode.anime.image} alt="" loading="lazy" onError={event => { event.currentTarget.src = "/images/avatar.webp"; }} /><span>{tab === "released" ? <Play size={17} fill="currentColor" /> : <LockKeyhole size={16} />}</span></button>
      <div className="release-card-content"><span className="release-episode-label">EPISODE {episode.number}<span className={tab === "released" ? "released-tag" : "scheduled-tag"}>{tab === "released" ? "Sudah rilis" : "Terjadwal"}</span></span><button className="release-card-title" onClick={() => onOpen(episode.anime)}>{episode.anime.title}</button><p>{episode.title}</p><time dateTime={episode.releaseAt}>{releaseTime(episode.releaseAt)}</time>{tab === "scheduled" ? <small className="release-countdown"><Clock3 size={12} />{releaseCountdown(episode.releaseAt, now)}</small> : <button className="release-watch" onClick={() => onOpen(episode.anime)}>Lihat episode<ArrowRight size={13} /></button>}</div>
    </article>)}</div>}
    <div className="release-policy"><Info size={14} /><p>Rilis berdasarkan waktu server. Sinkronisasi hanya mengambil episode dari sumber berlisensi; bukan mengunduh dari situs streaming sembarang.</p></div>
  </section>;
}
