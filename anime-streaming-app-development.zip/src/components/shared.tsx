"use client";

import { useEffect, useId, useRef, type ReactNode } from "react";
import { BadgeCheck, Bookmark, Check, Play, Star, X, type LucideIcon } from "lucide-react";
import type { Anime } from "@/lib/catalog";
import "./owner-badge.css";

export function VerifiedBadge({ verified }: { verified: boolean }) {
  return verified ? <span className="verified-badge" role="img" title="Centang oranye — akun khusus animeil.al. Status verifikasi email terpisah." aria-label="Centang oranye akun khusus"><BadgeCheck size={19} fill="currentColor" stroke="#12151e" strokeWidth={2} aria-hidden="true" /></span> : null;
}
export function Avatar({ name, verified = false, className = "" }: { name?: string; verified?: boolean; className?: string }) {
  return <span className={`avatar ${className}`}>{!name || verified ? <img src="/images/avatar.webp" alt="" /> : <span>{name.slice(0, 2).toUpperCase()}</span>}</span>;
}
let modalCount = 0;
let previousOverflow = "";
export function Modal({ children, onClose, title, className = "" }: { children: ReactNode; onClose: () => void; title: string; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose); closeRef.current = onClose;
  const id = useId();
  useEffect(() => {
    const previouslyFocused = document.activeElement as HTMLElement | null;
    if (modalCount === 0) { previousOverflow = document.body.style.overflow; document.body.style.overflow = "hidden"; }
    modalCount++;
    const timer = setTimeout(() => ref.current?.focus(), 30);
    function keydown(event: KeyboardEvent) {
      const dialogs = document.querySelectorAll('[role="dialog"]');
      if (dialogs[dialogs.length - 1] !== ref.current) return;
      if (event.key === "Escape") { event.preventDefault(); closeRef.current(); }
      if (event.key === "Tab") {
        const elements = ref.current?.querySelectorAll<HTMLElement>('button:not([disabled]),a[href],input,textarea,select,[tabindex="0"]');
        const visible = elements ? Array.from(elements).filter(e => e.offsetParent !== null) : [];
        if (!visible.length) { event.preventDefault(); return; }
        const first = visible[0], last = visible[visible.length - 1];
        if (event.shiftKey && (document.activeElement === first || document.activeElement === ref.current)) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && (document.activeElement === last || document.activeElement === ref.current)) { event.preventDefault(); first.focus(); }
      }
    }
    document.addEventListener("keydown", keydown);
    return () => { clearTimeout(timer); modalCount--; if (modalCount === 0) document.body.style.overflow = previousOverflow; document.removeEventListener("keydown", keydown); if (previouslyFocused?.isConnected) previouslyFocused.focus(); };
  }, []);
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <div ref={ref} className={`modal ${className}`} role="dialog" aria-modal="true" aria-labelledby={id} tabIndex={-1}>
      <h2 className="sr-only" id={id}>{title}</h2>
      <button className="modal-close icon-button" onClick={onClose} aria-label="Tutup dialog"><X size={21} /></button>
      {children}
    </div>
  </div>;
}
export function EmptyState({ icon: Icon, title, description, action, onAction }: { icon: LucideIcon; title: string; description: string; action?: string; onAction?: () => void }) {
  return <div className="empty-state"><span className="empty-icon"><Icon size={29} strokeWidth={1.5} /></span><h3>{title}</h3><p>{description}</p>{action && <button className="button button-secondary" onClick={onAction}>{action}</button>}</div>;
}
export function AnimeCard({ anime, onSelect, onSave, saved = false, rank }: { anime: Anime; onSelect: (anime: Anime) => void; onSave: (anime: Anime) => void; saved?: boolean; rank?: number }) {
  return <article className="anime-card">
    <div className="poster-wrap">
      <button className="poster-button" onClick={() => onSelect(anime)} aria-label={`Lihat ${anime.title}`}>
        <img src={anime.image} alt={`Poster ${anime.title}`} loading="lazy" decoding="async" onError={e => { if (!e.currentTarget.src.endsWith("avatar.webp")) e.currentTarget.src = "/images/avatar.webp"; }} />
        <span className="poster-shade" />
        <span className="episode-tag">{anime.episodes ? `${anime.episodes} EPISODE` : "SEDANG TAYANG"}</span>
        <span className="poster-play"><Play size={23} fill="currentColor" /></span>
        <span className="poster-bottom"><span className="poster-type">SERIAL</span><span className="poster-score"><Star size={11} fill="currentColor" /> {anime.score ? anime.score.toFixed(1) : "—"}</span></span>
        {rank && <span className="rank-number">{String(rank).padStart(2, "0")}</span>}
      </button>
      <button className={`card-save ${saved ? "is-saved" : ""}`} onClick={() => onSave(anime)} aria-label={saved ? `Hapus ${anime.title} dari daftar` : `Simpan ${anime.title}`} title={saved ? "Tersimpan di daftar saya" : "Simpan ke daftar saya"}>{saved ? <Check size={16} /> : <Bookmark size={15} />}</button>
    </div>
    <button className="anime-title" onClick={() => onSelect(anime)}>{anime.title}</button>
    <div className="anime-meta"><span>{anime.genres.slice(0, 2).join(" · ")}</span><span className="meta-dot">·</span><span>{anime.year}</span></div>
  </article>;
}
