export async function api<T = { message?: string }>(url: string, options?: RequestInit): Promise<T> {
  let response: Response;
  try { response = await fetch(url, { ...options, headers: { "Content-Type": "application/json", ...options?.headers } }); }
  catch { throw new Error("Koneksi terputus. Periksa internetmu dan coba lagi."); }
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Ada kendala. Silakan coba lagi.");
  return data as T;
}
export const post = <T = { message?: string }>(url: string, body: unknown) => api<T>(url, { method: "POST", body: JSON.stringify(body) });
export function relativeTime(value: string) {
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 1000));
  if (seconds < 60) return "Baru saja";
  if (seconds < 3600) return `${Math.floor(seconds / 60)} menit lalu`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} jam lalu`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)} hari lalu`;
  return new Date(value).toLocaleDateString("id-ID", { day: "numeric", month: "short" });
}
export const errorMessage = (error: unknown) => error instanceof Error ? error.message : "Ada kendala. Coba lagi sebentar.";
