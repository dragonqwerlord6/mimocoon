import { randomBytes, createHash, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users, emailTokens } from "@/db/schema";
export { publicUser } from "./user-profile";
export const digest = (value: string) => createHash("sha256").update(value).digest("hex");
export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
}
export function checkPassword(password: string, hash: string) {
  const [salt, key] = hash.split(":");
  if (!salt || !key) return false;
  const expected = Buffer.from(key, "hex");
  const actual = scryptSync(password, salt, 64);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
export async function currentUser() {
  const token = (await cookies()).get("animeil_session")?.value;
  if (!token) return null;
  const [result] = await db.select({ user: users }).from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.tokenHash, digest(token)), gt(sessions.expiresAt, new Date()))).limit(1);
  return result?.user ?? null;
}
export async function createSession(userId: string, request: Request) {
  const token = randomBytes(32).toString("hex");
  const expires = new Date(Date.now() + 30 * 86400000);
  await db.insert(sessions).values({ tokenHash: digest(token), userId, expiresAt: expires });
  const secure = new URL(request.url).protocol === "https:" || request.headers.get("x-forwarded-proto") === "https";
  (await cookies()).set("animeil_session", token, { httpOnly: true, secure, sameSite: "lax", path: "/", expires });
}
export function sameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (!origin) return true;
  try {
    const host = request.headers.get("x-forwarded-host") || request.headers.get("host") || new URL(request.url).host;
    return new URL(origin).host === host;
  } catch { return false; }
}
const buckets = new Map<string, { count: number; until: number }>();
export function rateLimit(key: string, max = 20) {
  const now = Date.now();
  if (buckets.size > 10000) for (const [k, v] of buckets) if (v.until < now) buckets.delete(k);
  const bucket = buckets.get(key);
  if (!bucket || bucket.until < now) { buckets.set(key, { count: 1, until: now + 15 * 60000 }); return true; }
  if (bucket.count >= max) return false;
  bucket.count++; return true;
}
export async function sendVerification(user: typeof users.$inferSelect, request: Request) {
  if (!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM || !process.env.APP_URL) return false;
  const token = randomBytes(32).toString("hex");
  const url = new URL("/", process.env.APP_URL);
  url.searchParams.set("verify", token);
  await db.insert(emailTokens).values({ userId: user.id, tokenHash: digest(token), expiresAt: new Date(Date.now() + 3600000) });
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST", headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: process.env.EMAIL_FROM, to: [user.email], subject: "Verifikasi email akun animeil.al", html: `<div style="font-family:Arial;padding:32px"><h1>Selamat datang di animeil.al</h1><p>Konfirmasikan alamat email untuk mengamankan akunmu. Tautan berlaku selama 1 jam.</p><a href="${url.toString()}">Verifikasi email saya</a><p>Abaikan email ini jika kamu tidak membuat akun.</p></div>` }),
    signal: AbortSignal.timeout(10000),
  }).catch(() => null);
  if (!response?.ok) { await db.delete(emailTokens).where(eq(emailTokens.tokenHash, digest(token))); return false; }
  return true;
}
export const errorResponse = (message: string, status = 400) => Response.json({ error: message }, { status });
export const validAnimeId = (id: unknown): id is number => typeof id === "number" && Number.isInteger(id) && id > 0 && id < 10000000;
export const validUuid = (id: unknown): id is string => typeof id === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);
