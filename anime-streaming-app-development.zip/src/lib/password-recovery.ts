import { randomBytes } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { passwordResetTokens, users } from "@/db/schema";
import { digest } from "@/lib/auth";

export const recoveryUnavailableMessage = "Pemulihan lewat email belum aktif. Pengelola perlu menghubungkan layanan email terlebih dahulu. Jika belum pernah membuat akun, pilih Daftar dan buat sandimu sendiri.";
export const recoveryRequestedMessage = "Jika email tersebut terdaftar, tautan pemulihan akan dikirim ke kotak masuknya. Periksa juga folder spam. Tautan berlaku 30 menit.";

export function passwordRecoveryAvailable() {
  if (!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM || !process.env.APP_URL) return false;
  try {
    const url = new URL(process.env.APP_URL);
    return url.protocol === "https:" || (url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname));
  } catch { return false; }
}

export async function sendPasswordRecovery(user: Pick<typeof users.$inferSelect, "id" | "email">) {
  if (!passwordRecoveryAvailable()) return false;
  const token = randomBytes(32).toString("hex");
  const tokenHash = digest(token);
  const url = new URL("/", process.env.APP_URL!);
  // A fragment keeps the token out of HTTP access logs and referrer headers.
  url.hash = new URLSearchParams({ reset: token }).toString();
  await db.insert(passwordResetTokens).values({
    tokenHash,
    userId: user.id,
    expiresAt: new Date(Date.now() + 30 * 60000),
  }).onConflictDoUpdate({
    target: passwordResetTokens.userId,
    set: { tokenHash, expiresAt: new Date(Date.now() + 30 * 60000) },
  });
  const link = url.toString();
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: process.env.EMAIL_FROM,
      to: [user.email],
      subject: "Atur ulang kata sandi animeil.al",
      text: `Ada permintaan untuk mengatur ulang kata sandi akun animeil.al milikmu. Buka tautan berikut untuk membuat sandi baru: ${link}\n\nTautan berlaku 30 menit dan hanya bisa dipakai sekali. Sandi lama tetap berlaku sampai kamu menyimpan sandi baru. Abaikan email ini jika kamu tidak meminta pemulihan. Jangan bagikan tautan ini kepada siapa pun.`,
      html: `<div style="font-family:Arial,sans-serif;padding:32px;max-width:520px"><h1>Atur ulang kata sandimu</h1><p>Kamu menerima email ini karena ada permintaan pemulihan akun animeil.al.</p><p><a href="${link}" style="display:inline-block;padding:12px 20px;border-radius:6px;background:#f9a05b;color:#201910;text-decoration:none">Buat kata sandi baru</a></p><p>Tautan berlaku <strong>30 menit</strong> dan hanya bisa dipakai sekali. Sandi lama tetap berlaku sampai kamu menyimpan sandi baru.</p><p>Jika bukan kamu yang meminta pemulihan, abaikan email ini. Jangan bagikan tautan ini kepada siapa pun.</p></div>`,
    }),
    signal: AbortSignal.timeout(10000),
  }).catch(() => null);
  if (!response?.ok) {
    await db.delete(passwordResetTokens).where(eq(passwordResetTokens.tokenHash, tokenHash));
    return false;
  }
  return true;
}
