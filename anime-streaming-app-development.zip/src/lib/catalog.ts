export type Anime = {
  id: number; title: string; image: string; score: number; episodes: number;
  year: number; genres: string[]; description: string; status: string;
  trailer: string; color: string; time?: string; day?: string;
};
export const catalog: Anime[] = [
  { id: 58567, title: "Solo Leveling: Arise from the Shadow", image: "/images/solo-leveling.jpg", score: 8.7, episodes: 13, year: 2025, genres: ["Aksi", "Fantasi"], description: "Sung Jinwoo kembali dengan kekuatan baru. Di balik setiap gerbang, musuh yang lebih kuat menanti sang pemburu yang terus naik level.", status: "Tamat", trailer: "GDMXGzjJzS4", color: "#7056c7" },
  { id: 55701, title: "Demon Slayer: Hashira Training", image: "/images/demon-slayer.jpg", score: 8.1, episodes: 8, year: 2024, genres: ["Aksi", "Fantasi"], description: "Tanjiro dan para pembasmi iblis menjalani latihan bersama para Hashira. Ikatan dan tekad mereka diuji sebelum pertempuran terbesar dimulai.", status: "Tamat", trailer: "Tf31dGdlWxE", color: "#dd8462" },
  { id: 21, title: "One Piece", image: "/images/one-piece.jpg", score: 8.7, episodes: 0, year: 1999, genres: ["Petualangan", "Aksi"], description: "Berlayar bersama Luffy dan kru Topi Jerami mencari harta karun legendaris. Persahabatan, kebebasan, dan petualangan tanpa batas menanti di lautan.", status: "Tayang", trailer: "-tviZNY6CSw", color: "#57abc4" },
  { id: 51009, title: "Jujutsu Kaisen Season 2", image: "/images/jujutsu-kaisen.jpg", score: 8.8, episodes: 23, year: 2023, genres: ["Aksi", "Supranatural"], description: "Masa lalu Gojo dan Geto mengungkap awal sebuah perpecahan. Kini para penyihir harus menghadapi ancaman besar yang menyelimuti Shibuya.", status: "Tamat", trailer: "PKHQuQF1S8k", color: "#597acb" },
  { id: 54900, title: "Wind Breaker", image: "/images/wind-breaker.jpg", score: 7.7, episodes: 13, year: 2024, genres: ["Aksi", "Sekolah"], description: "Haruka Sakura hanya ingin menjadi yang terkuat. Namun, di SMA Furin ia menemukan arti kekuatan yang sesungguhnya: melindungi orang lain.", status: "Tamat", trailer: "k5qM1PoLmUc", color: "#579788" },
  { id: 52588, title: "Kaiju No. 8", image: "/images/kaiju.jpg", score: 8.3, episodes: 12, year: 2024, genres: ["Aksi", "Fiksi ilmiah"], description: "Kafka Hibino kembali mengejar impiannya bergabung dengan pasukan pertahanan. Ada satu masalah: ia kini bisa berubah menjadi kaiju.", status: "Tamat", trailer: "7n_mFVPeApw", color: "#548788" },
  { id: 52991, title: "Frieren: Beyond Journey’s End", image: "/images/frieren.jpg", score: 9.3, episodes: 28, year: 2023, genres: ["Fantasi", "Petualangan", "Drama"], description: "Setelah sang pahlawan pergi, perjalanan baru dimulai. Ikuti Frieren memahami arti waktu, persahabatan, dan kenangan yang tak pernah benar-benar hilang.", status: "Tamat", trailer: "ZEkwCGJ3o7M", color: "#83b6a0" },
  { id: 50265, title: "Spy × Family", image: "/images/spy-family.jpg", score: 8.5, episodes: 12, year: 2022, genres: ["Komedi", "Aksi"], description: "Seorang mata-mata, pembunuh bayaran, dan anak pembaca pikiran membentuk keluarga penuh rahasia. Misi mereka? Terlihat seperti keluarga biasa.", status: "Tamat", trailer: "ofXigq9aIpo", color: "#dfa499" },
  { id: 44511, title: "Chainsaw Man", image: "/images/chainsaw-man.jpg", score: 8.5, episodes: 12, year: 2022, genres: ["Aksi", "Supranatural"], description: "Hidup Denji berubah ketika ia menyatu dengan iblis gergaji bernama Pochita. Kini ia memburu iblis sambil mengejar impian-impian sederhananya.", status: "Tamat", trailer: "jk7QSGwupPA", color: "#d39552" },
];
export const featured = [catalog[6], catalog[0], catalog[2]];
export const days = [
  { label: "Senin", value: "monday" }, { label: "Selasa", value: "tuesday" },
  { label: "Rabu", value: "wednesday" }, { label: "Kamis", value: "thursday" },
  { label: "Jumat", value: "friday" }, { label: "Sabtu", value: "saturday" },
  { label: "Minggu", value: "sunday" },
];
export const genreTranslations: Record<string, string> = {
  Action: "Aksi", Adventure: "Petualangan", Fantasy: "Fantasi", Drama: "Drama", Comedy: "Komedi",
  Romance: "Romansa", "Sci-Fi": "Fiksi ilmiah", Supernatural: "Supranatural", Mystery: "Misteri",
  Sports: "Olahraga", "Slice of Life": "Keseharian", Suspense: "Ketegangan", Horror: "Horor", AwardWinning: "Pemenang penghargaan",
  "Award Winning": "Pemenang penghargaan", Gourmet: "Kuliner", School: "Sekolah", "Avant Garde": "Eksperimental",
};
export type PublicUser = { id: string; name: string; email: string; verified: boolean; emailVerified: boolean };
export type CommentData = { id: string; userId: string; name: string; verified: boolean; body: string; parentId: string | null; createdAt: string; likes: number; liked: boolean };
export type NotificationData = { id: string; title: string; body: string; animeId: number; anime: Anime | null; commentId: string | null; read: boolean; createdAt: string };
export type HistoryData = { anime: Anime; animeId: number; episode: number; progress: number; duration: number; updatedAt: string };
export type Episode = { id: string; number: number; title: string; videoUrl: string; subtitleUrl: string; releaseAt: string };
