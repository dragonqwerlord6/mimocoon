import type { Anime, Episode } from "../catalog";

export type ReleaseEntry = Episode & { animeId: number; anime: Anime; status: "released" };
export type UpcomingEpisode = { id: string; animeId: number; number: number; title: string; releaseAt: string; anime: Anime; status: "scheduled" };
export type ReleaseSyncStatus = {
  configured: boolean;
  mode: "feed" | "webhook" | "none";
  state: "unconfigured" | "waiting" | "running" | "ready" | "partial" | "error";
  label: string;
  message: string;
  lastSuccessAt: string | null;
  nextCheckAt: string | null;
  intervalMinutes: number;
};
export type ReleaseResponse = {
  episodes: ReleaseEntry[];
  upcoming: UpcomingEpisode[];
  stats: { released: number; scheduled: number };
  serverTime: string;
  sync: ReleaseSyncStatus;
};
export type ImportResult = { imported: number; updated: number; unchanged: number; released: number; scheduled: number; rejected: number };
