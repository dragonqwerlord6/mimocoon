import { isIP } from "node:net";
import { catalog, type Anime } from "../catalog";

export class ReleaseInputError extends Error {}
export type ParsedEpisode = { animeId: number; number: number; title: string; videoUrl: string; subtitleUrl: string; releaseAt: Date; anime: Anime };
const japanese = /[\u3040-\u30ff\u3400-\u9fff]/;
export function publicHttpsUrl(value: unknown, allowedHosts?: string[]): value is string {
  if (typeof value !== "string" || !value || value.length > 2000) return false;
  try {
    const url = new URL(value);
    const host = url.hostname.toLowerCase();
    if (url.protocol !== "https:" || url.username || url.password || (url.port && url.port !== "443") || url.hash) return false;
    if (isIP(host) || host.includes(":") || !host.includes(".") || /(^|\.)(localhost|local|internal|invalid|test)$/.test(host) || host.endsWith(".")) return false;
    return !allowedHosts?.length || allowedHosts.includes(host);
  } catch { return false; }
}
export function mediaHosts() {
  return (process.env.MEDIA_ALLOWED_HOSTS || "").split(",").map(s => s.trim().toLowerCase()).filter(Boolean);
}
export function releaseDate(value: unknown): Date {
  if (typeof value !== "string") throw new ReleaseInputError("Waktu rilis wajib memakai ISO 8601 beserta zona waktu.");
  const parts = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d{1,3})?(Z|[+-]\d{2}:\d{2})$/.exec(value);
  if (!parts) throw new ReleaseInputError("Waktu rilis wajib memakai ISO 8601 beserta zona waktu.");
  const [, y, m, d, h, min, sec, zone] = parts;
  const offset = zone === "Z" ? [0, 0] : zone.slice(1).split(":").map(Number);
  const date = new Date(value);
  if (+y < 1900 || +y > 2200 || +m < 1 || +m > 12 || +d < 1 || +d > new Date(Date.UTC(+y, +m, 0)).getUTCDate() || +h > 23 || +min > 59 || +sec > 59 || offset[0] > 14 || offset[1] > 59 || (offset[0] === 14 && offset[1] !== 0) || Number.isNaN(date.getTime())) throw new ReleaseInputError("Tanggal atau zona waktu rilis tidak valid.");
  return date;
}
export function fallbackAnime(id: number): Anime {
  return catalog.find(a => a.id === id) || { id, title: `Anime #${id}`, image: "/images/avatar.webp", score: 0, episodes: 0, year: new Date().getUTCFullYear(), genres: [], description: "Episode resmi dengan audio asli dan subtitle Indonesia. Informasi disediakan oleh penerbit.", status: "Tayang", trailer: "", color: "#8297b0" };
}
function animeSnapshot(value: unknown, animeId: number): Anime {
  const base = fallbackAnime(animeId);
  if (value === undefined || value === null) return base;
  if (typeof value !== "object" || Array.isArray(value)) throw new ReleaseInputError("Metadata anime tidak valid.");
  const a = value as Record<string, unknown>;
  if (a.id !== undefined && a.id !== animeId) throw new ReleaseInputError("ID metadata anime tidak cocok.");
  if (typeof a.title !== "string" || !a.title.trim() || a.title.length > 200 || japanese.test(a.title)) throw new ReleaseInputError("Gunakan judul anime Indonesia atau judul internasional (maksimal 200 karakter).");
  if (a.image !== undefined && !publicHttpsUrl(a.image)) throw new ReleaseInputError("Poster dari penerbit harus menggunakan URL HTTPS publik.");
  const desc = typeof a.description === "string" ? a.description.trim() : base.description;
  if (desc.length > 2000 || japanese.test(desc)) throw new ReleaseInputError("Deskripsi wajib memakai teks Indonesia (maksimal 2.000 karakter).");
  const genres = Array.isArray(a.genres) ? a.genres.filter((g): g is string => typeof g === "string" && g.length <= 40 && !japanese.test(g)).slice(0, 5) : base.genres;
  return { ...base, title: a.title.trim(), image: typeof a.image === "string" ? a.image : base.image, description: desc, genres, year: Number.isInteger(a.year) && Number(a.year) >= 1900 && Number(a.year) <= 2200 ? Number(a.year) : base.year, episodes: Number.isInteger(a.episodes) && Number(a.episodes) >= 0 && Number(a.episodes) <= 10000 ? Number(a.episodes) : base.episodes, score: typeof a.score === "number" && Number.isFinite(a.score) && a.score >= 0 && a.score <= 10 ? a.score : base.score, status: a.status === "Tamat" ? "Tamat" : base.status, trailer: typeof a.trailer === "string" && /^[a-zA-Z0-9_-]{11}$/.test(a.trailer) ? a.trailer : base.trailer };
}
export function parseEpisode(value: unknown, options: { allowImmediate?: boolean; now?: Date } = {}): ParsedEpisode {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new ReleaseInputError("Data episode harus berupa objek.");
  const a = value as Record<string, unknown>;
  if (typeof a.animeId !== "number" || !Number.isInteger(a.animeId) || a.animeId < 1 || a.animeId >= 10000000 || typeof a.number !== "number" || !Number.isInteger(a.number) || a.number < 1 || a.number > 10000) throw new ReleaseInputError("ID anime atau nomor episode tidak valid.");
  if (typeof a.title !== "string" || !a.title.trim() || a.title.length > 200 || japanese.test(a.title)) throw new ReleaseInputError("Judul episode harus memakai teks Indonesia (maksimal 200 karakter).");
  if (!publicHttpsUrl(a.videoUrl, mediaHosts()) || !publicHttpsUrl(a.subtitleUrl, mediaHosts())) throw new ReleaseInputError("Video dan subtitle harus berupa URL HTTPS publik pada CDN yang diizinkan.");
  if (a.subtitleLanguage !== undefined && a.subtitleLanguage !== "id") throw new ReleaseInputError("Subtitle episode wajib berbahasa Indonesia (id).");
  const releaseAt = a.releaseAt === undefined && options.allowImmediate ? options.now || new Date() : releaseDate(a.releaseAt);
  return { animeId: a.animeId, number: a.number, title: a.title.trim(), videoUrl: a.videoUrl, subtitleUrl: a.subtitleUrl, releaseAt, anime: animeSnapshot(a.anime, a.animeId) };
}
export function parseFeedPage(value: unknown) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new ReleaseInputError("Feed harus berupa objek JSON dengan daftar episodes.");
  const data = value as Record<string, unknown>;
  if (!Array.isArray(data.episodes) || data.episodes.length > 500) throw new ReleaseInputError("Feed harus berisi daftar episodes, maksimal 500 per halaman.");
  if (data.nextCursor !== undefined && data.nextCursor !== null && (typeof data.nextCursor !== "string" || !data.nextCursor || data.nextCursor.length > 1000)) throw new ReleaseInputError("Cursor feed tidak valid.");
  const episodes: ParsedEpisode[] = [];
  const errors: string[] = [];
  for (const [index, item] of data.episodes.entries()) {
    try { episodes.push(parseEpisode(item)); }
    catch (error) { errors.push(`Episode ke-${index + 1}: ${error instanceof ReleaseInputError ? error.message : "Data tidak valid."}`); }
  }
  return { episodes, errors, nextCursor: typeof data.nextCursor === "string" ? data.nextCursor : null };
}
