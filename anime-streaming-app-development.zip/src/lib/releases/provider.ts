import { createHash, timingSafeEqual } from "node:crypto";
import { lookup } from "node:dns/promises";
import { isIP } from "node:net";
import { publicHttpsUrl, ReleaseInputError } from "./validation";

export const SYNC_KEY = "licensed-feed";
export function feedSettings() {
  const url = process.env.EPISODE_FEED_URL?.trim() || "";
  const seconds = Number(process.env.EPISODE_SYNC_INTERVAL_SECONDS || 300);
  const intervalSeconds = Number.isFinite(seconds) ? Math.max(60, Math.min(86400, Math.floor(seconds))) : 300;
  return { url, configured: publicHttpsUrl(url), intervalSeconds, sourceKey: createHash("sha256").update(url).digest("hex"), token: process.env.EPISODE_FEED_TOKEN?.trim() || "" };
}
export function bearerMatches(request: Request, secret: string | undefined) {
  if (!secret?.trim()) return false;
  const actual = request.headers.get("authorization") || "";
  const hash = (value: string) => createHash("sha256").update(value).digest();
  return timingSafeEqual(hash(actual), hash(`Bearer ${secret}`));
}
function publicAddress(address: string) {
  if (isIP(address) === 4) {
    const [a, b] = address.split(".").map(Number);
    return a > 0 && a < 224 && a !== 10 && a !== 127 && !(a === 100 && b >= 64 && b <= 127) && !(a === 169 && b === 254) && !(a === 172 && b >= 16 && b <= 31) && !(a === 192 && [0, 168].includes(b)) && !(a === 198 && [18, 19].includes(b));
  }
  return isIP(address) === 6 && /^[23]/i.test(address) && !address.toLowerCase().startsWith("2001:db8:");
}
export async function fetchProvider(url: string, init: RequestInit): Promise<Response> {
  if (!publicHttpsUrl(url)) throw new ReleaseInputError("Alamat feed harus berupa URL HTTPS publik.");
  const records = await lookup(new URL(url).hostname, { all: true });
  if (!records.length || records.some(record => !publicAddress(record.address))) throw new ReleaseInputError("Alamat feed tidak boleh mengarah ke jaringan privat.");
  return fetch(url, { ...init, redirect: "error", cache: "no-store" });
}
export async function readFeedJson(response: Response) {
  if (!response.ok) throw new ReleaseInputError(`Penyedia mengembalikan HTTP ${response.status}. Akan dicoba kembali.`);
  if (!(response.headers.get("content-type") || "").toLowerCase().includes("json")) throw new ReleaseInputError("Penyedia harus mengirim Content-Type JSON.");
  const max = 2 * 1024 * 1024;
  if (Number(response.headers.get("content-length")) > max || !response.body) throw new ReleaseInputError("Ukuran feed tidak valid; maksimal 2 MB per halaman.");
  const reader = response.body.getReader(); const chunks: Uint8Array[] = []; let bytes = 0;
  try {
    while (true) {
      const { done, value } = await reader.read(); if (done) break;
      bytes += value.byteLength;
      if (bytes > max) { await reader.cancel(); throw new ReleaseInputError("Ukuran feed melebihi 2 MB per halaman."); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  try { return JSON.parse(Buffer.concat(chunks).toString("utf8")) as unknown; }
  catch { throw new ReleaseInputError("JSON dari penerbit tidak valid."); }
}
