import { and, eq, inArray, isNull, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { episodes, episodeSyncState, notifications, watchlist } from "@/db/schema";
import type { ParsedEpisode } from "./validation";
import type { ImportResult } from "./types";
import { SYNC_KEY } from "./provider";

export type SyncCompletion = { token: string; sourceKey: string; cursor: string | null; intervalSeconds: number; rejected: number; warning: string | null };
const keyOf = (episode: { animeId: number; number: number }) => `${episode.animeId}:${episode.number}`;
function differs(old: typeof episodes.$inferSelect, next: ParsedEpisode) {
  // PostgreSQL jsonb may reorder object keys; compare a canonical form so a
  // repeated feed is truly unchanged instead of rewriting every row.
  const snapshot = (value: ParsedEpisode["anime"] | null) => value ? JSON.stringify(Object.entries(value).sort(([a], [b]) => a.localeCompare(b))) : "";
  return old.title !== next.title || old.videoUrl !== next.videoUrl || old.subtitleUrl !== next.subtitleUrl || old.releaseAt.getTime() !== next.releaseAt.getTime() || snapshot(old.anime) !== snapshot(next.anime);
}

export async function persistEpisodes(input: ParsedEpisode[], options: { source: "feed" | "webhook"; sync?: SyncCompletion; now?: Date }) {
  const now = options.now || new Date();
  const unique = [...new Map(input.map(episode => [keyOf(episode), episode])).values()];
  return db.transaction(async tx => {
    if (options.sync) {
      const [state] = await tx.select().from(episodeSyncState).where(eq(episodeSyncState.key, SYNC_KEY)).for("update");
      if (state?.runningToken !== options.sync.token || state.sourceKey !== options.sync.sourceKey || !state.leaseUntil || state.leaseUntil <= now) throw new Error("SYNC_LEASE_EXPIRED");
    }
    // One transaction-level lock shared by cron and webhooks prevents duplicate
    // notifications during overlapping imports. No in-memory scheduler is required.
    await tx.execute(sql`select pg_advisory_xact_lock(73201, 191)`);
    const animeIds = [...new Set(unique.map(e => e.animeId))];
    const previous = animeIds.length ? await tx.select().from(episodes).where(inArray(episodes.animeId, animeIds)) : [];
    const before = new Map(previous.map(episode => [keyOf(episode), episode]));
    const changed = unique.filter(episode => !before.has(keyOf(episode)) || differs(before.get(keyOf(episode))!, episode));
    const stored = new Map(previous.map(episode => [keyOf(episode), episode]));
    for (let index = 0; index < changed.length; index += 250) {
      const rows = await tx.insert(episodes).values(changed.slice(index, index + 250).map(episode => ({ ...episode, source: options.source, syncedAt: now }))).onConflictDoUpdate({
        target: [episodes.animeId, episodes.number],
        set: { title: sql`excluded.title`, videoUrl: sql`excluded.video_url`, subtitleUrl: sql`excluded.subtitle_url`, releaseAt: sql`excluded.release_at`, anime: sql`excluded.anime`, source: sql`excluded.source`, syncedAt: sql`excluded.synced_at` },
      }).returning();
      for (const row of rows) stored.set(keyOf(row), row);
    }
    const changedKeys = new Set(changed.map(keyOf));
    const followers = animeIds.length ? await tx.select().from(watchlist).where(inArray(watchlist.animeId, animeIds)) : [];
    const legacy = animeIds.length ? await tx.select({ userId: notifications.userId, animeId: notifications.animeId, title: notifications.title }).from(notifications).where(and(inArray(notifications.animeId, animeIds), isNull(notifications.episodeId), isNull(notifications.commentId))) : [];
    const legacyKeys = new Set(legacy.map(n => `${n.userId}:${n.animeId}:${n.title}`));
    const pendingNotifications: (typeof notifications.$inferInsert)[] = [];
    for (const item of unique) {
      const row = stored.get(keyOf(item))!;
      const title = `Episode ${item.number} sudah rilis!`;
      const body = `${item.anime.title} — ${item.title}`;
      if (changedKeys.has(keyOf(item))) {
        // Also update pre-sync notifications so postponements cannot leak early.
        await tx.update(notifications).set({ visibleAt: item.releaseAt, title, body, anime: item.anime }).where(or(eq(notifications.episodeId, row.id), and(isNull(notifications.episodeId), isNull(notifications.commentId), eq(notifications.animeId, item.animeId), eq(notifications.title, title))));
      }
      if (!before.has(keyOf(item)) || item.releaseAt > now) {
        for (const follower of followers.filter(f => f.animeId === item.animeId)) {
          if (legacyKeys.has(`${follower.userId}:${item.animeId}:${title}`)) continue;
          pendingNotifications.push({ userId: follower.userId, animeId: item.animeId, anime: item.anime, episodeId: row.id, title, body, visibleAt: item.releaseAt });
        }
      }
    }
    for (let index = 0; index < pendingNotifications.length; index += 500) {
      await tx.insert(notifications).values(pendingNotifications.slice(index, index + 500)).onConflictDoNothing({ target: [notifications.userId, notifications.episodeId] });
    }
    const result: ImportResult = {
      imported: unique.filter(e => !before.has(keyOf(e))).length,
      updated: changed.filter(e => before.has(keyOf(e))).length,
      unchanged: unique.length - changed.length,
      released: unique.filter(e => e.releaseAt <= now).length,
      scheduled: unique.filter(e => e.releaseAt > now).length,
      rejected: options.sync?.rejected || 0,
    };
    if (options.sync) {
      await tx.update(episodeSyncState).set({ state: result.rejected ? "partial" : "ready", runningToken: null, leaseUntil: null, cursor: options.sync.cursor, lastSuccessAt: now, nextAttemptAt: new Date(now.getTime() + options.sync.intervalSeconds * 1000), lastError: options.sync.warning?.slice(0, 500) || null, imported: result.imported, updated: result.updated, unchanged: result.unchanged, rejected: result.rejected }).where(and(eq(episodeSyncState.key, SYNC_KEY), eq(episodeSyncState.runningToken, options.sync.token)));
    }
    return { result, episodes: unique.map(item => stored.get(keyOf(item))!) };
  });
}
