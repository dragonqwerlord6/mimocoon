import { randomUUID } from "node:crypto";
import { and, eq, isNull, lte, ne, or } from "drizzle-orm";
import { db } from "@/db";
import { episodeSyncState } from "@/db/schema";
import { feedSettings, fetchProvider, readFeedJson, SYNC_KEY } from "./provider";
import { parseFeedPage, ReleaseInputError, type ParsedEpisode } from "./validation";
import { persistEpisodes } from "./persist";
import type { ImportResult, ReleaseSyncStatus } from "./types";

export type SyncResult = { state: "unconfigured" | "skipped" | "ready" | "partial" | "error"; message: string; result?: ImportResult; morePages?: boolean };
export async function syncEpisodes(options: { force?: boolean; fetcher?: typeof fetchProvider } = {}): Promise<SyncResult> {
  const settings = feedSettings();
  if (!settings.configured) return { state: "unconfigured", message: "Feed episode berlisensi belum dihubungkan. Tidak ada video yang diambil." };
  const now = new Date(); const token = randomUUID();
  await db.insert(episodeSyncState).values({ key: SYNC_KEY }).onConflictDoNothing();
  const [previous] = await db.select().from(episodeSyncState).where(eq(episodeSyncState.key, SYNC_KEY));
  const sourceChanged = previous.sourceKey !== settings.sourceKey;
  const due = or(isNull(episodeSyncState.nextAttemptAt), lte(episodeSyncState.nextAttemptAt, now), isNull(episodeSyncState.sourceKey), ne(episodeSyncState.sourceKey, settings.sourceKey));
  const claimed = await db.update(episodeSyncState).set({ state: "running", sourceKey: settings.sourceKey, runningToken: token, leaseUntil: new Date(now.getTime() + 120000), lastAttemptAt: now, ...(sourceChanged ? { cursor: null, lastSuccessAt: null } : {}) }).where(and(eq(episodeSyncState.key, SYNC_KEY), or(isNull(episodeSyncState.leaseUntil), lte(episodeSyncState.leaseUntil, now)), options.force ? undefined : due)).returning();
  if (!claimed.length) return { state: "skipped", message: "Sinkronisasi lain sedang berjalan atau interval pemeriksaan belum tiba." };
  try {
    let cursor = claimed[0].cursor;
    const seen = new Set<string>();
    const entries: ParsedEpisode[] = []; const errors: string[] = [];
    const signal = AbortSignal.timeout(40000);
    const fetcher = options.fetcher || fetchProvider;
    // Persist a continuation cursor for large backlogs instead of timing out.
    for (let page = 0; page < 3; page++) {
      if (cursor && seen.has(cursor)) throw new ReleaseInputError("Penerbit mengirim cursor berulang; halaman dihentikan.");
      if (cursor) seen.add(cursor);
      const url = new URL(settings.url);
      if (cursor) url.searchParams.set("cursor", cursor);
      const headers: Record<string, string> = { Accept: "application/json", "User-Agent": "animeil.al/1.0 licensed-episode-sync" };
      if (settings.token) headers.Authorization = `Bearer ${settings.token}`;
      const response = await fetcher(url.toString(), { headers, signal, redirect: "error", cache: "no-store" });
      const parsed = parseFeedPage(await readFeedJson(response));
      entries.push(...parsed.episodes); errors.push(...parsed.errors); cursor = parsed.nextCursor;
      if (!cursor) break;
    }
    const { result } = await persistEpisodes(entries, { source: "feed", sync: { token, sourceKey: settings.sourceKey, cursor, intervalSeconds: settings.intervalSeconds, rejected: errors.length, warning: errors.length ? `${errors.length} entri tidak valid diabaikan. ${errors[0]}` : null } });
    return { state: errors.length ? "partial" : "ready", result, morePages: !!cursor, message: `${result.imported} episode baru, ${result.updated} diperbarui. ${result.released} sudah waktunya tayang dan ${result.scheduled} menunggu jadwal.${errors.length ? ` ${errors.length} entri tidak valid dilewati.` : ""}` };
  } catch (error) {
    const message = error instanceof ReleaseInputError ? error.message : "Sumber episode belum dapat dihubungi atau disimpan. Pemeriksaan akan dicoba kembali; episode tersimpan tetap tersedia.";
    await db.update(episodeSyncState).set({ state: "error", runningToken: null, leaseUntil: null, lastError: message.slice(0, 500), nextAttemptAt: new Date(Date.now() + settings.intervalSeconds * 1000) }).where(and(eq(episodeSyncState.key, SYNC_KEY), eq(episodeSyncState.runningToken, token)));
    return { state: "error", message };
  }
}

export async function releaseSyncStatus(): Promise<ReleaseSyncStatus> {
  const settings = feedSettings();
  const webhook = !!process.env.RELEASE_WEBHOOK_SECRET?.trim();
  const base = { configured: settings.configured, mode: settings.configured ? "feed" as const : webhook ? "webhook" as const : "none" as const, intervalMinutes: Math.ceil(settings.intervalSeconds / 60), lastSuccessAt: null, nextCheckAt: null };
  if (!settings.configured) return { ...base, state: "unconfigured", label: webhook ? "Menunggu penerbit" : "Menunggu sumber", message: webhook ? "Webhook siap menerima episode berlisensi. Pengambilan feed berkala belum dikonfigurasi." : "Feed video berlisensi belum terhubung. Sistem belum mengambil episode; trailer dan katalog tetap bisa dibuka." };
  const [row] = await db.select().from(episodeSyncState).where(eq(episodeSyncState.key, SYNC_KEY));
  if (!row || row.sourceKey !== settings.sourceKey) return { ...base, state: "waiting", label: "Menunggu sinkronisasi", message: "Sumber sudah dikonfigurasi. Menunggu pengambilan pertama dari penerbit." };
  const isRunning = row.state === "running" && row.leaseUntil && row.leaseUntil > new Date();
  const state = isRunning ? "running" : row.state === "running" ? "waiting" : ["ready", "partial", "error"].includes(row.state) ? row.state as "ready" | "partial" | "error" : "waiting";
  const labels = { running: "Sedang disinkronkan", waiting: "Menunggu pemeriksaan", ready: "Sinkronisasi aktif", partial: "Sebagian data dilewati", error: "Sumber belum merespons" };
  const messages = { running: "Memeriksa episode baru dan perubahan jadwal dari penerbit.", waiting: "Pemeriksaan sumber akan dilanjutkan pada kesempatan berikutnya.", ready: "Episode yang sudah rilis langsung tersedia. Episode mendatang terbuka otomatis sesuai waktu penerbit.", partial: `${row.rejected} entri tidak valid dilewati. Episode lain tetap disimpan sesuai jadwal.`, error: "Pemeriksaan terakhir belum berhasil. Episode yang sudah tersimpan tidak dihapus; sistem akan mencoba lagi." };
  return { ...base, state, label: labels[state], message: messages[state], lastSuccessAt: row.lastSuccessAt?.toISOString() || null, nextCheckAt: row.nextAttemptAt?.toISOString() || null };
}
