// This allowlist controls a visual account badge only. It must never grant
// administrator permissions or claim that email ownership has been verified.
// Use the email stored on the authenticated account, never a request-body flag.
const OWNER_BADGE_EMAIL = "ilfil1087@gmail.com";

export function hasOwnerBadge(email: string | null | undefined): boolean {
  return typeof email === "string" && email.trim().toLowerCase() === OWNER_BADGE_EMAIL;
}
