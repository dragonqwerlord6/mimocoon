import type { PublicUser } from "./catalog";
import { hasOwnerBadge } from "./verification";

type ProfileSource = Pick<PublicUser, "id" | "name" | "email" | "emailVerified">;

// Used by the server for session, sign-in, and comment-author responses.
// `verified` is the legacy name for the orange display badge; emailVerified
// remains an independent, truthful record of email ownership verification.
export function publicUser(user: ProfileSource): PublicUser {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    emailVerified: user.emailVerified,
    verified: hasOwnerBadge(user.email),
  };
}
