#!/usr/bin/env python3
"""Create a reproducible, secret-free source ZIP using Python's standard library."""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "public" / "downloads" / "animeil-al-source.zip"
PREFIX = "animeil-al/"
ROOT_FILES = (
    ".env.example", ".gitignore", ".vercelignore", ".nvmrc",
    "README.md", "DEPLOYMENT.md", "EPISODE_SYNC.md", "THIRD_PARTY_NOTICES.md",
    "package.json", "package-lock.json", "tsconfig.json", "next-env.d.ts",
    "next.config.ts", "postcss.config.mjs", "eslint.config.mjs",
    "drizzle.config.ts", "playwright.config.ts", "vercel.json", "docker-compose.yml",
)
SOURCE_DIRS = ("src", "public", "tests", "scripts", "drizzle")
BLOCKED_PARTS = {
    "node_modules", ".next", ".git", ".vercel", ".idea", ".vscode",
    "coverage", "artifacts", "test-results", "playwright-report", "__pycache__",
}
BLOCKED_SUFFIXES = (".zip", ".tar", ".gz", ".log", ".tsbuildinfo", ".pyc", ".pem", ".key", ".p12", ".pfx", ".dump", ".backup")
TEXT_SUFFIXES = {".ts", ".tsx", ".js", ".mjs", ".cjs", ".json", ".md", ".sql", ".py", ".yml", ".yaml", ".css", ".txt"}


def forbidden(relative):
    path = PurePosixPath(relative)
    if path.is_absolute() or ".." in path.parts or "\\" in relative:
        return True
    if any(part in BLOCKED_PARTS for part in path.parts):
        return True
    if path.name.startswith(".env") and relative != ".env.example":
        return True
    if path.name in {".npmrc", ".yarnrc", ".DS_Store", "Thumbs.db"}:
        return True
    if path.name.lower().endswith(BLOCKED_SUFFIXES):
        return True
    return relative == "public/downloads" or relative.startswith("public/downloads/")


def sensitive_values():
    keys = {"DATABASE_URL", "DATABASE_DIRECT_URL", "RESEND_API_KEY", "RELEASE_WEBHOOK_SECRET", "POSTGRES_PASSWORD", "EPISODE_FEED_URL", "EPISODE_FEED_TOKEN", "CRON_SECRET"}
    values = {os.environ[key] for key in keys if os.environ.get(key)}
    for filename in (".env", ".env.local"):
        path = ROOT / filename
        if not path.is_file():
            continue
        for line in path.read_text(encoding="utf-8").splitlines():
            key, sep, value = line.partition("=")
            if sep and key.strip() in keys:
                value = value.strip().strip("\"'")
                if value:
                    values.add(value)
    # Very short local passwords can occur in ordinary text. Actual .env files
    # are always excluded, regardless of length; longer known secrets are scanned.
    return [value.encode() for value in values if len(value) >= 12]


def collect_sources():
    paths = []
    for filename in ROOT_FILES:
        path = ROOT / filename
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"Required source file missing or unsafe: {filename}")
        paths.append(path)
    for dirname in SOURCE_DIRS:
        folder = ROOT / dirname
        if not folder.is_dir() or folder.is_symlink():
            raise ValueError(f"Required source directory missing or unsafe: {dirname}")
        for current, directories, files in os.walk(folder, followlinks=False):
            current_path = Path(current)
            directories[:] = [name for name in directories if not (current_path / name).is_symlink() and not forbidden((current_path / name).relative_to(ROOT).as_posix())]
            for name in files:
                path = current_path / name
                relative = path.relative_to(ROOT).as_posix()
                if forbidden(relative):
                    continue
                if path.is_symlink():
                    raise ValueError(f"Symlink refused: {relative}")
                paths.append(path)
    paths = sorted(set(paths), key=lambda path: path.relative_to(ROOT).as_posix())
    if not any(path.suffix == ".sql" and path.relative_to(ROOT).parts[0] == "drizzle" for path in paths):
        raise ValueError("Initial SQL migration missing. Run npx drizzle-kit generate --name=initial first.")
    package = json.loads((ROOT / "package.json").read_text())
    lock = json.loads((ROOT / "package-lock.json").read_text())
    locked_root = lock.get("packages", {}).get("", {})
    for key in ("dependencies", "devDependencies"):
        if package.get(key, {}) != locked_root.get(key, {}):
            raise ValueError("package-lock.json does not match package.json. Regenerate the lockfile using npm tooling.")
    secrets = sensitive_values()
    data = {}
    for path in paths:
        relative = path.relative_to(ROOT).as_posix()
        content = path.read_bytes()
        if path.suffix in TEXT_SUFFIXES or path.name.startswith("."):
            if any(value in content for value in secrets):
                raise ValueError(f"Possible configured secret in source: {relative}; archive was not written.")
            if re.search(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----", content):
                raise ValueError(f"Private key refused: {relative}")
        data[relative] = content
    return data


def verify_archive(path):
    with zipfile.ZipFile(path, "r") as archive:
        if archive.testzip() is not None:
            raise ValueError("Archive integrity check failed.")
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate archive entries found.")
        for name in names:
            if not name.startswith(PREFIX) or forbidden(name[len(PREFIX):]):
                raise ValueError(f"Unsafe or excluded archive entry: {name}")
            if (archive.getinfo(name).external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("Symbolic links are not allowed in the archive.")
        manifest = json.loads(archive.read(PREFIX + "SOURCE-MANIFEST.json"))
        expected = {PREFIX + item["path"] for item in manifest["files"]}
        expected.add(PREFIX + "SOURCE-MANIFEST.json")
        if set(names) != expected:
            raise ValueError("Archive contents do not match SOURCE-MANIFEST.json.")
        for item in manifest["files"]:
            content = archive.read(PREFIX + item["path"])
            if len(content) != item["bytes"] or hashlib.sha256(content).hexdigest() != item["sha256"]:
                raise ValueError(f"Checksum mismatch: {item['path']}")
        for filename in ROOT_FILES:
            if PREFIX + filename not in names:
                raise ValueError(f"Required archive entry missing: {filename}")
    return len(names)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true", help="Verify the existing ZIP and its external SHA-256 file without rebuilding.")
    args = parser.parse_args()
    if args.verify:
        count = verify_archive(OUTPUT)
        digest = hashlib.sha256(OUTPUT.read_bytes()).hexdigest()
        expected = OUTPUT.with_suffix(".zip.sha256").read_text().split()[0]
        if expected != digest:
            raise ValueError("External archive checksum mismatch.")
        print(f"Verified: {count} files, {OUTPUT.stat().st_size} bytes, SHA-256 {digest}")
        return

    data = collect_sources()
    manifest = {
        "application": "animeil.al",
        "formatVersion": 1,
        "notes": [
            "Source and assets only; no real environment secrets or user/database data.",
            "Dependencies and build outputs are excluded; follow DEPLOYMENT.md.",
            "The archive manifest lists all entries except the manifest itself.",
        ],
        "files": [{"path": relative, "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()} for relative, content in data.items()],
    }
    data["SOURCE-MANIFEST.json"] = (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode()
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    temporary = OUTPUT.with_suffix(".zip.tmp")
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for relative, content in sorted(data.items()):
                info = zipfile.ZipInfo(PREFIX + relative, date_time=(1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                archive.writestr(info, content, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        count = verify_archive(temporary)
        temporary.replace(OUTPUT)
    finally:
        if temporary.exists():
            temporary.unlink()
    digest = hashlib.sha256(OUTPUT.read_bytes()).hexdigest()
    OUTPUT.with_suffix(".zip.sha256").write_text(f"{digest}  {OUTPUT.name}\n", encoding="utf-8")
    print(f"Created {OUTPUT.relative_to(ROOT)}")
    print(f"Files: {count}; bytes: {OUTPUT.stat().st_size}; SHA-256: {digest}")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, zipfile.BadZipFile) as error:
        print(f"Export failed: {error}", file=sys.stderr)
        sys.exit(1)
