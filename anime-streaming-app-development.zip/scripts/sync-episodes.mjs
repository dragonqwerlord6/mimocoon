import { config } from "dotenv";
config({ path: ".env.local", quiet: true });
config({ path: ".env", quiet: true });

if (process.argv.includes("--help")) {
  console.log("node scripts/sync-episodes.mjs [--force]");
  console.log("Panggil dari cron lokal atau scheduler eksternal. Memerlukan APP_URL dan CRON_SECRET. Tidak menampilkan token atau URL sumber.");
  process.exit(0);
}

try {
  if (!process.env.APP_URL || !process.env.CRON_SECRET) throw new Error("APP_URL dan CRON_SECRET belum diatur.");
  const url = new URL("/api/cron/episodes", process.env.APP_URL);
  if (url.protocol !== "https:" && !(url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname))) throw new Error("APP_URL harus HTTPS, kecuali pengujian localhost.");
  if (process.argv.includes("--force")) url.searchParams.set("force", "1");
  const response = await fetch(url, { method: "POST", headers: { Authorization: `Bearer ${process.env.CRON_SECRET}` }, signal: AbortSignal.timeout(60000), redirect: "error" });
  const result = await response.json();
  console.log(JSON.stringify({ status: response.status, state: result.state, message: result.message || result.error, result: result.result, morePages: result.morePages }, null, 2));
  if (!response.ok) process.exitCode = 1;
} catch (error) {
  console.error(error instanceof Error && /belum diatur|harus HTTPS/.test(error.message) ? error.message : "Sinkronisasi belum dapat dijalankan. Periksa konfigurasi dan koneksi aplikasi.");
  process.exitCode = 1;
}
