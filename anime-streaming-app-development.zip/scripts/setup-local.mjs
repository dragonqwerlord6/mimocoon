import { randomBytes } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const target = join(root, ".env");

if (process.argv.includes("--help")) {
  console.log("Jalankan dari source yang diekstrak: node scripts/setup-local.mjs");
  console.log("Membuat .env lokal dengan sandi database acak. Tidak menimpa .env/.env.local dan tidak menjalankan atau menghapus database.");
  process.exit(0);
}

if (existsSync(target) || existsSync(join(root, ".env.local"))) {
  console.log("Konfigurasi .env/.env.local sudah ada; tidak ada file atau sandi yang diubah.");
  console.log("Gunakan konfigurasi yang ada, atau atur sendiri sesuai DEPLOYMENT.md.");
  process.exit(0);
}

const password = randomBytes(24).toString("hex");
let contents = readFileSync(join(root, ".env.example"), "utf8");
const values = {
  DATABASE_URL: `postgresql://animeil:${password}@127.0.0.1:5432/animeil`,
  POSTGRES_PASSWORD: password,
};
for (const [key, value] of Object.entries(values)) {
  const pattern = new RegExp(`^${key}=.*$`, "m");
  if (!pattern.test(contents)) throw new Error(`Template .env.example tidak memiliki ${key}.`);
  contents = contents.replace(pattern, `${key}=${value}`);
}
writeFileSync(target, contents, { flag: "wx", mode: 0o600 });
console.log(".env lokal dibuat. Sandi database acak disimpan hanya di .env, tidak ditampilkan di terminal.");
console.log("Langkah berikut: docker compose up -d --wait db");
console.log("Lalu: npx drizzle-kit migrate");
console.log("Terakhir: npm run dev → http://localhost:3000");
