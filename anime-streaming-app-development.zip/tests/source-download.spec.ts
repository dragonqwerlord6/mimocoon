import { createHash } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { expect, test } from "@playwright/test";

const archivePath = resolve("public/downloads/animeil-al-source.zip");

test("ZIP source dapat diunduh sebagai lampiran dan checksum cocok", async ({ request }) => {
  // A fresh source checkout intentionally does not publish its own source ZIP.
  test.skip(!existsSync(archivePath), "Jalankan python3 scripts/export-source.py untuk menguji unduhan ZIP.");
  const response = await request.get("/downloads/animeil-al-source.zip");
  expect(response.status()).toBe(200);
  expect(response.headers()["content-type"]).toContain("application/zip");
  expect(response.headers()["content-disposition"]).toContain('attachment; filename="animeil-al-source.zip"');
  expect(response.headers()["x-content-type-options"]).toBe("nosniff");
  const body = await response.body();
  expect(body.subarray(0, 4).toString("hex")).toBe("504b0304");
  expect(body.equals(readFileSync(archivePath))).toBe(true);
  const checksumResponse = await request.get("/downloads/animeil-al-source.zip.sha256");
  expect(checksumResponse.status()).toBe(200);
  const expected = (await checksumResponse.text()).trim().split(/\s+/)[0];
  expect(createHash("sha256").update(body).digest("hex")).toBe(expected);
});
