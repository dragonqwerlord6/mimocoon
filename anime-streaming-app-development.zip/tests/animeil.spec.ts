import "dotenv/config";
import { test, expect, request as makeRequest } from "@playwright/test";
import { randomBytes, createHash } from "node:crypto";
import { eq, inArray } from "drizzle-orm";
import { db } from "../src/db";
import { users, episodes, passwordResetTokens } from "../src/db/schema";
import { catalog } from "../src/lib/catalog";
import { hasOwnerBadge } from "../src/lib/verification";

const suffix = randomBytes(7).toString("hex");
const emails = ["a", "b", "ui", "recovery", "recovery-ui"].map(n => `test-${n}-${suffix}@example.com`);
const password = randomBytes(18).toString("hex");
const testAnimeId = 9900123;
const baseURL = process.env.TEST_BASE_URL || "http://localhost:3000";

test.afterAll(async () => {
  await db.delete(users).where(inArray(users.email, emails));
  await db.delete(episodes).where(eq(episodes.animeId, testAnimeId));
  // The Playwright worker shares this pool with the episode integration tests.
});

test("Centang oranye hanya untuk alamat email yang ditentukan", () => {
  expect(hasOwnerBadge("ilfil1087@gmail.com")).toBe(true);
  expect(hasOwnerBadge("  ILFIL1087@GMAIL.COM  ")).toBe(true);
  expect(hasOwnerBadge("pengguna@example.com")).toBe(false);
  expect(hasOwnerBadge("ilfil1087@gmail.com.example.com")).toBe(false);
  expect(hasOwnerBadge("ilfil1087+lain@gmail.com")).toBe(false);
  expect(hasOwnerBadge("ilfil1087@googlemail.com")).toBe(false);
  expect(hasOwnerBadge("ilfil1087@gmail.com\u200b")).toBe(false);
  expect(hasOwnerBadge(null)).toBe(false);
  expect(hasOwnerBadge(undefined)).toBe(false);
});

test("Beranda, carousel, pencarian, dialog dan navigasi ponsel", async ({ page }) => {
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto("/");
  await expect(page.getByRole("heading", { name: /Petualangan belum/ })).toBeVisible();
  await expect(page.locator(".popular-section .anime-card")).toHaveCount(6);
  await page.getByRole("button", { name: "Anime pilihan berikutnya" }).click();
  await expect(page.getByRole("heading", { name: /Bangkit. Lebih kuat/ })).toBeVisible();
  await page.getByRole("button", { name: "Anime pilihan sebelumnya" }).click();
  await page.getByRole("button", { name: "Mulai menonton", exact: true }).click();
  await expect(page.getByRole("dialog", { name: "Frieren: Beyond Journey’s End" })).toBeVisible();
  await page.getByRole("button", { name: "Komentar & rating" }).click();
  await page.getByRole("button", { name: "Beri rating 8 dari 10" }).click();
  await expect(page.getByRole("dialog", { name: "Masuk ke animeil.al" })).toBeVisible();
  await page.getByRole("dialog", { name: "Masuk ke animeil.al" }).getByRole("button", { name: "Tutup dialog" }).click();
  await page.getByRole("button", { name: "Tutup dialog" }).click();
  await page.getByRole("textbox", { name: "Cari anime", exact: true }).fill("Frieren");
  await expect(page.locator(".catalog-grid .anime-card")).toHaveCount(1);
  await expect(page.locator(".anime-title")).toHaveText("Frieren: Beyond Journey’s End");
  await page.locator("aside").getByRole("button", { name: "Beranda", exact: true }).click();
  await page.setViewportSize({ width: 390, height: 844 });
  await expect(page.getByRole("navigation", { name: "Navigasi cepat" })).toBeVisible();
  await page.locator(".search-box").click();
  await expect(page.getByRole("textbox", { name: "Cari anime", exact: true })).toBeFocused();
  await page.getByRole("textbox", { name: "Cari anime", exact: true }).fill("Kaiju");
  await expect(page.locator(".anime-title")).toHaveText("Kaiju No. 8");
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  expect(errors).toEqual([]);
});

test("Akun, koleksi, suka, rating, balasan dan notifikasi tersimpan", async () => {
  const a = await makeRequest.newContext({ baseURL });
  const b = await makeRequest.newContext({ baseURL });
  const guest = await makeRequest.newContext({ baseURL });
  const registerA = await a.post("/api/auth", { data: { action: "register", email: emails[0], name: "Penguji Satu", password, verified: true, emailVerified: true } });
  expect(registerA.status()).toBe(201);
  expect((await registerA.json()).user.verified).toBe(false);
  const registerB = await b.post("/api/auth", { data: { action: "register", email: emails[1], name: "Penguji Dua", password } });
  expect(registerB.status()).toBe(201);
  await db.update(users).set({ emailVerified: true }).where(eq(users.email, emails[1]));
  expect((await (await b.get("/api/auth")).json()).user.verified).toBe(false);
  const save = await a.post("/api/library", { data: { action: "save", anime: catalog[6] } });
  expect((await save.json()).saved).toBe(true);
  expect((await (await a.get("/api/library")).json()).saved[0].id).toBe(52991);
  await a.post("/api/library", { data: { action: "progress", anime: catalog[6], episode: 0, progress: 20, duration: 90 } });
  expect((await (await a.get("/api/library")).json()).history[0].progress).toBe(20);
  await a.post("/api/community", { data: { action: "like", animeId: testAnimeId } });
  await a.post("/api/community", { data: { action: "rate", animeId: testAnimeId, score: 8 } });
  await a.post("/api/community", { data: { action: "rate", animeId: testAnimeId, score: 10 } });
  let stats = await (await a.get(`/api/community?animeId=${testAnimeId}`)).json();
  expect(stats.stats).toEqual({ likes: 1, rating: 10, votes: 1 });
  expect(stats.liked).toBe(true);
  const parent = (await (await a.post("/api/community", { data: { action: "comment", animeId: testAnimeId, text: "Ceritanya menarik, mari berdiskusi!" } })).json()).comment;
  const reply = (await (await b.post("/api/community", { data: { action: "comment", animeId: testAnimeId, parentId: parent.id, text: "Setuju, perjalanan karakternya sangat bagus." } })).json()).comment;
  await b.post("/api/community", { data: { action: "commentLike", animeId: testAnimeId, commentId: parent.id } });
  stats = await (await b.get(`/api/community?animeId=${testAnimeId}`)).json();
  expect(stats.comments.find((c: { id: string }) => c.id === parent.id).likes).toBe(1);
  expect(stats.comments.find((c: { id: string }) => c.id === reply.id).parentId).toBe(parent.id);
  const notification = (await (await a.get("/api/notifications")).json()).notifications.find((n: { commentId: string }) => n.commentId === reply.id);
  expect(notification.read).toBe(false);
  expect(notification.title).toContain("Penguji Dua");
  expect((await (await b.get("/api/notifications")).json()).notifications).toHaveLength(0);
  await a.post("/api/notifications", { data: { id: notification.id } });
  expect((await (await a.get("/api/notifications")).json()).notifications[0].read).toBe(true);
  expect((await guest.post("/api/community", { data: { action: "like", animeId: testAnimeId } })).status()).toBe(401);
  expect((await a.post("/api/community", { data: { action: "comment", animeId: testAnimeId, text: "  " } })).status()).toBe(400);
  expect((await a.post("/api/community", { headers: { Origin: "https://not-the-app.example.com" }, data: { action: "like", animeId: testAnimeId } })).status()).toBe(403);
  await a.post("/api/auth", { data: { action: "logout" } });
  expect((await (await a.get("/api/auth")).json()).user).toBeNull();
  expect((await a.post("/api/auth", { data: { action: "login", email: emails[0], password: "incorrect-password" } })).status()).toBe(401);
  expect((await a.post("/api/auth", { data: { action: "login", email: emails[0], password } })).status()).toBe(200);
  expect((await (await a.get("/api/library")).json()).saved[0].id).toBe(52991);
  await Promise.all([a.dispose(), b.dispose(), guest.dispose()]);
});

test("Rilis terjadwal disembunyikan lalu terbit otomatis", async ({ request }) => {
  await db.insert(episodes).values({ animeId: testAnimeId, number: 1, title: "Pengujian rilis terjadwal", videoUrl: "https://example.com/licensed-test.mp4", subtitleUrl: "https://example.com/subtitle-id.vtt", releaseAt: new Date(Date.now() + 1800) });
  expect((await (await request.get(`/api/releases?animeId=${testAnimeId}`)).json()).episodes).toHaveLength(0);
  await new Promise(resolve => setTimeout(resolve, 1950));
  const released = await (await request.get(`/api/releases?animeId=${testAnimeId}`)).json();
  expect(released.episodes).toHaveLength(1);
  expect(released.episodes[0].number).toBe(1);
  const unauthorized = await request.post("/api/releases", { data: { animeId: testAnimeId } });
  expect([401, 503]).toContain(unauthorized.status());
});

test("Pendaftaran dan komentar melalui antarmuka", async ({ page }) => {
  await page.goto("/");
  await page.locator(".profile-button").click();
  const dialog = page.getByRole("dialog");
  await dialog.getByRole("button", { name: "Daftar", exact: true }).click();
  await dialog.getByLabel("Nama pengguna").fill("Penguji Antarmuka");
  await dialog.getByLabel("Alamat email").fill(emails[2]);
  await dialog.getByLabel("Kata sandi", { exact: true }).fill(password);
  await dialog.getByRole("button", { name: "Buat akun gratis", exact: true }).click();
  await expect(page.locator(".profile-copy")).toContainText("Penguji Antarmuka");
  await expect(page.locator(".profile-button .verified-badge")).toHaveCount(0);
  await page.locator("aside").getByRole("button", { name: "Komunitas", exact: true }).click();
  const comment = `Obrolan pengujian antarmuka ${suffix}`;
  await page.getByRole("textbox", { name: "Tulis komentar", exact: true }).fill(comment);
  await page.getByRole("button", { name: "Kirim komentar", exact: true }).click();
  await expect(page.getByText(comment, { exact: true })).toBeVisible();
  const item = page.locator("article.comment").filter({ hasText: comment });
  await item.getByRole("button", { name: "Sukai komentar", exact: true }).click();
  await expect(item.getByRole("button", { name: "Batal menyukai komentar", exact: true })).toBeVisible();
  await page.locator(".profile-button").click();
  await page.getByRole("button", { name: "Keluar dari akun", exact: true }).click();
  await expect(page.locator(".profile-copy")).toContainText("Masuk / Daftar");
});


test("Pesan sandi salah memberi petunjuk dan pemulihan tidak berpura-pura aktif", async ({ page, request }) => {
  const availability = await (await request.get("/api/auth/password")).json();
  await page.goto("/");
  await page.locator(".profile-button").click();
  const login = page.getByRole("dialog", { name: "Masuk ke animeil.al" });
  await expect(login.getByText(/Tidak ada sandi bawaan/)).toBeVisible();
  await login.getByLabel("Alamat email", { exact: true }).fill("nobody-registered@example.invalid");
  await login.getByLabel("Kata sandi", { exact: true }).fill("not-a-real-account-password");
  await login.getByRole("button", { name: "Masuk ke akun", exact: true }).click();
  await expect(login.getByRole("alert")).toContainText("Email atau kata sandi tidak cocok");
  await expect(login.getByRole("alert")).toContainText("Pilih Daftar");
  await login.getByRole("button", { name: "Lupa kata sandi?", exact: true }).click();
  const forgot = page.getByRole("dialog", { name: "Lupa kata sandi", exact: true });
  await expect(forgot).toBeVisible();
  await expect(forgot.getByLabel("Alamat email", { exact: true })).toHaveValue("nobody-registered@example.invalid");
  if (availability.available) {
    await expect(forgot.getByRole("button", { name: "Kirim tautan pemulihan", exact: true })).toBeEnabled();
    await forgot.getByRole("button", { name: "Kirim tautan pemulihan", exact: true }).click();
    await expect(page.getByRole("dialog", { name: "Permintaan pemulihan akun" }).getByRole("status")).toContainText("Jika email tersebut terdaftar");
  } else {
    await expect(forgot.getByRole("status")).toContainText("Pemulihan lewat email belum aktif");
    await expect(forgot.getByRole("button", { name: "Kirim tautan pemulihan", exact: true })).toBeDisabled();
    await forgot.getByRole("button", { name: "Buat akun baru", exact: true }).click();
    await expect(page.getByRole("dialog", { name: "Buat akun animeil.al" })).toBeVisible();
  }
});

test("Endpoint pemulihan memvalidasi permintaan dan menyatakan status email dengan jujur", async ({ request }) => {
  const statusResponse = await request.get("/api/auth/password");
  expect(statusResponse.headers()["cache-control"]).toContain("no-store");
  const status = await statusResponse.json();
  expect(typeof status.available).toBe("boolean");
  const requested = await request.post("/api/auth/password", { data: { action: "request", email: "no-account-to-mail@example.invalid" } });
  expect(requested.status()).toBe(status.available ? 202 : 503);
  const body = await requested.json();
  expect(body.token).toBeUndefined();
  if (!status.available) expect(body.error).toContain("Pemulihan lewat email belum aktif");
  expect((await request.post("/api/auth/password", { data: { action: "request", email: "invalid-email" } })).status()).toBe(400);
  expect((await request.post("/api/auth/password", { data: { action: "reset", password, confirmPassword: password } })).status()).toBe(400);
  expect((await request.post("/api/auth/password", { headers: { Origin: "https://not-the-app.example.com" }, data: { action: "request", email: "no-account@example.invalid" } })).status()).toBe(403);
});

test("Reset sekali pakai menolak token kedaluwarsa, mengganti sandi dan mengakhiri sesi lama", async () => {
  const a = await makeRequest.newContext({ baseURL });
  const b = await makeRequest.newContext({ baseURL });
  const registered = await a.post("/api/auth", { data: { action: "register", email: emails[3], name: "Penguji Pemulihan", password } });
  expect(registered.status()).toBe(201);
  const userId = (await registered.json()).user.id;
  expect((await b.post("/api/auth", { data: { action: "login", email: emails[3], password } })).status()).toBe(200);
  const token = randomBytes(32).toString("hex");
  const tokenHash = createHash("sha256").update(token).digest("hex");
  const newPassword = randomBytes(18).toString("hex");
  const payload = { action: "reset", token, password: newPassword, confirmPassword: newPassword };
  await db.insert(passwordResetTokens).values({ userId, tokenHash, expiresAt: new Date(Date.now() - 1000) });
  const expired = await a.post("/api/auth/password", { data: payload });
  expect(expired.status()).toBe(400);
  expect((await expired.json()).error).toContain("kedaluwarsa");
  expect((await (await b.get("/api/auth")).json()).user.id).toBe(userId);
  await db.update(passwordResetTokens).set({ expiresAt: new Date(Date.now() + 1800000) }).where(eq(passwordResetTokens.userId, userId));
  expect((await a.post("/api/auth/password", { data: { ...payload, confirmPassword: "different-password" } })).status()).toBe(400);
  expect((await a.post("/api/auth/password", { data: { ...payload, password: "short", confirmPassword: "short" } })).status()).toBe(400);
  const changed = await a.post("/api/auth/password", { data: payload });
  expect(changed.status()).toBe(200);
  expect((await changed.json()).message).toContain("Kata sandi berhasil diperbarui");
  expect((await (await a.get("/api/auth")).json()).user).toBeNull();
  expect((await (await b.get("/api/auth")).json()).user).toBeNull();
  expect((await a.post("/api/auth/password", { data: payload })).status()).toBe(400);
  expect((await a.post("/api/auth", { data: { action: "login", email: emails[3], password } })).status()).toBe(401);
  const loggedIn = await a.post("/api/auth", { data: { action: "login", email: emails[3], password: newPassword } });
  expect(loggedIn.status()).toBe(200);
  const user = (await loggedIn.json()).user;
  expect(user.emailVerified).toBe(true);
  expect(user.verified).toBe(false);
  const [stored] = await db.select().from(users).where(eq(users.id, userId));
  expect(stored.passwordHash).not.toBe(newPassword);
  expect(await db.select().from(passwordResetTokens).where(eq(passwordResetTokens.userId, userId))).toHaveLength(0);
  await Promise.all([a.dispose(), b.dispose()]);
});

test("Tautan reset di ponsel menyembunyikan token dan menerima sandi baru", async ({ page, request }) => {
  const registered = await request.post("/api/auth", { data: { action: "register", email: emails[4], name: "Penguji Reset Ponsel", password } });
  expect(registered.status()).toBe(201);
  const userId = (await registered.json()).user.id;
  const token = randomBytes(32).toString("hex");
  await db.insert(passwordResetTokens).values({ userId, tokenHash: createHash("sha256").update(token).digest("hex"), expiresAt: new Date(Date.now() + 1800000) });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/#reset=" + token);
  const reset = page.getByRole("dialog", { name: "Atur ulang kata sandi", exact: true });
  await expect(reset).toBeVisible();
  await expect.poll(() => page.url()).not.toContain(token);
  const newPassword = randomBytes(18).toString("hex");
  await reset.getByLabel("Kata sandi baru", { exact: true }).fill(newPassword);
  await reset.getByLabel("Ulangi kata sandi baru", { exact: true }).fill("different-new-password");
  await reset.getByRole("button", { name: "Simpan sandi baru", exact: true }).click();
  await expect(reset.getByRole("alert")).toContainText("Kedua kata sandi belum sama");
  await reset.getByLabel("Ulangi kata sandi baru", { exact: true }).fill(newPassword);
  await reset.getByRole("button", { name: "Simpan sandi baru", exact: true }).click();
  const login = page.getByRole("dialog", { name: "Masuk ke animeil.al" });
  await expect(login.getByRole("status")).toContainText("Kata sandi berhasil diperbarui");
  await login.getByLabel("Alamat email", { exact: true }).fill(emails[4]);
  await login.getByLabel("Kata sandi", { exact: true }).fill(newPassword);
  await login.getByRole("button", { name: "Masuk ke akun", exact: true }).click();
  await expect(login).not.toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});
