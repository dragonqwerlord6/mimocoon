import { expect, test, type Page } from "@playwright/test";
import { publicUser } from "../src/lib/user-profile";
import type { PublicUser } from "../src/lib/catalog";

// Presentation fixtures only. Never create, sign into, or modify the owner's
// actual account or its password to test a display badge.
const ownerSource = {
  id: "c82d253c-2805-44a2-bf4e-1d73fbf86890",
  name: "alfn",
  email: "ilfil1087@gmail.com",
  emailVerified: false,
};
const memberSource = {
  id: "fbece14e-e0e0-461a-b82b-922f430df3ae",
  name: "Pembaca Anime",
  email: "member-badge-test@example.invalid",
  emailVerified: true,
};

async function mockSession(page: Page, user: PublicUser | null) {
  await page.route("**/api/auth", async route => {
    if (route.request().method() === "GET") await route.fulfill({ json: { user }, headers: { "Cache-Control": "no-store" } });
    else await route.continue();
  });
  await page.route("**/api/library", route => route.fulfill({ json: { saved: [], history: [] } }));
  await page.route("**/api/notifications", route => route.fulfill({ json: { notifications: [] } }));
}

test("Profil server memisahkan centang dari emailVerified dan mengabaikan flag kiriman", () => {
  expect(publicUser(ownerSource)).toMatchObject({ verified: true, emailVerified: false });
  expect(publicUser({ ...ownerSource, emailVerified: true })).toMatchObject({ verified: true, emailVerified: true });
  expect(publicUser(memberSource)).toMatchObject({ verified: false, emailVerified: true });
  expect(publicUser({ ...memberSource, emailVerified: false })).toMatchObject({ verified: false, emailVerified: false });
  const forged = { ...memberSource, name: "ilfil1087@gmail.com", verified: true, admin: true };
  expect(publicUser(forged).verified).toBe(false);
  expect(publicUser(forged)).not.toHaveProperty("admin");
});

test("Sesi anonim tidak mendapat centang melalui parameter URL", async ({ request }) => {
  const response = await request.get("/api/auth?email=ilfil1087%40gmail.com&verified=true");
  expect(response.status()).toBe(200);
  expect(response.headers()["cache-control"]).toContain("no-store");
  expect((await response.json()).user).toBeNull();
});

for (const width of [360, 390, 1440]) {
  test(`Centang terlihat di sebelah alfn pada layar ${width}px tanpa verifikasi email`, async ({ page }, testInfo) => {
    const owner = publicUser(ownerSource);
    const member = publicUser(memberSource);
    await mockSession(page, owner);
    await page.route("**/api/community?animeId=0", route => route.fulfill({
      json: {
        comments: [
          { id: "b1b06a6b-956e-442e-8d5a-b03430d17c03", userId: owner.id, name: owner.name, verified: owner.verified, body: "Selamat datang di komunitas animeil.al.", parentId: null, createdAt: new Date().toISOString(), likes: 0, liked: false },
          { id: "0c16177d-5774-4bbf-875c-690d9832aa03", userId: member.id, name: member.name, verified: member.verified, body: "Senang bisa berbagi cerita di sini.", parentId: "b1b06a6b-956e-442e-8d5a-b03430d17c03", createdAt: new Date().toISOString(), likes: 0, liked: false },
        ],
        stats: { likes: 0, rating: 0, votes: 0 }, liked: false, score: 0,
      },
    }));
    await page.setViewportSize({ width, height: 900 });
    await page.goto("/");
    await expect(page.locator(".profile-button .profile-name")).toHaveText("alfn");
    await expect(page.locator(".profile-button .verified-badge")).toBeVisible();
    await expect(page.locator(".profile-button .verified-badge")).toHaveCSS("color", "rgb(255, 152, 63)");
    await page.getByRole("button", { name: "Menu akun alfn", exact: true }).click();
    await expect(page.locator(".account-info .account-name")).toHaveText("alfn");
    const badge = page.locator(".account-info .verified-badge");
    await expect(badge).toBeVisible();
    await expect(badge).toHaveAccessibleName("Centang oranye akun khusus");
    await expect(page.getByRole("button", { name: "Verifikasi email", exact: true })).toBeVisible();
    const nameBox = await page.locator(".account-info .account-name").boundingBox();
    const badgeBox = await badge.boundingBox();
    expect(nameBox).not.toBeNull(); expect(badgeBox).not.toBeNull();
    expect(badgeBox!.x).toBeGreaterThanOrEqual(nameBox!.x + nameBox!.width);
    expect(badgeBox!.width).toBeGreaterThanOrEqual(17);
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    await page.screenshot({ path: testInfo.outputPath(`owner-badge-${width}.png`) });
    await page.getByRole("button", { name: "Menu akun alfn", exact: true }).click();
    await page.getByRole("button", { name: "Yuk, ikut ngobrol", exact: true }).click();
    const ownerComment = page.locator("article.comment").filter({ hasText: "Selamat datang di komunitas animeil.al." });
    await expect(ownerComment.locator(".comment-heading .verified-badge")).toBeVisible();
    const reply = page.locator("article.comment-reply").filter({ hasText: "Senang bisa berbagi cerita di sini." });
    await expect(reply).toBeVisible();
    await expect(reply.locator(".verified-badge")).toHaveCount(0);
  });
}

test("Pengguna lain tidak mendapat centang meskipun emailnya sudah terverifikasi", async ({ page }) => {
  await mockSession(page, publicUser(memberSource));
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await page.getByRole("button", { name: "Menu akun Pembaca Anime", exact: true }).click();
  await expect(page.locator(".account-info .account-name")).toHaveText(memberSource.name);
  await expect(page.locator(".profile-button .verified-badge")).toHaveCount(0);
  await expect(page.locator(".account-info .verified-badge")).toHaveCount(0);
  await expect(page.getByRole("button", { name: "Verifikasi email", exact: true })).toHaveCount(0);
});

test("Tamu tidak mendapat centang akun", async ({ page }) => {
  await mockSession(page, null);
  await page.goto("/");
  await expect(page.locator(".profile-name")).toHaveText("Masuk / Daftar");
  await expect(page.locator(".profile-button .verified-badge")).toHaveCount(0);
});
