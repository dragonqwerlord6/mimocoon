import "dotenv/config";
import { createHash, randomBytes } from "node:crypto";
import { test, expect, request as makeRequest } from "@playwright/test";
import { and, eq, inArray } from "drizzle-orm";
import { db } from "../src/db";
import { episodes, episodeSyncState, notifications, users } from "../src/db/schema";
import { catalog } from "../src/lib/catalog";
import { parseEpisode, parseFeedPage, releaseDate, publicHttpsUrl } from "../src/lib/releases/validation";
import { syncEpisodes, releaseSyncStatus } from "../src/lib/releases/sync";
import { SYNC_KEY } from "../src/lib/releases/provider";
import type { ReleaseResponse } from "../src/lib/releases/types";

const suffix = randomBytes(8).toString("hex");
const animeId = 9500000 + parseInt(suffix.slice(0, 4), 16);
const feedUrl = `https://publisher.example.com/episodes?fixture=${suffix}`;
const sourceKey = createHash("sha256").update(feedUrl).digest("hex");
const credential = randomBytes(24).toString("hex");
const emails: string[] = [];
const originalEnv: Record<string, string | undefined> = {};
let previousState: typeof episodeSyncState.$inferSelect | undefined;
const baseURL = process.env.TEST_BASE_URL || "http://localhost:3000";

function sample(number: number, releaseAt: string) {
  return {
    animeId, number, title: `Cerita pengujian ${number}`, releaseAt,
    videoUrl: `https://cdn.publisher.example.com/${suffix}/episode-${number}.m3u8`,
    subtitleUrl: `https://cdn.publisher.example.com/${suffix}/episode-${number}-id.vtt`,
    subtitleLanguage: "id",
    anime: { id: animeId, title: "Serial uji rilis otomatis", image: "https://cdn.publisher.example.com/poster.jpg", description: "Serial untuk menguji jadwal, bukan episode anime sungguhan.", genres: ["Petualangan"], year: 2026 },
  };
}

test.beforeAll(async () => {
  for (const key of ["EPISODE_FEED_URL", "EPISODE_FEED_TOKEN", "EPISODE_SYNC_INTERVAL_SECONDS", "MEDIA_ALLOWED_HOSTS"]) originalEnv[key] = process.env[key];
  process.env.EPISODE_FEED_URL = feedUrl;
  process.env.EPISODE_FEED_TOKEN = credential;
  process.env.EPISODE_SYNC_INTERVAL_SECONDS = "300";
  process.env.MEDIA_ALLOWED_HOSTS = "cdn.publisher.example.com";
  [previousState] = await db.select().from(episodeSyncState).where(eq(episodeSyncState.key, SYNC_KEY));
});

test.afterAll(async () => {
  for (const [key, value] of Object.entries(originalEnv)) { if (value === undefined) delete process.env[key]; else process.env[key] = value; }
  await db.delete(episodes).where(eq(episodes.animeId, animeId));
  if (emails.length) await db.delete(users).where(inArray(users.email, emails));
  await db.delete(episodeSyncState).where(and(eq(episodeSyncState.key, SYNC_KEY), eq(episodeSyncState.sourceKey, sourceKey)));
  if (previousState) await db.insert(episodeSyncState).values(previousState).onConflictDoNothing();
});

test("Feed mewajibkan zona waktu, menolak tanggal/URL tidak aman dan melewati entri invalid", () => {
  const past = "2026-01-01T19:00:00+07:00";
  expect(releaseDate(past).toISOString()).toBe("2026-01-01T12:00:00.000Z");
  expect(() => releaseDate("2026-01-01T19:00:00")).toThrow(/zona waktu/);
  expect(() => releaseDate("2026-02-30T19:00:00Z")).toThrow(/tidak valid/);
  expect(() => releaseDate("2026-01-01T19:00:00+15:00")).toThrow(/tidak valid/);
  expect(() => parseEpisode({ ...sample(1, past), releaseAt: undefined })).toThrow(/zona waktu/);
  expect(() => parseEpisode({ ...sample(1, past), subtitleLanguage: "en" })).toThrow(/Indonesia/);
  expect(() => parseEpisode({ ...sample(1, past), videoUrl: "https://127.0.0.1/movie.mp4" })).toThrow(/HTTPS/);
  expect(publicHttpsUrl("https://user:password@publisher.example.com/feed")).toBe(false);
  expect(publicHttpsUrl("https://[::1]/feed")).toBe(false);
  expect(publicHttpsUrl("https://internal.local/feed")).toBe(false);
  const parsed = parseFeedPage({ episodes: [sample(1, past), { ...sample(2, past), releaseAt: "tidak-valid" }], nextCursor: "page-two" });
  expect(parsed.episodes).toHaveLength(1); expect(parsed.errors).toHaveLength(1); expect(parsed.nextCursor).toBe("page-two");
});

test("Import menerbitkan episode lama langsung, menahan episode mendatang dan tidak menggandakan notifikasi", async () => {
  const client = await makeRequest.newContext({ baseURL });
  const email = `episode-${suffix}@example.com`; emails.push(email);
  const registered = await client.post("/api/auth", { data: { action: "register", email, name: "Penguji Rilis", password: credential } });
  expect(registered.status()).toBe(201);
  const userId = (await registered.json()).user.id;
  const anime = { ...catalog[6], id: animeId, title: "Serial uji rilis otomatis", image: "https://cdn.publisher.example.com/poster.jpg" };
  expect((await client.post("/api/library", { data: { action: "save", anime } })).status()).toBe(200);
  const past = new Date(Date.now() - 86400000).toISOString();
  let future = sample(3, new Date(Date.now() + 86400000).toISOString());
  let items: unknown[] = [sample(1, past), sample(2, past), future, { ...sample(4, past), releaseAt: "unknown" }];
  let fetches = 0;
  const fetcher = async (url: string, init: RequestInit) => {
    fetches++;
    expect(new URL(url).origin).toBe("https://publisher.example.com");
    expect(new Headers(init.headers).get("Authorization")).toBe(`Bearer ${credential}`);
    expect(init.redirect).toBe("error");
    return Response.json({ episodes: items });
  };
  const first = await syncEpisodes({ force: true, fetcher });
  expect(first.state).toBe("partial");
  expect(first.result).toMatchObject({ imported: 3, updated: 0, unchanged: 0, released: 2, scheduled: 1, rejected: 1 });
  const response = await client.get(`/api/releases?animeId=${animeId}`);
  const data = await response.json();
  expect(data.episodes.map((episode: { number: number }) => episode.number)).toEqual([1, 2]);
  expect(data.upcoming).toHaveLength(1);
  expect(data.upcoming[0].number).toBe(3);
  expect(data.upcoming[0]).not.toHaveProperty("videoUrl");
  expect(data.upcoming[0]).not.toHaveProperty("subtitleUrl");
  expect(JSON.stringify(data)).not.toContain("episode-3.m3u8");
  expect((await client.get(`/api/subtitles?id=${data.upcoming[0].id}`)).status()).toBe(404);
  expect((await (await client.get("/api/notifications")).json()).notifications.filter((n: { animeId: number }) => n.animeId === animeId)).toHaveLength(2);
  expect(await db.select().from(notifications).where(and(eq(notifications.userId, userId), eq(notifications.animeId, animeId)))).toHaveLength(3);

  const second = await syncEpisodes({ force: true, fetcher });
  expect(second.result).toMatchObject({ imported: 0, updated: 0, unchanged: 3 });
  expect(await db.select().from(episodes).where(eq(episodes.animeId, animeId))).toHaveLength(3);
  expect(await db.select().from(notifications).where(and(eq(notifications.userId, userId), eq(notifications.animeId, animeId)))).toHaveLength(3);
  const cooledDown = await syncEpisodes({ fetcher });
  expect(cooledDown.state).toBe("skipped"); expect(fetches).toBe(2);

  future = { ...future, releaseAt: new Date(Date.now() - 1000).toISOString() };
  items = [sample(1, past), sample(2, past), future];
  const movedEarlier = await syncEpisodes({ force: true, fetcher });
  expect(movedEarlier.result).toMatchObject({ imported: 0, updated: 1, released: 3, scheduled: 0 });
  expect((await (await client.get(`/api/releases?animeId=${animeId}`)).json()).episodes).toHaveLength(3);
  expect((await (await client.get("/api/notifications")).json()).notifications.filter((n: { animeId: number }) => n.animeId === animeId)).toHaveLength(3);

  future = { ...future, releaseAt: new Date(Date.now() + 172800000).toISOString() };
  items = [sample(1, past), sample(2, past), future];
  await syncEpisodes({ force: true, fetcher });
  expect((await (await client.get(`/api/releases?animeId=${animeId}`)).json()).episodes).toHaveLength(2);
  expect((await (await client.get("/api/notifications")).json()).notifications.filter((n: { animeId: number }) => n.animeId === animeId)).toHaveLength(2);
  const pending = await db.select().from(notifications).where(and(eq(notifications.userId, userId), eq(notifications.episodeId, data.upcoming[0].id)));
  expect(pending[0].visibleAt.toISOString()).toBe(future.releaseAt);
  await client.dispose();
});

test("Pengikut baru ikut menerima antrean jadwal yang sudah tersimpan", async () => {
  const client = await makeRequest.newContext({ baseURL });
  const email = `episode-late-${suffix}@example.com`; emails.push(email);
  const response = await client.post("/api/auth", { data: { action: "register", email, name: "Pengikut Baru", password: credential } });
  expect(response.status()).toBe(201);
  const userId = (await response.json()).user.id;
  const anime = { ...catalog[6], id: animeId, image: "https://cdn.publisher.example.com/poster.jpg" };
  await client.post("/api/library", { data: { action: "save", anime } });
  const notes = await db.select().from(notifications).where(eq(notifications.userId, userId));
  expect(notes).toHaveLength(1); expect(notes[0].episodeId).not.toBeNull();
  expect((await (await client.get("/api/notifications")).json()).notifications).toHaveLength(0);
  await client.post("/api/library", { data: { action: "save", anime } });
  expect(await db.select().from(notifications).where(eq(notifications.userId, userId))).toHaveLength(0);
  await client.dispose();
});

test("Feed berhalaman menyimpan cursor lalu melanjutkan backlog", async () => {
  const requested: string[] = [];
  const fetcher = async (url: string) => {
    const cursor = new URL(url).searchParams.get("cursor") || "0"; requested.push(cursor);
    const page = Number(cursor);
    return Response.json({ episodes: [sample(10 + page, new Date(Date.now() - 10000).toISOString())], nextCursor: page < 3 ? String(page + 1) : null });
  };
  const first = await syncEpisodes({ force: true, fetcher });
  expect(first.result?.imported).toBe(3); expect(first.morePages).toBe(true);
  expect(requested).toEqual(["0", "1", "2"]);
  const second = await syncEpisodes({ force: true, fetcher });
  expect(second.result?.imported).toBe(1); expect(second.morePages).toBe(false);
  expect(requested).toEqual(["0", "1", "2", "3"]);
});

test("Dua worker hanya menjalankan satu import dan kegagalan sumber tidak menghapus episode", async () => {
  let release: (() => void) | undefined;
  let enter: (() => void) | undefined;
  const entered = new Promise<void>(resolve => { enter = resolve; });
  const pending = new Promise<void>(resolve => { release = resolve; });
  let fetched = 0;
  const first = syncEpisodes({ force: true, fetcher: async () => { fetched++; enter?.(); await pending; return Response.json({ episodes: [sample(30, new Date(Date.now() - 1000).toISOString())] }); } });
  await entered;
  try {
    const second = await syncEpisodes({ force: true, fetcher: async () => { fetched++; return Response.json({ episodes: [] }); } });
    expect(second.state).toBe("skipped"); expect(fetched).toBe(1);
  } finally { release?.(); }
  expect((await first).result?.imported).toBe(1);
  const before = await db.select().from(episodes).where(eq(episodes.animeId, animeId));
  const failed = await syncEpisodes({ force: true, fetcher: async () => Response.json({ error: "private-provider-detail" }, { status: 503 }) });
  expect(failed.state).toBe("error"); expect(failed.message).not.toContain("private-provider-detail");
  expect(await db.select().from(episodes).where(eq(episodes.animeId, animeId))).toHaveLength(before.length);
  expect((await releaseSyncStatus()).state).toBe("error");
});

test("Sumber kosong dan scheduler tanpa izin tidak dianggap sebagai sinkronisasi sukses", async ({ request }) => {
  const saved = process.env.EPISODE_FEED_URL; delete process.env.EPISODE_FEED_URL;
  try {
    const result = await syncEpisodes({ force: true, fetcher: async () => { throw new Error("should not fetch"); } });
    expect(result.state).toBe("unconfigured");
    expect((await releaseSyncStatus()).configured).toBe(false);
  } finally { process.env.EPISODE_FEED_URL = saved; }
  const response = await request.get("/api/cron/episodes?force=1");
  expect([401, 503]).toContain(response.status());
  const spoof = await request.post("/api/cron/episodes", { headers: { Authorization: "Bearer not-the-real-secret" } });
  expect([401, 503]).toContain(spoof.status());
});

test("Jadwal ponsel menampilkan antrean terkunci dan memperbarui episode yang sudah rilis", async ({ page }) => {
  let released = false;
  const anime = catalog[6];
  const releaseAt = new Date(Date.now() + 3600000).toISOString();
  const upcoming = { id: "fe688d0f-d7f9-41a7-86b6-08cf50baf634", animeId: anime.id, anime, number: 1, title: "Perjalanan yang dinantikan", releaseAt, status: "scheduled" as const };
  await page.route("**/api/releases*", route => {
    const data: ReleaseResponse = {
      episodes: released ? [{ ...upcoming, status: "released", videoUrl: "https://cdn.publisher.example.com/released.mp4", subtitleUrl: "https://cdn.publisher.example.com/id.vtt" }] : [],
      upcoming: released ? [] : [upcoming], stats: { released: released ? 1 : 0, scheduled: released ? 0 : 1 }, serverTime: new Date().toISOString(),
      sync: { configured: true, mode: "feed", state: "ready", label: "Sinkronisasi aktif", message: "Episode terjadwal tersimpan dengan aman.", lastSuccessAt: new Date().toISOString(), nextCheckAt: null, intervalMinutes: 5 },
    };
    return route.fulfill({ json: data });
  });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await page.getByRole("button", { name: "Lihat rilis", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Sudah waktunya? Langsung tayang." })).toBeVisible();
  await page.getByRole("tab", { name: /Terjadwal/ }).click();
  await expect(page.locator(".release-card.scheduled")).toHaveCount(1);
  await page.locator(".release-card-title").click();
  const modal = page.getByRole("dialog", { name: anime.title });
  await expect(modal.getByRole("region", { name: "Episode terjadwal" })).toBeVisible();
  await expect(modal.locator(".episode-lock")).toBeVisible();
  await expect(modal.locator("video")).toHaveCount(0);
  released = true;
  await page.evaluate(() => window.dispatchEvent(new Event("focus")));
  await expect(modal.getByRole("button", { name: "Tonton episode 1", exact: true })).toBeVisible();
  await expect(modal.locator(".upcoming-episode")).toHaveCount(0);
  await expect(modal.locator(".episode-item")).toHaveCount(1);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});
