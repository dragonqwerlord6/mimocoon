import { expect, test } from "@playwright/test";

function statusPayload(available: boolean) {
  return {
    available,
    state: available ? "configured" : "unconfigured",
    label: available ? "Konfigurasi tersedia" : "Belum terhubung",
    deliveryVerified: false,
    checkedAt: new Date().toISOString(),
    message: available
      ? "Konfigurasi email sudah tersedia di server. Kamu dapat meminta tautan pemulihan; penerimaan email di kotak masuk belum diuji."
      : "Pemulihan lewat email belum aktif. Pengelola perlu menghubungkan layanan email terlebih dahulu.",
  };
}

test("Status server tidak di-cache dan tidak mengklaim email sudah terkirim", async ({ request }) => {
  const response = await request.get("/api/auth/password");
  expect(response.status()).toBe(200);
  expect(response.headers()["cache-control"]).toContain("no-store");
  const data = await response.json();
  expect(typeof data.available).toBe("boolean");
  expect(data.state).toBe(data.available ? "configured" : "unconfigured");
  expect(data.label).toBe(data.available ? "Konfigurasi tersedia" : "Belum terhubung");
  expect(data.deliveryVerified).toBe(false);
  expect(Number.isNaN(Date.parse(data.checkedAt))).toBe(false);
  expect(Math.abs(Date.now() - Date.parse(data.checkedAt))).toBeLessThan(15000);
  expect(Object.keys(data).sort()).toEqual(["available", "checkedAt", "deliveryVerified", "label", "message", "state"]);
});

test("Periksa lagi memperbarui status tanpa menghapus email yang diketik", async ({ page }) => {
  let available = false;
  let fail = false;
  let calls = 0;
  await page.route("**/api/auth/password", async route => {
    expect(route.request().method()).toBe("GET");
    calls++;
    if (fail) {
      await route.fulfill({ status: 503, json: { error: "Koneksi layanan sementara terputus. Coba lagi." } });
    } else {
      await route.fulfill({ json: statusPayload(available) });
    }
  });
  await page.goto("/");
  await page.locator(".profile-button").click();
  await page.getByRole("button", { name: "Lupa kata sandi?", exact: true }).click();
  const dialog = page.getByRole("dialog", { name: "Lupa kata sandi", exact: true });
  const status = dialog.getByRole("status");
  const submit = dialog.getByRole("button", { name: "Kirim tautan pemulihan", exact: true });
  await expect(status).toContainText("Belum terhubung");
  await expect(status).toContainText("Diperiksa pukul");
  await expect(submit).toBeDisabled();
  await dialog.getByLabel("Alamat email", { exact: true }).fill("status-test@example.invalid");

  available = true;
  await dialog.getByRole("button", { name: "Periksa lagi", exact: true }).click();
  await expect(status).toContainText("Konfigurasi tersedia");
  await expect(status).toContainText("belum diuji");
  await expect(submit).toBeEnabled();
  await expect(dialog.getByLabel("Alamat email", { exact: true })).toHaveValue("status-test@example.invalid");
  expect(calls).toBeGreaterThanOrEqual(2);

  fail = true;
  await dialog.getByRole("button", { name: "Periksa lagi", exact: true }).click();
  await expect(status).toContainText("Status belum dapat diperiksa");
  await expect(status).not.toContainText("Belum terhubung");
  await expect(submit).toBeDisabled();

  fail = false;
  await dialog.getByRole("button", { name: "Periksa lagi", exact: true }).click();
  await expect(status).toContainText("Konfigurasi tersedia");
  await expect(submit).toBeEnabled();
});

test("Kembali ke tab memeriksa ulang status secara otomatis", async ({ page }) => {
  let available = false;
  let calls = 0;
  await page.route("**/api/auth/password", async route => {
    calls++;
    await route.fulfill({ json: statusPayload(available) });
  });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await page.locator(".profile-button").click();
  await page.getByRole("button", { name: "Lupa kata sandi?", exact: true }).click();
  const dialog = page.getByRole("dialog", { name: "Lupa kata sandi", exact: true });
  await expect(dialog.getByRole("status")).toContainText("Belum terhubung");
  await dialog.getByLabel("Alamat email", { exact: true }).fill("return-test@example.invalid");
  available = true;
  await page.evaluate(() => window.dispatchEvent(new Event("focus")));
  await expect(dialog.getByRole("status")).toContainText("Konfigurasi tersedia");
  await expect(dialog.getByRole("button", { name: "Kirim tautan pemulihan", exact: true })).toBeEnabled();
  await expect(dialog.getByLabel("Alamat email", { exact: true })).toHaveValue("return-test@example.invalid");
  expect(calls).toBeGreaterThanOrEqual(2);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});
