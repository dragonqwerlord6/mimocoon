import { config } from "dotenv";
import { defineConfig } from "drizzle-kit";

// Match Next.js local precedence while preserving variables supplied by CI.
config({ path: ".env.local", quiet: true });
config({ path: ".env", quiet: true });

const databaseUrl = process.env.DATABASE_DIRECT_URL?.trim() || process.env.DATABASE_URL?.trim();
if (!databaseUrl) {
  throw new Error("Isi DATABASE_URL di .env atau environment deployment. Lihat DEPLOYMENT.md.");
}

export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dbCredentials: { url: databaseUrl },
  strict: true,
});
