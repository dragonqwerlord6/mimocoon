CREATE TABLE "episode_sync_state" (
	"key" varchar(40) PRIMARY KEY NOT NULL,
	"source_key" text,
	"state" varchar(20) DEFAULT 'waiting' NOT NULL,
	"running_token" uuid,
	"lease_until" timestamp with time zone,
	"cursor" text,
	"last_attempt_at" timestamp with time zone,
	"last_success_at" timestamp with time zone,
	"next_attempt_at" timestamp with time zone,
	"last_error" varchar(500),
	"imported" integer DEFAULT 0 NOT NULL,
	"updated" integer DEFAULT 0 NOT NULL,
	"unchanged" integer DEFAULT 0 NOT NULL,
	"rejected" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
ALTER TABLE "episodes" ADD COLUMN "anime" jsonb;--> statement-breakpoint
ALTER TABLE "episodes" ADD COLUMN "source" varchar(30) DEFAULT 'webhook' NOT NULL;--> statement-breakpoint
ALTER TABLE "episodes" ADD COLUMN "synced_at" timestamp with time zone DEFAULT now() NOT NULL;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN "episode_id" uuid;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_episode_id_episodes_id_fk" FOREIGN KEY ("episode_id") REFERENCES "public"."episodes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "episode_release_at_idx" ON "episodes" USING btree ("release_at");--> statement-breakpoint
CREATE UNIQUE INDEX "notification_episode_user" ON "notifications" USING btree ("user_id","episode_id");