# Pengambilan episode dan rilis otomatis

## Perilaku

1. Server mengambil feed JSON dari **penerbit video berlisensi** yang dikonfigurasi pengelola.
2. Episode dengan `releaseAt` yang sudah lewat atau sama dengan waktu server langsung tampil. Tidak ada penundaan tambahan untuk katalog lama.
3. Episode mendatang disimpan sebagai terjadwal. API hanya menampilkan judul, poster, nomor, dan waktu rilis; URL video/subtitle tidak pernah dikirim sebelum waktunya.
4. Saat `releaseAt` tercapai, filter waktu database otomatis memasukkan episode ke daftar tayang. Tidak perlu menunggu cron berikutnya untuk membuka episode yang sudah tersimpan.
5. Antarmuka memeriksa perubahan setiap 20 detik, saat kembali ke tab, dan sekali lagi ketika hitung mundur mencapai waktu rilis. Jam hitung mundur menyesuaikan waktu server. Waktu ditampilkan dalam WIB.
6. Pengambilan berulang memperbarui pasangan `animeId` + `number`, tidak membuat salinan baru. Perubahan waktu/judul memperbarui notifikasi. Notifikasi episode memiliki kunci unik pengguna + episode dan hanya terlihat setelah waktu rilis.
7. Pengguna yang menyimpan anime setelah episode dijadwalkan tetap berlangganan notifikasi episode mendatang. Menghapus dari koleksi menghapus notifikasi episode yang belum waktunya terlihat, tanpa menghapus balasan komentar.

**Feed belum disediakan oleh proyek ini.** Tanpa `EPISODE_FEED_URL`, aplikasi menampilkan “Menunggu sumber” dan tidak mengambil video. Jikan hanya untuk metadata/jadwal siaran, bukan sumber video atau bukti bahwa episode tersedia. Tidak ada scraping situs bajakan, bypass DRM, atau pengunduhan video pihak ketiga tanpa izin.

## Environment server

- `EPISODE_FEED_URL`: URL HTTPS publik feed penerbit. Redirect, URL berkredensial, literal IP, dan alamat jaringan privat tidak diizinkan.
- `EPISODE_FEED_TOKEN`: opsional; dikirim ke feed sebagai header `Authorization: Bearer ...`. Gunakan token baca dari penerbit, bukan token pengguna aplikasi.
- `EPISODE_SYNC_INTERVAL_SECONDS`: batas frekuensi pemeriksaan, default **300 detik** (5 menit), rentang 60–86400.
- `CRON_SECRET`: rahasia acak panjang (disarankan minimal 32 karakter) untuk pemanggil scheduler. Berbeda dari token feed.
- `MEDIA_ALLOWED_HOSTS`: daftar hostname CDN video/subtitle berlisensi yang diizinkan, dipisahkan koma. Sangat disarankan di produksi. Nilai kosong berarti menerima hostname HTTPS publik dari penerbit tepercaya.
- `RELEASE_WEBHOOK_SECRET`: opsional, tetap didukung untuk penerbit yang mengirim episode segera melalui webhook.

Jangan memberi variabel ini prefix `NEXT_PUBLIC_`. Jangan memasukkan token di URL atau kode frontend. Hanya pengelola deployment yang boleh mengubah URL sumber; centang oranye **tidak** memberi hak admin maupun akses scheduler.

## Format feed

Ini adalah kontrak adapter aplikasi, bukan klaim bahwa layanan anime tertentu menyediakan API yang sama. Jika penyedia memakai format lain, hubungkan adapter resmi milikmu yang menghasilkan JSON berikut.

Feed mengirim HTTP 200 dengan `Content-Type: application/json`. Contoh dokumentasi (URL contoh tidak memutar anime nyata):

```json
{
  "episodes": [
    {
      "animeId": 52991,
      "number": 1,
      "title": "Awal perjalanan",
      "videoUrl": "https://media.publisher.example.com/anime/52991/1/master.m3u8",
      "subtitleUrl": "https://media.publisher.example.com/anime/52991/1/id.vtt",
      "subtitleLanguage": "id",
      "releaseAt": "2026-01-01T19:00:00+07:00",
      "anime": {
        "id": 52991,
        "title": "Frieren: Beyond Journey's End",
        "image": "https://media.publisher.example.com/posters/52991.jpg",
        "description": "Sebuah perjalanan memahami waktu dan kenangan.",
        "year": 2023,
        "genres": ["Fantasi", "Petualangan"],
        "episodes": 28
      }
    }
  ],
  "nextCursor": null
}
```

- `animeId`: ID katalog/MyAnimeList, integer positif kurang dari 10.000.000.
- `number`: integer 1–10000, unik per anime.
- `title`: bahasa Indonesia, maksimal 200 karakter; teks Jepang ditolak.
- `videoUrl`: URL MP4 atau HLS publik/berlisensi. Host HLS harus mengizinkan CORS agar browser dapat memutar.
- `subtitleUrl`: URL WebVTT bahasa Indonesia; tidak mengikuti redirect. Audio video tetap dari sumber aslinya, tidak dilakukan dubbing otomatis.
- `subtitleLanguage`: opsional, jika diisi wajib `id`.
- `releaseAt`: **wajib** pada feed, ISO 8601 dengan `Z` atau offset seperti `+07:00`. Tanpa zona waktu atau tanggal tidak valid ditolak. Ini harus merupakan waktu **izin tayang aplikasi**, bukan sekadar siaran TV yang mungkin berbeda wilayah/embargo.
- `anime`: opsional, metadata untuk menampilkan judul di daftar rilis. Jika tidak ada, aplikasi memakai katalog lokal atau label fallback. Metadata tidak diterjemahkan otomatis; pemasok menyediakan bahasa Indonesia/judul internasional.
- `nextCursor`: null/tidak ada bila selesai, atau cursor string maksimal 1000 karakter. Halaman berikut diminta pada **URL sumber yang sama** dengan query `cursor`. Cursor tidak boleh mengandung URL pengalihan; aplikasi tidak pernah mengikutinya sebagai URL.

Batas: 500 entri dan 2 MB per halaman; maksimum 3 halaman (1500 entri sebelum deduplikasi) per proses. Sisa cursor disimpan agar proses berikutnya melanjutkan backlog. Bila selesai, siklus berikut memeriksa feed dari awal untuk menemukan perubahan. Feed boleh berupa daftar incremental; hilangnya episode dari feed **tidak otomatis menghapus** episode yang telah diterbitkan.

Entri invalid dilewati dan dihitung. Kegagalan jaringan/format halaman mempertahankan episode yang sudah ada. Cursor tidak dimajukan ketika seluruh proses gagal. Kunci lease database 120 detik mencegah dua worker menulis bersamaan; transaksi bersama webhook mencegah duplikasi. Token/URL rahasia tidak dikirim ke status publik atau log error.

Gunakan URL CDN berumur cukup panjang atau URL penerbit yang memperbarui akses dengan benar. Aplikasi tidak memperpanjang signed URL yang kedaluwarsa sendiri. Untuk embargo yang ketat, penerbit/CDN juga harus membatasi akses sebelum jadwal: menyembunyikan URL aplikasi bukan pengganti kontrol akses pada server video.

## Scheduler

### Vercel Hobby (gratis)

`vercel.json` menyediakan satu cron harian: `0 0 * * *` (sekitar 07.00 WIB; Vercel Hobby dapat menjalankan dalam rentang satu jam). Ini sengaja bukan `*/5` karena Hobby menolak cron lebih dari sekali sehari.

Vercel mengirim `Authorization: Bearer <CRON_SECRET>` ke `/api/cron/episodes`. Cron produksi tidak berjalan otomatis pada preview/local. Isi secret dan redeploy. Tanpa secret, endpoint menolak pemanggilan.

Selain cron, membaca daftar rilis saat aplikasi terbuka memicu catch-up menggunakan Next.js `after`, maksimal sesuai interval yang disimpan di database. Ini **bukan** jaminan pengambilan setiap lima menit saat tidak ada pengunjung.

### Interval 5 menit tanpa pengunjung

Gunakan scheduler eksternal yang mendukung header Authorization, cron server milikmu, atau paket Vercel yang mendukung interval tersebut. Untuk Vercel Pro, ubah jadwal menjadi `*/5 * * * *` jika paketmu mendukungnya. Endpoint:

- `GET` atau `POST /api/cron/episodes`
- Header `Authorization: Bearer <CRON_SECRET>`
- `?force=1` opsional untuk pemeriksaan manual oleh pemegang secret, mengabaikan cooldown tetapi **tidak** melewati lock dan **tidak** memajukan waktu rilis.

Untuk lokal/server yang sudah menjalankan aplikasi:

```sh
node scripts/sync-episodes.mjs
```

Script memakai `APP_URL` dan `CRON_SECRET` dari environment/.env. Jadwalkan setiap lima menit memakai cron OS atau Windows Task Scheduler. Tambahkan `--force` hanya bila ingin memeriksa segera. Script tidak menyimpan proses latar belakang permanen.

Gunakan webhook penerbit untuk penerimaan episode secepat mungkin. Frekuensi polling hanya menentukan seberapa cepat **episode baru ditemukan**. Episode yang sudah tersimpan di antrean tetap terbuka tepat menurut waktu server meski cron berikutnya belum jalan.

## Webhook kompatibel

`POST /api/releases` dengan `Authorization: Bearer <RELEASE_WEBHOOK_SECRET>` menerima satu objek episode dengan field yang sama. Jika `releaseAt` tidak diisi pada webhook, dianggap rilis segera. Jika ada waktu mendatang, tetap ditahan walaupun request mencoba mengirim flag `published`/`force`: hanya timestamp yang valid menentukan akses. Flag tersebut tidak dipakai.

Respons mengembalikan status `released` atau `scheduled` dan ringkasan perubahan. Riwayat impor, metadata, serta penundaan notifikasi menggunakan layanan yang sama dengan feed.

## Migrasi dan pemeriksaan

Jalankan `npx drizzle-kit migrate` pada database yang sudah memakai migrasi proyek. Migrasi tambahan mempertahankan episode dan akun lama, menambahkan snapshot anime, status sinkronisasi, dan hubungan notifikasi episode. Backup database produksi sebelum migrasi.

Tes otomatis memeriksa:
- Episode lama langsung tersedia setelah import.
- URL episode/subtitle mendatang tidak ada di API publik dan endpoint subtitle tetap menolak sebelum waktunya.
- Sinkronisasi ulang dan dua worker tidak menggandakan episode/notifikasi.
- Perubahan jadwal mengikuti penerbit, termasuk penundaan dan rilis yang dimajukan.
- Pengambilan berhalaman dilanjutkan menggunakan cursor.
- Sumber belum dikonfigurasi/tidak dapat dihubungi tidak dipalsukan menjadi status sukses.
- Countdown dan perpindahan daftar tanpa reload pada HP.

Pengujian feed memakai respons penerbit tiruan pada database pengujian, bukan video anime asli. Agar beroperasi nyata, tetap diperlukan kontrak sumber berlisensi, konfigurasi server, dan scheduler yang berjalan.

Dokumentasi Vercel: https://vercel.com/docs/cron-jobs/manage-cron-jobs
