# animeil.al

Aplikasi Next.js App Router berbahasa Indonesia dengan PostgreSQL dan Drizzle. Katalog, pencarian, jadwal, akun berbasis kata sandi, koleksi, riwayat, rating, suka anime/komentar, balasan, dan notifikasi tersimpan di database.

## Unduh, jalankan lokal, atau deploy ke Vercel

Paket source berisi kode aplikasi lengkap, aset lokal, `package-lock.json`, `.env.example`, migrasi database awal, Docker Compose, serta tes. **Mulai dari [DEPLOYMENT.md](DEPLOYMENT.md)** untuk langkah lengkap Windows/macOS/Linux, PostgreSQL lokal, dan Vercel.

Prasyarat: Node.js **22 LTS**, npm, dan PostgreSQL. Cara cepat pada hasil ekstrak baru dengan Docker Compose:

1. `npm ci`
2. `node scripts/setup-local.mjs` — membuat `.env` dengan sandi database acak; tidak menimpa konfigurasi lama.
3. `docker compose up -d --wait db`
4. `npx drizzle-kit migrate` — untuk database baru/kosong.
5. `npm run dev`, lalu buka **http://localhost:3000**.

Untuk Vercel, hubungkan PostgreSQL hosted, terapkan migrasi dari mesin/CI tepercaya, tambahkan `DATABASE_URL` pada environment Vercel, lalu import repository atau jalankan Vercel CLI. `vercel.json` sudah memakai preset Next.js, `npm ci`, dan `npm run build`. **Jangan gunakan alamat database localhost di Vercel.** Email dan sumber video merupakan konfigurasi opsional milikmu sendiri, tidak disertakan.

Endpoint kesehatan: `/api/health`. `drizzle.config.ts` membaca `DATABASE_DIRECT_URL` bila tersedia atau `DATABASE_URL`. Jangan menjalankan migrasi awal pada database produksi lama yang sudah memakai `drizzle-kit push` tanpa backup dan baseline terlebih dahulu.

ZIP tidak menyertakan `.env` asli, kunci API, akun/data pengguna, `node_modules`, hasil build, atau salinan ZIP itu sendiri. Ini adalah ekspor source, bukan backup database. Lihat juga [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) untuk hak penggunaan aset.

Bila ingin membuat ulang ZIP: `python3 scripts/export-source.py`, lalu verifikasi dengan `python3 scripts/export-source.py --verify`. Python tidak dibutuhkan untuk menjalankan aplikasi.

## Keamanan akun dan centang pemilik

Kata sandi di-hash menggunakan scrypt dengan salt acak. Cookie sesi HTTP-only, SameSite=Lax, 30 hari. Token sesi disimpan dalam bentuk SHA-256. Mutasi memeriksa origin; endpoint akun dan interaksi dibatasi lajunya. Untuk deployment multi-instance, ganti pembatas laju dalam memori dengan penyimpanan terpusat dan proxy tepercaya.

Centang oranye dihitung **di server** dari email yang tersimpan pada akun, hanya untuk `ilfil1087@gmail.com` setelah normalisasi spasi luar dan huruf kecil. Sesuai permintaan pemilik aplikasi, penanda visual ini tidak bergantung pada `emailVerified` atau koneksi layanan email. Pengguna lain tidak mendapat centang walaupun emailnya terverifikasi; nama pengguna, parameter URL, alias email, dan flag `verified` kiriman klien tidak menentukan badge.

`verified` pada respons profil adalah nama kompatibilitas untuk **penanda visual akun khusus**, bukan bukti kepemilikan email dan bukan hak admin. Status kepemilikan email tetap menggunakan `emailVerified` secara terpisah dan hanya berubah lewat alur verifikasi/pemulihan yang valid. Badge tampil di samping nama pada header (termasuk HP), menu akun, komentar, dan balasan milik akun tersebut. Sesi lama membaca aturan baru saat halaman dimuat ulang tanpa perlu mengganti sandi.

Konfigurasi verifikasi melalui Resend:
- `RESEND_API_KEY`: kunci server Resend.
- `EMAIL_FROM`: pengirim pada domain yang telah diverifikasi di Resend.
- `APP_URL`: URL HTTPS publik aplikasi, dipakai untuk tautan verifikasi agar tidak bergantung pada header request.

Jika layanan email belum dikonfigurasi, akun dan centang khusus tetap dapat digunakan sesuai aturan email. Verifikasi kepemilikan email dan pengiriman pemulihan tetap memerlukan konfigurasi penyedia. Token verifikasi sekali pakai berlaku satu jam. Jangan mengatur emailVerified secara terbuka atau menggunakan badge untuk melewati autentikasi.

## Bantuan masuk dan pemulihan kata sandi

Tidak ada akun demo, sandi bersama, atau sandi bawaan untuk opsi A/B. Pengguna baru memilih **Daftar**, membuat akun, lalu masuk menggunakan sandi akun animeil.al tersebut, bukan sandi layanan email. Kata sandi tidak dapat dilihat kembali dari database.

Dialog login menyediakan **Lupa kata sandi**, petunjuk mendaftar, tampil/sembunyikan sandi, dan peringatan Caps Lock. Fitur pemulihan menggunakan konfigurasi Resend yang sama dengan verifikasi. `APP_URL` harus HTTPS (HTTP hanya diizinkan untuk localhost). Tanpa konfigurasi ini, UI menampilkan bahwa pemulihan email belum aktif dan tidak mengaku telah mengirim email.

Endpoint `/api/auth/password`:
- `GET` memeriksa konfigurasi server saat permintaan masuk, dengan respons `private, no-store` dan waktu pemeriksaan `checkedAt`, tanpa mengekspos nilai rahasia. `available: true` / `state: configured` berarti konfigurasi tersedia, **bukan** bukti email sudah sampai. `deliveryVerified` tetap false karena endpoint ini tidak mengirim email uji. Dialog membedakan status belum terhubung, konfigurasi tersedia, dan gangguan pemeriksaan jaringan; status diperiksa kembali setiap 30 detik ketika terlihat, saat kembali ke tab, atau lewat **Periksa lagi**. Perubahan variabel lingkungan harus diterapkan melalui restart/deployment server terlebih dahulu.
- `POST` dengan aksi `request` dan email meminta tautan pemulihan. Permintaan dibatasi per IP dan alamat email; respons generik tidak mengungkap keberadaan akun. Pengiriman berjalan setelah respons melalui Next.js `after` dan kegagalan dicatat tanpa token maupun data akun.
- `POST` dengan aksi `reset`, token, password, dan confirmPassword memperbarui kata sandi secara transaksional hanya bila token valid. Token acak 256-bit disimpan sebagai SHA-256, berlaku 30 menit, sekali pakai, dan hanya ada satu token aktif per akun.

Tautan menggunakan fragmen `/#reset=...` agar token tidak ikut terkirim dalam URL HTTP. Aplikasi segera menghapus token dari bilah alamat dan tidak menyimpannya di localStorage. Reset yang berhasil mengakhiri seluruh sesi lama, menghapus tautan verifikasi email lama, dan mengharuskan login ulang. Kepemilikan tautan email juga memverifikasi alamat tersebut; centang oranye tetap hanya boleh untuk email pemilik yang diizinkan. Tidak ada bypass pemulihan melalui nama pengguna, chat, atau pengaturan kata sandi bersama.

## Katalog dan gambar

Metadata langsung menggunakan Jikan v4 (MyAnimeList) dengan cache 15 menit, filter konten aman, dan timeout. Jika sumber tidak dapat dijangkau, pencarian tetap bekerja pada katalog lokal. Halaman jadwal menyatakan ketidaktersediaan secara jelas, tidak mengarang tanggal rilis. Waktu jadwal adalah JST. Deskripsi kurasi dan antarmuka berbahasa Indonesia; judul memakai versi internasional atau romanisasi.

Poster katalog disimpan lokal dari MyAnimeList. Gambar hero dan avatar adalah ilustrasi yang dihasilkan untuk prototipe. Lampiran pengguna tidak tersedia sebagai file di sandbox saat pembuatan; `public/images/avatar.webp` dan `src/app/icon.png` dapat diganti dengan gambar asli yang disetujui pengguna. Tidak ada klaim bahwa ilustrasi pengganti merupakan berkas asli lampiran.

## Episode berlisensi dan rilis otomatis

Tidak ada episode bajakan atau tautan streaming tidak resmi. Sebelum penerbit terhubung, pemutar menawarkan trailer resmi yang disematkan dari YouTube dan tautan pencarian layanan resmi. Subtitle pada trailer bergantung kanal; teks Indonesia tidak dijanjikan bila kanal tidak menyediakannya. Pemutar mendukung MP4 serta HLS (hls.js) untuk video berlisensi dan WebVTT Indonesia, dengan audio asli dari sumber.

**Pengambilan otomatis didukung** melalui feed JSON berlisensi. Panduan format, scheduler, migrasi, dan batas Vercel Hobby ada di [EPISODE_SYNC.md](EPISODE_SYNC.md).

Episode dengan `releaseAt` yang sudah lewat langsung tersedia setelah diterima; episode mendatang masuk daftar **Terjadwal** tanpa URL video/subtitle, kemudian terbuka otomatis berdasarkan waktu server. Sinkronisasi berulang tidak menggandakan episode atau notifikasi. Beranda menampilkan status sumber; halaman Jadwal dan pemutar menampilkan antrean serta hitung mundur dalam WIB.

Konfigurasi:
- `EPISODE_FEED_URL`: feed JSON HTTPS milik penerbit berlisensi.
- `EPISODE_FEED_TOKEN`: token baca server jika diperlukan penerbit.
- `EPISODE_SYNC_INTERVAL_SECONDS`: cooldown pengambilan, default 300 detik.
- `CRON_SECRET`: rahasia scheduler untuk `/api/cron/episodes`.
- `RELEASE_WEBHOOK_SECRET`: rahasia panjang acak yang dibagikan hanya kepada penerbit berizin.
- `MEDIA_ALLOWED_HOSTS`: daftar hostname CDN yang diperbolehkan, dipisahkan koma. Sangat dianjurkan untuk produksi.

Tanpa feed, aplikasi menampilkan **Menunggu sumber**, bukan berpura-pura mengambil episode. Cron bawaan Vercel dijalankan harian agar kompatibel Hobby. Untuk pemeriksaan setiap lima menit tanpa pengunjung gunakan scheduler eksternal atau paket yang mendukung; catch-up saat aplikasi terbuka tetap dibatasi cooldown database. Episode yang sudah tersimpan tidak perlu menunggu cron untuk terbuka pada waktunya.

Penerbit mengirim `POST /api/releases` dengan header `Authorization: Bearer <RELEASE_WEBHOOK_SECRET>` dan JSON:
- `animeId`: ID MyAnimeList, integer positif.
- `number`: nomor episode, 1–10000.
- `title`: judul episode dalam bahasa Indonesia, maksimal 200 karakter.
- `videoUrl`: URL HTTPS MP4 atau HLS berlisensi; CDN HLS harus mengizinkan CORS.
- `subtitleUrl`: URL HTTPS subtitle WebVTT bahasa Indonesia, tanpa redirect.
- `releaseAt`: waktu ISO 8601 lengkap dengan zona waktu, misalnya 2026-12-01T19:00:00+07:00.

Pasangan animeId/number unik dan idempoten untuk penerbitan ulang. Episode otomatis terlihat ketika releaseAt tercapai melalui filter database. Endpoint publik hanya menampilkan metadata episode mendatang, tidak URL medianya. Pemutar memeriksa episode setiap 20 detik, saat kembali ke tab, dan saat countdown berakhir. Notifikasi rilis unik per pengguna/episode dan tidak terlihat sebelum jadwal rilis; pengguna yang menyimpan setelah penjadwalan juga mendapat notifikasi episode mendatang. Perubahan waktu rilis memperbarui visibleAt secara transaksional agar notifikasi tidak muncul lebih awal.

Notifikasi balasan dibuat secara transaksional dengan komentar. Klien memeriksa notifikasi setiap 20 detik selama aplikasi terbuka. Pengingat browser memerlukan izin pengguna; ini bukan layanan Web Push ketika aplikasi ditutup. Jangan menjanjikan rilis simultan global atau subtitle otomatis tanpa kontrak penerbit dan sumber subtitle yang sesuai.

## Validasi

Jalankan `npx next typegen`, `npm exec tsc -- --noEmit --pretty false`, dan `npm run build`. Lingkungan pratinjau menggunakan proses bootstrap/build/start/healthcheck terkelola. Jangan menggunakan email sungguhan untuk data akun pengujian. Tes badge memakai fixture respons browser yang dibentuk oleh pemetaan profil server; tes tidak mendaftarkan alamat pemilik, membaca sandinya, atau mengubah akun pemilik di database.
