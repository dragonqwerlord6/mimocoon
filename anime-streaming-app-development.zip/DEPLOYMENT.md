# Panduan deploy animeil.al

Paket ini adalah source Next.js App Router + PostgreSQL/Drizzle, bukan HTML statis. Ekstrak ZIP, lalu buka terminal di folder `animeil-al` yang berisi `package.json`.

## Yang disertakan

- Seluruh kode antarmuka, route API, autentikasi, komentar, koleksi, rating, notifikasi, pemutar, dan aturan centang oranye terbaru.
- Seluruh aset gambar, ikon aplikasi, dan font lokal yang dipakai aplikasi.
- `package.json` dan `package-lock.json` agar `npm ci` memasang versi yang terkunci.
- Skema Drizzle serta migrasi SQL awal dalam `drizzle/`.
- `.env.example`, konfigurasi Vercel, Docker Compose untuk PostgreSQL lokal, dan tes otomatis.
- `SOURCE-MANIFEST.json` di dalam ZIP, berisi SHA-256 setiap file sumber.

**Tidak disertakan:** `.env` asli, API key, token sesi, database atau akun pengguna, `node_modules`, `.next`, dan hasil tes. Dengan database baru, pengguna perlu mendaftar sendiri. Tidak ada sandi admin bawaan. File ZIP bukan backup database aplikasi pratinjau.

## Prasyarat

- Node.js **22 LTS** dan npm. `.nvmrc` memilih versi 22.
- PostgreSQL 16 atau versi kompatibel. Untuk cara cepat lokal gunakan Docker Desktop / Docker Engine dengan Compose v2.
- Internet saat `npm ci`. Aset utama sudah lokal; metadata terbaru dan trailer memerlukan internet.
- Python 3 hanya diperlukan bila ingin membuat ulang ZIP, bukan untuk menjalankan aplikasi.

## A. Jalankan lokal dengan PostgreSQL Docker

1. Ekstrak ZIP dan masuk ke folder proyek:

   ```sh
   cd animeil-al
   npm ci
   node scripts/setup-local.mjs
   ```

   Script membuat `.env` dengan sandi PostgreSQL acak. Sandi tidak ditampilkan di terminal dan tidak terkait sandi akun animeil.al. Script **tidak menimpa** `.env` atau `.env.local` yang sudah ada.

2. Jalankan PostgreSQL dan tunggu sampai sehat:

   ```sh
   docker compose up -d --wait db
   ```

   Database hanya diekspos di `127.0.0.1`, tidak di jaringan publik. Datanya disimpan dalam volume Docker. Jika Compose tidak mendukung `--wait`, gunakan `docker compose up -d db` lalu periksa `docker compose ps` sampai status healthy.

3. Terapkan migrasi pada database **baru/kosong**:

   ```sh
   npx drizzle-kit migrate
   ```

4. Jalankan aplikasi:

   ```sh
   npm run dev
   ```

5. Buka **http://localhost:3000**. Endpoint **http://localhost:3000/api/health** harus menampilkan `{"ok":true}`. Buat akun sendiri lewat **Daftar** untuk menguji komentar dan koleksi.

Untuk menjalankan hasil build produksi secara lokal:

```sh
npm run build
npm run start
```

Perintah produksi ini untuk komputer/server milikmu, bukan perintah yang perlu dimasukkan sebagai build command Vercel.

Menghentikan database tanpa menghapus data:

```sh
docker compose stop
```

**Jangan gunakan `docker compose down -v` kecuali memang ingin menghapus seluruh data lokal.** Jangan mengganti sandi `.env` pada volume yang sudah berisi PostgreSQL tanpa mengganti sandi database melalui prosedur PostgreSQL.

### Port 5432 sudah digunakan?

Ubah `POSTGRES_PORT` di `.env` ke port bebas, misalnya 5433, dan ubah port pada `DATABASE_URL` agar sama. Aplikasi berjalan di mesin host, jadi alamat database lokalnya `127.0.0.1`, bukan hostname container `db`.

## B. Lokal tanpa Docker

1. Pasang Node.js 22 dan PostgreSQL. Buat database kosong serta user PostgreSQL milikmu dengan hak untuk membuat tabel di database itu.
2. Jalankan `npm ci`.
3. Salin `.env.example` menjadi `.env`:

   macOS/Linux:
   ```sh
   cp .env.example .env
   ```

   Windows PowerShell:
   ```powershell
   Copy-Item .env.example .env
   ```

4. Isi `DATABASE_URL` menggunakan connection string PostgreSQL milikmu. Polanya `postgresql://USER:PASSWORD@HOST:PORT/DATABASE`. Encode karakter khusus pada user/password sesuai aturan URL. Jangan gunakan credential contoh untuk server publik.
5. Isi `APP_URL=http://localhost:3000`. Variabel `POSTGRES_*` tidak dipakai jika tidak menjalankan Compose.
6. Jalankan `npx drizzle-kit migrate`, lalu `npm run dev`.

Drizzle membaca `.env.local` lalu `.env`, tanpa menimpa variabel yang sudah diberikan oleh terminal/CI. Pastikan tidak ada `.env.local` lama yang menunjuk ke database berbeda.

## C. Deploy ke Vercel

### 1. Siapkan PostgreSQL hosted

Gunakan PostgreSQL hosted yang dapat diakses dari Vercel, misalnya melalui Vercel Marketplace atau penyedia PostgreSQL pilihanmu. Vercel **tidak menjalankan container Docker Compose** milik proyek.

- Ambil connection string **pooled** untuk `DATABASE_URL` jika tersedia.
- Gunakan opsi TLS/SSL dari penyedia; jangan menonaktifkan verifikasi sertifikat.
- Bila migrasi memerlukan koneksi direct, simpan URL non-pooled sebagai `DATABASE_DIRECT_URL` hanya di lingkungan migrasi.
- Pilih region database dekat region fungsi Vercel. Pool aplikasi dibatasi 5 koneksi per instance, bukan untuk seluruh deployment.

### 2. Terapkan migrasi sebelum membuka aplikasi ke pengguna

Di komputer/CI tepercaya, siapkan `.env` untuk **database deployment**, bukan Docker lokal, lalu:

```sh
npm ci
npx drizzle-kit migrate
```

`DATABASE_DIRECT_URL` diprioritaskan oleh CLI migrasi jika diisi; jika kosong digunakan `DATABASE_URL`. Aplikasi sendiri hanya memakai `DATABASE_URL`.

Migrasi awal ditujukan untuk database baru. Jangan menerapkannya begitu saja pada database yang tabelnya sudah dibuat memakai `drizzle-kit push`: tabel yang sudah ada dapat menghasilkan konflik. Backup dan baseline skema terlebih dahulu, atau gunakan database baru. Jangan mencampur `push` dan migrasi versioned pada database produksi tanpa peninjauan.

Migrasi tidak otomatis dijalankan oleh `npm run build`. Ini disengaja agar preview deployment tidak mengubah database produksi secara tidak sengaja.

### 3. Upload kode ke Git dan import

1. Buat repository Git milikmu, lalu upload **isi folder hasil ekstrak**. Sertakan dotfiles seperti `.gitignore` dan `.env.example`, tetapi **jangan upload `.env`, token, atau backup database**.
2. Di Vercel pilih **Add New → Project → Import Git Repository**.
3. Root Directory adalah folder yang berisi `package.json`. Framework: **Next.js**. Node.js: **22.x**.
4. `vercel.json` sudah menetapkan Install Command `npm ci` dan Build Command `npm run build`. Biarkan Output Directory otomatis; jangan memilih static export atau folder `out` karena aplikasi memakai API dan database.
5. Tambahkan environment variables di pengaturan proyek, lalu klik **Deploy**.

### 4. Environment variables

| Variabel | Kapan dibutuhkan | Nilai |
| --- | --- | --- |
| `DATABASE_URL` | **Wajib saat build dan runtime** | PostgreSQL hosted milikmu; jangan pakai `127.0.0.1` untuk Vercel. |
| `APP_URL` | Tautan email verifikasi/reset | URL HTTPS aplikasi yang stabil, misalnya domain `.vercel.app` atau domain milikmu. |
| `RESEND_API_KEY` | Pengiriman email | Kunci server Resend milikmu. Jangan memakai prefix `NEXT_PUBLIC_`. |
| `EMAIL_FROM` | Pengiriman email | Alamat pada domain pengirim yang telah diverifikasi di Resend. |
| `RELEASE_WEBHOOK_SECRET` | Rilis episode otomatis dari penerbit | Rahasia acak panjang yang hanya dibagikan kepada penyedia berizin. |
| `MEDIA_ALLOWED_HOSTS` | Sangat disarankan untuk sumber media produksi | Daftar hostname CDN video/subtitle resmi, dipisahkan koma, tanpa protokol. |
| `DATABASE_DIRECT_URL` | Opsional, CLI migrasi saja | URL direct bila disyaratkan penyedia database. |

`POSTGRES_USER`, `POSTGRES_DB`, `POSTGRES_PASSWORD`, dan `POSTGRES_PORT` hanya untuk Docker lokal dan tidak diperlukan di Vercel.

Sesudah Vercel memberikan alamat publik, set `APP_URL` ke URL tersebut dan **redeploy**. Mengubah environment variables tidak mengubah deployment lama. Pakai database terpisah untuk Production dan Preview agar tes tidak menulis ke data pengguna sungguhan.

### 5. Alternatif: Vercel CLI tanpa Git

Dari folder hasil ekstrak, jalankan:

```sh
npx vercel login
npx vercel link
npx vercel env add DATABASE_URL production
npx vercel env add APP_URL production
```

Isi nilainya secara interaktif. Tambahkan variabel email/video hanya jika layanan tersebut sudah kamu miliki. Terapkan migrasi seperti pada langkah 2, lalu:

```sh
npx vercel --prod
```

Untuk preview CLI, tambahkan pula variabel pada environment `preview`. `.vercelignore` menjaga file rahasia dan ZIP hasil ekspor agar tidak diunggah. Jangan memakai deployment pertama yang gagal karena konfigurasi sebagai bukti aplikasi sudah siap.

### 6. Periksa deployment

- Buka `/api/health`: harus `ok: true`.
- Uji daftar/login menggunakan akun pengujian milikmu.
- Simpan anime, kirim komentar, dan pastikan interaksi bertahan setelah refresh.
- Pastikan akun biasa tidak memiliki centang oranye. Penanda visual khusus hanya untuk email yang ditentukan di `src/lib/verification.ts`; tidak memberi hak admin dan tidak membuktikan kepemilikan email.
- Buka **Lupa kata sandi** untuk melihat status konfigurasi. “Konfigurasi tersedia” bukan bukti pesan sudah diterima; lakukan pengujian email nyata setelah domain pengirim siap.
- Integrasi episode/video tidak akan aktif tanpa sumber berlisensi dan rahasia webhook sendiri. Tidak ada video bajakan atau API key yang disertakan dalam ZIP.

## Sinkronisasi episode otomatis

Lihat **[EPISODE_SYNC.md](EPISODE_SYNC.md)** untuk format feed, pemanggilan scheduler, dan perilaku rilis. Tambahkan `EPISODE_FEED_URL`, `EPISODE_FEED_TOKEN` bila perlu, `CRON_SECRET`, serta `EPISODE_SYNC_INTERVAL_SECONDS` (default 300) di environment server. Terapkan migrasi terbaru dengan `npx drizzle-kit migrate` sebelum menjalankan versi ini.

`vercel.json` sekarang berisi cron harian `/api/cron/episodes` yang kompatibel dengan Hobby. Untuk pemeriksaan setiap lima menit saat tidak ada pengunjung, gunakan scheduler eksternal dengan header Authorization atau Vercel Pro yang mendukung `*/5 * * * *`. Pengambilan saat aplikasi terbuka menggunakan `after` dan cooldown database, bukan timer server permanen. Episode yang sudah diterima dan dijadwalkan tetap terbuka otomatis menurut waktu server, terlepas dari interval cron.

Tidak ada video atau credential penerbit disertakan dalam ZIP. Tanpa feed, halaman menampilkan status **Menunggu sumber**.

## Batasan operasional yang perlu diketahui

- Pembatas laju saat ini memakai memori per proses. Untuk trafik publik multi-instance, tambahkan penyimpanan rate-limit terpusat/proteksi penyedia dan penanganan proxy tepercaya.
- Notifikasi dipolling saat aplikasi terbuka; pengingat browser ini bukan Web Push ketika aplikasi ditutup.
- Katalog langsung dapat dibatasi/diblokir oleh sumber. Saat gagal aplikasi memakai katalog lokal dan tidak mengarang jadwal.
- Hosting aplikasi tidak mencakup hak distribusi anime. Review `THIRD_PARTY_NOTICES.md` dan izin aset sebelum publikasi/komersialisasi.
- Paket source tidak membawa database lama. Pemindahan data memerlukan backup/restore PostgreSQL terpisah melalui saluran privat.

## Tes dan pengecekan

Dengan database pengujian dan aplikasi yang sudah berjalan:

```sh
npx next typegen
npm exec tsc -- --noEmit --pretty false
npm run build
npx playwright install --with-deps chromium
npx playwright test
```

Tes browser menggunakan `http://localhost:3000` kecuali `TEST_BASE_URL` diatur. Jangan arahkan tes ke database produksi. Akun tes dibersihkan setelah tes; tes badge memakai fixture, bukan akun pemilik asli.

## Membuat ulang file ZIP

Dengan Python 3.9+:

```sh
python3 scripts/export-source.py
python3 scripts/export-source.py --verify
```

Di Windows gunakan `py -3` jika perintah `python3` tidak tersedia. Hasil berada di `public/downloads/animeil-al-source.zip` dan file checksum `.zip.sha256` di sebelahnya. Pembuat ZIP memakai allowlist, tidak menyalin `.env`, dependency terpasang, log, hasil build, artefak tes, maupun ZIP lama.

ZIP yang kamu unduh **tidak berisi salinan dirinya sendiri**. Folder unduhan juga diabaikan Git/Vercel sehingga aplikasi yang kamu deploy tidak otomatis memublikasikan source code. Bila memang ingin membagikan source lagi, buat ZIP sendiri dan unggah ke tempat yang kamu pilih. Jangan menyimpan API key secara hardcoded di source; tinjau isi arsip sebelum membagikannya.

Tautan unduhan dari pratinjau dapat berhenti tersedia ketika lingkungan pratinjau berakhir. Simpan ZIP ke perangkat atau repository pribadimu segera.

## Rujukan resmi

- https://vercel.com/docs/frameworks/full-stack/nextjs
- https://vercel.com/docs/environment-variables
- https://orm.drizzle.team/docs/drizzle-config-file
- https://orm.drizzle.team/docs/migrations
